import React, { forwardRef, useState } from 'react';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
  startAdornment?: React.ReactNode;
  endAdornment?: React.ReactNode;
  fullWidth?: boolean;
}

const labelStyle: React.CSSProperties = {
  display: 'block',
  fontSize: '11px',
  fontWeight: 500,
  color: 'var(--color-text-secondary)',
  marginBottom: '5px',
  textTransform: 'uppercase',
  letterSpacing: '0.05em',
  fontFamily: 'var(--font-sans,system-ui,sans-serif)',
};

export const Input = forwardRef<HTMLInputElement, InputProps>(({
  label,
  error,
  helperText,
  startAdornment,
  endAdornment,
  fullWidth = false,
  className = '',
  style = {},
  disabled,
  onFocus,
  onBlur,
  ...props
}, ref) => {
  const [focused, setFocused] = useState(false);

  const borderColor = error
    ? '#D85A30'
    : focused
    ? '#1D9E75'
    : 'rgba(0,0,0,0.12)';

  const inputStyle: React.CSSProperties = {
    width: fullWidth ? '100%' : undefined,
    padding: `9px ${endAdornment ? '36px' : '12px'} 9px ${startAdornment ? '36px' : '12px'}`,
    border: `0.5px solid ${borderColor}`,
    borderRadius: '9px',
    fontSize: '13px',
    outline: 'none',
    background: disabled ? 'var(--color-background-secondary,#f5f4f0)' : 'var(--color-background-primary,#fff)',
    color: disabled ? 'var(--color-text-secondary)' : 'var(--color-text-primary)',
    cursor: disabled ? 'not-allowed' : 'text',
    opacity: disabled ? 0.7 : 1,
    fontFamily: 'var(--font-sans,system-ui,sans-serif)',
    boxSizing: 'border-box',
    transition: 'border-color 0.15s',
    display: 'block',
    ...style,
  };

  return (
    <div
      className={className}
      style={{ width: fullWidth ? '100%' : undefined, fontFamily: 'var(--font-sans,system-ui,sans-serif)' }}
    >
      {label && <label style={labelStyle}>{label}</label>}

      <div style={{ position: 'relative' }}>
        {startAdornment && (
          <div style={{
            position: 'absolute', left: '11px', top: '50%',
            transform: 'translateY(-50%)',
            color: 'var(--color-text-tertiary,#b0b0b0)',
            pointerEvents: 'none',
            display: 'flex', alignItems: 'center',
          }}>
            {startAdornment}
          </div>
        )}

        <input
          ref={ref}
          disabled={disabled}
          style={inputStyle}
          onFocus={e => {
            setFocused(true);
            onFocus?.(e);
          }}
          onBlur={e => {
            setFocused(false);
            onBlur?.(e);
          }}
          {...props}
        />

        {endAdornment && (
          <div style={{
            position: 'absolute', right: '11px', top: '50%',
            transform: 'translateY(-50%)',
            color: 'var(--color-text-tertiary,#b0b0b0)',
            pointerEvents: 'none',
            display: 'flex', alignItems: 'center',
          }}>
            {endAdornment}
          </div>
        )}
      </div>

      {(error || helperText) && (
        <p style={{
          margin: '4px 0 0',
          fontSize: '11px',
          color: error ? '#D85A30' : 'var(--color-text-secondary)',
          fontFamily: 'var(--font-sans,system-ui,sans-serif)',
        }}>
          {error || helperText}
        </p>
      )}
    </div>
  );
});

Input.displayName = 'Input';