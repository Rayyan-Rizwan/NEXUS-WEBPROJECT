import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  onClick?: () => void;
  hoverable?: boolean;
}

export const Card: React.FC<CardProps> = ({
  children,
  className = '',
  style = {},
  onClick,
  hoverable = false,
}) => {
  const baseStyle: React.CSSProperties = {
    background: 'var(--color-background-primary,#fff)',
    border: '0.5px solid rgba(0,0,0,0.08)',
    borderRadius: '14px',
    overflow: 'hidden',
    cursor: onClick ? 'pointer' : 'default',
    transition: hoverable ? 'border-color 0.15s, transform 0.15s' : undefined,
    fontFamily: 'var(--font-sans,system-ui,sans-serif)',
    ...style,
  };

  return (
    <div
      className={className}
      style={baseStyle}
      onClick={onClick}
      onMouseEnter={hoverable ? e => {
        (e.currentTarget as HTMLElement).style.borderColor = '#1D9E75';
        (e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)';
      } : undefined}
      onMouseLeave={hoverable ? e => {
        (e.currentTarget as HTMLElement).style.borderColor = 'rgba(0,0,0,0.08)';
        (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
      } : undefined}
    >
      {children}
    </div>
  );
};

interface CardHeaderProps {
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}

export const CardHeader: React.FC<CardHeaderProps> = ({
  children,
  className = '',
  style = {},
}) => (
  <div
    className={className}
    style={{
      padding: '16px 24px',
      borderBottom: '0.5px solid rgba(0,0,0,0.07)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      ...style,
    }}
  >
    {children}
  </div>
);

interface CardBodyProps {
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}

export const CardBody: React.FC<CardBodyProps> = ({
  children,
  className = '',
  style = {},
}) => (
  <div
    className={className}
    style={{
      padding: '20px 24px',
      ...style,
    }}
  >
    {children}
  </div>
);

interface CardFooterProps {
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}

export const CardFooter: React.FC<CardFooterProps> = ({
  children,
  className = '',
  style = {},
}) => (
  <div
    className={className}
    style={{
      padding: '12px 24px',
      borderTop: '0.5px solid rgba(0,0,0,0.07)',
      background: 'var(--color-background-secondary,#f8f7f4)',
      ...style,
    }}
  >
    {children}
  </div>
);