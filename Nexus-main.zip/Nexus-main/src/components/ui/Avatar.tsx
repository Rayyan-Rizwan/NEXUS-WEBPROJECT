import React from 'react';

export type AvatarSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

interface AvatarProps {
  src?: string;
  alt: string;
  size?: AvatarSize;
  className?: string;
  style?: React.CSSProperties;
  status?: 'online' | 'offline' | 'away' | 'busy';
}

const sizeMap: Record<AvatarSize, number> = {
  xs: 20,
  sm: 28,
  md: 36,
  lg: 44,
  xl: 60,
};

const statusColors: Record<string, string> = {
  online:  '#1D9E75',
  offline: '#A0A0A0',
  away:    '#BA7517',
  busy:    '#D85A30',
};

const avatarPalette = [
  { bg: '#EAF3DE', text: '#0F6E56' },
  { bg: '#EEEDFE', text: '#534AB7' },
  { bg: '#FAEEDA', text: '#854F0B' },
  { bg: '#FAECE7', text: '#993C1D' },
  { bg: '#FBEAF0', text: '#993556' },
];

const getColors = (name: string) => avatarPalette[(name.charCodeAt(0) + (name.charCodeAt(1) || 0)) % avatarPalette.length];
const getInitials = (name: string) => name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();

const statusDotSize: Record<AvatarSize, number> = {
  xs: 6,
  sm: 7,
  md: 9,
  lg: 10,
  xl: 12,
};

export const Avatar: React.FC<AvatarProps> = ({
  src,
  alt,
  size = 'md',
  className = '',
  style = {},
  status,
}) => {
  const px = sizeMap[size];
  const dotPx = statusDotSize[size];
  const borderRadius = size === 'xl' || size === 'lg' ? '12px' : size === 'md' ? '9px' : '7px';
  const fontSize = Math.round(px * 0.32);
  const c = getColors(alt);
  const initials = getInitials(alt);

  const [imgError, setImgError] = React.useState(false);

  const showFallback = !src || imgError;

  return (
    <div
      className={className}
      style={{
        position: 'relative',
        display: 'inline-block',
        flexShrink: 0,
        ...style,
      }}
    >
      {showFallback ? (
        <div style={{
          width: px, height: px,
          borderRadius,
          background: c.bg,
          color: c.text,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize,
          fontWeight: 500,
          fontFamily: 'var(--font-sans,system-ui,sans-serif)',
          userSelect: 'none',
        }}>
          {initials}
        </div>
      ) : (
        <img
          src={src}
          alt={alt}
          onError={() => setImgError(true)}
          style={{
            width: px, height: px,
            borderRadius,
            objectFit: 'cover',
            display: 'block',
          }}
        />
      )}

      {status && (
        <span style={{
          position: 'absolute',
          bottom: 0, right: 0,
          width: dotPx, height: dotPx,
          borderRadius: '50%',
          background: statusColors[status] || statusColors.offline,
          border: '1.5px solid var(--color-background-primary,#fff)',
          display: 'block',
        }} />
      )}
    </div>
  );
};