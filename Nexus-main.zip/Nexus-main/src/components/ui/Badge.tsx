import React from 'react';

export type BadgeVariant = 'primary' | 'secondary' | 'accent' | 'success' | 'warning' | 'error' | 'gray';
export type BadgeSize = 'sm' | 'md' | 'lg';

interface BadgeProps {
  children: React.ReactNode;
  variant?: BadgeVariant;
  size?: BadgeSize;
  rounded?: boolean;
  className?: string;
  style?: React.CSSProperties;
}

const variantStyles: Record<BadgeVariant, { bg: string; color: string; dot: string }> = {
  primary:   { bg: '#EAF3DE', color: '#0F6E56', dot: '#1D9E75' },
  secondary: { bg: '#EEEDFE', color: '#534AB7', dot: '#7F77DD' },
  accent:    { bg: '#FAEEDA', color: '#854F0B', dot: '#BA7517' },
  success:   { bg: '#EAF3DE', color: '#0F6E56', dot: '#1D9E75' },
  warning:   { bg: '#FAEEDA', color: '#854F0B', dot: '#BA7517' },
  error:     { bg: '#FAECE7', color: '#993C1D', dot: '#D85A30' },
  gray:      { bg: 'var(--color-background-secondary,#f5f4f0)', color: 'var(--color-text-secondary)', dot: '#A0A0A0' },
};

const sizeStyles: Record<BadgeSize, { fontSize: string; padding: string }> = {
  sm: { fontSize: '10px', padding: '2px 8px' },
  md: { fontSize: '11px', padding: '3px 10px' },
  lg: { fontSize: '12px', padding: '4px 12px' },
};

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  rounded = true,
  className = '',
  style = {},
}) => {
  const vs = variantStyles[variant];
  const ss = sizeStyles[size];

  return (
    <span
      className={className}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '4px',
        fontWeight: 500,
        fontFamily: 'var(--font-sans,system-ui,sans-serif)',
        borderRadius: rounded ? '20px' : '6px',
        background: vs.bg,
        color: vs.color,
        fontSize: ss.fontSize,
        padding: ss.padding,
        lineHeight: 1,
        whiteSpace: 'nowrap',
        ...style,
      }}
    >
      {children}
    </span>
  );
};