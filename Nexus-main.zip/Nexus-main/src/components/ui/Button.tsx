import React from 'react';

export type ButtonVariant = 'primary' | 'secondary' | 'accent' | 'outline' | 'ghost' | 'link' | 'success' | 'warning' | 'error';
export type ButtonSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  fullWidth?: boolean;
  isLoading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

type VariantConfig = {
  bg: string;
  color: string;
  border: string;
  hoverBg: string;
  hoverColor?: string;
};

const variantConf: Record<ButtonVariant, VariantConfig> = {
  primary:   { bg: '#1D9E75', color: '#fff', border: 'none', hoverBg: '#0F6E56' },
  secondary: { bg: '#7F77DD', color: '#fff', border: 'none', hoverBg: '#534AB7' },
  accent:    { bg: '#BA7517', color: '#fff', border: 'none', hoverBg: '#854F0B' },
  success:   { bg: '#1D9E75', color: '#fff', border: 'none', hoverBg: '#0F6E56' },
  warning:   { bg: '#BA7517', color: '#fff', border: 'none', hoverBg: '#854F0B' },
  error:     { bg: '#D85A30', color: '#fff', border: 'none', hoverBg: '#993C1D' },
  outline:   { bg: 'var(--color-background-primary,#fff)', color: 'var(--color-text-secondary)', border: '0.5px solid rgba(0,0,0,0.15)', hoverBg: 'var(--color-background-secondary,#f5f4f0)', hoverColor: 'var(--color-text-primary)' },
  ghost:     { bg: 'transparent', color: 'var(--color-text-secondary)', border: 'none', hoverBg: 'var(--color-background-secondary,#f5f4f0)', hoverColor: 'var(--color-text-primary)' },
  link:      { bg: 'transparent', color: '#1D9E75', border: 'none', hoverBg: 'transparent', hoverColor: '#0F6E56' },
};

const sizeConf: Record<ButtonSize, { fontSize: string; padding: string; gap: string; borderRadius: string }> = {
  xs: { fontSize: '11px', padding: '4px 9px',  gap: '4px', borderRadius: '7px' },
  sm: { fontSize: '12px', padding: '6px 12px', gap: '5px', borderRadius: '8px' },
  md: { fontSize: '13px', padding: '8px 16px', gap: '6px', borderRadius: '9px' },
  lg: { fontSize: '14px', padding: '10px 20px',gap: '7px', borderRadius: '10px' },
  xl: { fontSize: '15px', padding: '12px 24px',gap: '8px', borderRadius: '11px' },
};

const Spinner: React.FC = () => (
  <span style={{ display: 'inline-block', width: '14px', height: '14px', flexShrink: 0 }}>
    <style>{`@keyframes btn-spin { to { transform: rotate(360deg) } }`}</style>
    <svg viewBox="0 0 14 14" style={{ animation: 'btn-spin 0.85s linear infinite' }}>
      <circle cx="7" cy="7" r="5.5" fill="none" stroke="currentColor" strokeWidth="1.5" strokeOpacity="0.25" />
      <path d="M7 1.5A5.5 5.5 0 0 1 12.5 7" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  </span>
);

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  isLoading = false,
  leftIcon,
  rightIcon,
  children,
  className = '',
  disabled,
  style = {},
  ...props
}) => {
  const vc = variantConf[variant];
  const sc = sizeConf[size];
  const isDisabled = disabled || isLoading;

  return (
    <button
      disabled={isDisabled}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: sc.gap,
        width: fullWidth ? '100%' : undefined,
        padding: variant === 'link' ? '0' : sc.padding,
        fontSize: sc.fontSize,
        fontWeight: 500,
        fontFamily: 'var(--font-sans,system-ui,sans-serif)',
        borderRadius: sc.borderRadius,
        border: vc.border,
        background: vc.bg,
        color: vc.color,
        cursor: isDisabled ? 'not-allowed' : 'pointer',
        opacity: isDisabled ? 0.6 : 1,
        transition: 'all 0.15s',
        outline: 'none',
        lineHeight: 1,
        textDecoration: variant === 'link' ? 'none' : undefined,
        ...style,
      }}
      onMouseEnter={e => {
        if (!isDisabled) {
          (e.currentTarget as HTMLButtonElement).style.background = vc.hoverBg;
          if (vc.hoverColor) (e.currentTarget as HTMLButtonElement).style.color = vc.hoverColor;
          if (variant !== 'link') (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)';
        }
      }}
      onMouseLeave={e => {
        if (!isDisabled) {
          (e.currentTarget as HTMLButtonElement).style.background = vc.bg;
          if (vc.hoverColor) (e.currentTarget as HTMLButtonElement).style.color = vc.color;
          (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)';
        }
      }}
      onMouseDown={e => {
        if (!isDisabled) (e.currentTarget as HTMLButtonElement).style.transform = 'scale(0.98)';
      }}
      onMouseUp={e => {
        if (!isDisabled) (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)';
      }}
      className={className}
      {...props}
    >
      {isLoading && <Spinner />}
      {!isLoading && leftIcon && <span style={{ display: 'flex', alignItems: 'center', flexShrink: 0 }}>{leftIcon}</span>}
      {children}
      {!isLoading && rightIcon && <span style={{ display: 'flex', alignItems: 'center', flexShrink: 0 }}>{rightIcon}</span>}
    </button>
  );
};