import React from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Navbar } from './Navbar';
import { Sidebar } from './Sidebar';

export const DashboardLayout: React.FC = () => {
  const { user, isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'var(--color-background-tertiary,#F5F4F0)',
        fontFamily: 'var(--font-sans,system-ui,sans-serif)',
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px' }}>
          {/* Spinner */}
          <div style={{ position: 'relative', width: '40px', height: '40px' }}>
            <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
            <div style={{
              width: '40px', height: '40px', borderRadius: '50%',
              border: '3px solid #EAF3DE',
              borderTopColor: '#1D9E75',
              animation: 'spin 0.85s linear infinite',
            }} />
          </div>
          <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>Loading…</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'var(--color-background-tertiary,#F5F4F0)',
      display: 'flex',
      flexDirection: 'column',
      fontFamily: 'var(--font-sans,system-ui,sans-serif)',
    }}>
      <Navbar />

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        <Sidebar />

        <main style={{
          flex: 1,
          overflowY: 'auto',
          padding: '28px 32px',
        }}>
          <div style={{ maxWidth: '1280px', margin: '0 auto' }}>
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};