import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  Home, Building2, CircleDollarSign, Users, MessageCircle,
  Bell, FileText, Settings, HelpCircle, TrendingUp, Calendar,
  Video, Shield, CreditCard, Layers, Lock
} from 'lucide-react';

const SectionLabel: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div style={{
    fontSize: '10px', fontWeight: 500,
    color: 'rgba(255,255,255,0.25)',
    letterSpacing: '0.07em', textTransform: 'uppercase' as const,
    padding: '0 14px', marginBottom: '4px', marginTop: '16px',
  }}>
    {children}
  </div>
);

export const Sidebar: React.FC = () => {
  const { user } = useAuth();
  if (!user) return null;

  const entrepreneurItems = [
    { to: '/dashboard/entrepreneur',         icon: <Home size={15}/>,             text: 'Dashboard' },
    { to: '/profile/entrepreneur/' + user.id, icon: <Building2 size={15}/>,       text: 'My startup' },
    { to: '/investors',                       icon: <CircleDollarSign size={15}/>, text: 'Find investors' },
    { to: '/messages',                        icon: <MessageCircle size={15}/>,    text: 'Messages' },
    { to: '/notifications',                   icon: <Bell size={15}/>,             text: 'Notifications' },
    { to: '/documents',                       icon: <FileText size={15}/>,         text: 'Documents' },
    { to: '/meetings',                        icon: <Calendar size={15}/>,         text: 'Meetings' },
    { to: '/video-call',                      icon: <Video size={15}/>,            text: 'Video calls' },
  ];

  const investorItems = [
    { to: '/dashboard/investor',             icon: <Home size={15}/>,           text: 'Dashboard' },
    { to: '/profile/investor/' + user.id,    icon: <TrendingUp size={15}/>,     text: 'My portfolio' },
    { to: '/entrepreneurs',                  icon: <Users size={15}/>,          text: 'Find startups' },
    { to: '/messages',                       icon: <MessageCircle size={15}/>,  text: 'Messages' },
    { to: '/notifications',                  icon: <Bell size={15}/>,           text: 'Notifications' },
    { to: '/deals',                          icon: <Layers size={15}/>,         text: 'Deals' },
    { to: '/meetings',                       icon: <Calendar size={15}/>,       text: 'Meetings' },
    { to: '/video-call',                     icon: <Video size={15}/>,          text: 'Video calls' },
  ];

  const milestoneItems = [
    { to: '/document-chamber', icon: <Shield size={15}/>,     text: 'Document chamber' },
    { to: '/payments',         icon: <CreditCard size={15}/>,  text: 'Payments' },
    { to: '/security',         icon: <Lock size={15}/>,        text: 'Security' },
  ];

  const settingsItems = [
    { to: '/settings', icon: <Settings size={15}/>,   text: 'Settings' },
    { to: '/help',     icon: <HelpCircle size={15}/>, text: 'Help & support' },
  ];

  const mainItems = user.role === 'entrepreneur' ? entrepreneurItems : investorItems;

  const navLinkStyle = ({ isActive }: { isActive: boolean }): React.CSSProperties => ({
    display: 'flex', alignItems: 'center', gap: '9px',
    padding: '9px 12px', borderRadius: '8px',
    textDecoration: 'none', fontSize: '13px',
    fontWeight: isActive ? 500 : 400,
    color: isActive ? '#5DCAA5' : 'rgba(255,255,255,0.45)',
    background: isActive ? 'rgba(29,158,117,0.15)' : 'transparent',
    transition: 'all 0.12s', marginBottom: '1px',
  });

  const onEnter = (e: React.MouseEvent<HTMLAnchorElement>) => {
    const el = e.currentTarget;
    if (el.style.color !== 'rgb(93, 202, 165)') {
      el.style.background = 'rgba(255,255,255,0.05)';
      el.style.color = 'rgba(255,255,255,0.8)';
    }
  };

  const onLeave = (e: React.MouseEvent<HTMLAnchorElement>) => {
    const el = e.currentTarget;
    if (el.style.color !== 'rgb(93, 202, 165)') {
      el.style.background = 'transparent';
      el.style.color = 'rgba(255,255,255,0.45)';
    }
  };

  return (
    <aside
      style={{ width: '220px', background: '#1A1A1A', height: '100%', display: 'flex', flexDirection: 'column', flexShrink: 0, fontFamily: 'var(--font-sans,system-ui,sans-serif)' }}
      className="sidebar-hidden"
    >
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 12px 12px' }}>

        <SectionLabel>Main</SectionLabel>
        {mainItems.map((item, i) => (
          <NavLink key={i} to={item.to} style={navLinkStyle} onMouseEnter={onEnter} onMouseLeave={onLeave}>
            <span style={{ flexShrink: 0, opacity: 0.7, display: 'flex', alignItems: 'center' }}>{item.icon}</span>
            {item.text}
          </NavLink>
        ))}

        <SectionLabel>Features</SectionLabel>
        {milestoneItems.map((item, i) => (
          <NavLink key={i} to={item.to} style={navLinkStyle} onMouseEnter={onEnter} onMouseLeave={onLeave}>
            <span style={{ flexShrink: 0, opacity: 0.7, display: 'flex', alignItems: 'center' }}>{item.icon}</span>
            {item.text}
          </NavLink>
        ))}

        <SectionLabel>Account</SectionLabel>
        {settingsItems.map((item, i) => (
          <NavLink key={i} to={item.to} style={navLinkStyle} onMouseEnter={onEnter} onMouseLeave={onLeave}>
            <span style={{ flexShrink: 0, opacity: 0.7, display: 'flex', alignItems: 'center' }}>{item.icon}</span>
            {item.text}
          </NavLink>
        ))}
      </div>

      <div style={{ padding: '12px', borderTop: '0.5px solid rgba(255,255,255,0.08)' }}>
        <div style={{ background: 'rgba(29,158,117,0.12)', border: '0.5px solid rgba(29,158,117,0.25)', borderRadius: '10px', padding: '12px' }}>
          <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.35)', margin: '0 0 2px' }}>Need assistance?</p>
          <p style={{ fontSize: '12px', fontWeight: 500, color: 'rgba(255,255,255,0.7)', margin: '0 0 8px' }}>Contact support</p>
          <a href="mailto:support@nexus.vc" style={{ fontSize: '11px', color: '#5DCAA5', textDecoration: 'none', fontWeight: 500 }}>
            support@nexus.vc
          </a>
        </div>
      </div>

      <style>{`
        @media (max-width: 767px) { .sidebar-hidden { display: none !important; } }
      `}</style>
    </aside>
  );
};