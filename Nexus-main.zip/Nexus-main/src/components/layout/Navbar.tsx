import React, { useState } from 'react';
import { useNavigate, Link, NavLink } from 'react-router-dom';
import {
  Menu, X, Bell, MessageCircle, User, LogOut,
  Building2, CircleDollarSign, Home, ChevronDown
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75', mid: '#C0DD97' },
};

const getInitials = (name: string) => name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();

export const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
    setIsMenuOpen(false);
    setShowUserMenu(false);
  };

  const dashboardRoute = user?.role === 'entrepreneur' ? '/dashboard/entrepreneur' : '/dashboard/investor';
  const profileRoute = user ? `/profile/${user.role}/${user.id}` : '/login';

  const navLinks = [
    { icon: <Home size={15} />, text: 'Dashboard', path: dashboardRoute },
    { icon: <MessageCircle size={15} />, text: 'Messages', path: '/messages' },
    { icon: <Bell size={15} />, text: 'Notifications', path: '/notifications' },
  ];

  const initials = user ? getInitials(user.name) : '??';

  return (
    <nav style={{
      background: 'var(--color-background-primary,#fff)',
      borderBottom: '0.5px solid rgba(0,0,0,0.08)',
      position: 'sticky',
      top: 0,
      zIndex: 40,
      fontFamily: 'var(--font-sans,system-ui,sans-serif)',
    }}>
      <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '56px' }}>

          {/* Logo */}
          <Link to="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '9px' }}>
            <div style={{
              width: '30px', height: '30px', borderRadius: '8px',
              background: T.emerald.bg, display: 'flex', alignItems: 'center', justifyContent: 'center',
              border: `0.5px solid ${T.emerald.mid}`,
            }}>
              <svg width="15" height="15" viewBox="0 0 16 16" fill={T.emerald.fill}>
                <polygon points="8,1 14,4.5 14,11.5 8,15 2,11.5 2,4.5" />
              </svg>
            </div>
            <span style={{ fontSize: '15px', fontWeight: 500, color: 'var(--color-text-primary)', letterSpacing: '-0.01em' }}>
              Nexus
            </span>
          </Link>

          {/* Desktop nav */}
          <div style={{ display: 'none', alignItems: 'center', gap: '2px' }} className="desktop-nav">
            {user && navLinks.map((link, i) => (
              <NavLink
                key={i}
                to={link.path}
                style={({ isActive }) => ({
                  display: 'flex', alignItems: 'center', gap: '6px',
                  padding: '7px 12px', borderRadius: '8px',
                  fontSize: '13px', textDecoration: 'none',
                  fontWeight: isActive ? 500 : 400,
                  color: isActive ? '#0F6E56' : 'var(--color-text-secondary)',
                  background: isActive ? '#EAF3DE' : 'transparent',
                  transition: 'all 0.12s',
                })}
              >
                {link.icon} {link.text}
              </NavLink>
            ))}
          </div>

          {/* Right side */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            {user ? (
              <>
                {/* User menu */}
                <div style={{ position: 'relative' }}>
                  <button
                    onClick={() => setShowUserMenu(p => !p)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: '7px',
                      padding: '5px 10px 5px 5px', borderRadius: '10px',
                      border: '0.5px solid rgba(0,0,0,0.10)',
                      background: 'var(--color-background-primary,#fff)',
                      cursor: 'pointer',
                    }}
                  >
                    <div style={{
                      width: '26px', height: '26px', borderRadius: '7px',
                      background: T.emerald.bg, color: T.emerald.text,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: '10px', fontWeight: 500,
                    }}>
                      {initials}
                    </div>
                    <span style={{ fontSize: '12px', fontWeight: 500, color: 'var(--color-text-primary)', maxWidth: '100px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {user.name}
                    </span>
                    <ChevronDown size={12} color="var(--color-text-secondary)" />
                  </button>

                  {showUserMenu && (
                    <>
                      {/* Backdrop */}
                      <div style={{ position: 'fixed', inset: 0, zIndex: 49 }} onClick={() => setShowUserMenu(false)} />
                      {/* Dropdown */}
                      <div style={{
                        position: 'absolute', right: 0, top: 'calc(100% + 6px)',
                        background: 'var(--color-background-primary,#fff)',
                        border: '0.5px solid rgba(0,0,0,0.10)',
                        borderRadius: '12px', padding: '6px',
                        minWidth: '180px', zIndex: 50,
                        boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
                      }}>
                        {/* User info */}
                        <div style={{ padding: '8px 10px 10px', borderBottom: '0.5px solid rgba(0,0,0,0.06)', marginBottom: '4px' }}>
                          <p style={{ fontSize: '13px', fontWeight: 500, margin: '0 0 1px' }}>{user.name}</p>
                          <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)', margin: 0, textTransform: 'capitalize' }}>{user.role}</p>
                        </div>
                        {[
                          { icon: <User size={14} />, label: 'View profile', path: profileRoute },
                          { icon: user.role === 'entrepreneur' ? <Building2 size={14} /> : <CircleDollarSign size={14} />, label: 'Dashboard', path: dashboardRoute },
                        ].map((item, i) => (
                          <button
                            key={i}
                            onClick={() => { navigate(item.path); setShowUserMenu(false); }}
                            style={{
                              display: 'flex', alignItems: 'center', gap: '8px',
                              width: '100%', padding: '8px 10px', borderRadius: '7px',
                              border: 'none', background: 'none', cursor: 'pointer',
                              fontSize: '13px', color: 'var(--color-text-secondary)', textAlign: 'left',
                            }}
                            onMouseEnter={e => { e.currentTarget.style.background = 'var(--color-background-secondary,#f8f7f4)'; e.currentTarget.style.color = 'var(--color-text-primary)'; }}
                            onMouseLeave={e => { e.currentTarget.style.background = 'none'; e.currentTarget.style.color = 'var(--color-text-secondary)'; }}
                          >
                            {item.icon} {item.label}
                          </button>
                        ))}
                        <div style={{ borderTop: '0.5px solid rgba(0,0,0,0.06)', marginTop: '4px', paddingTop: '4px' }}>
                          <button
                            onClick={handleLogout}
                            style={{
                              display: 'flex', alignItems: 'center', gap: '8px',
                              width: '100%', padding: '8px 10px', borderRadius: '7px',
                              border: 'none', background: 'none', cursor: 'pointer',
                              fontSize: '13px', color: '#D85A30', textAlign: 'left',
                            }}
                            onMouseEnter={e => { e.currentTarget.style.background = '#FAECE7'; }}
                            onMouseLeave={e => { e.currentTarget.style.background = 'none'; }}
                          >
                            <LogOut size={14} /> Sign out
                          </button>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </>
            ) : (
              <div style={{ display: 'flex', gap: '8px' }}>
                <Link to="/login" style={{ textDecoration: 'none' }}>
                  <button style={{ padding: '7px 16px', border: '0.5px solid rgba(0,0,0,0.12)', borderRadius: '9px', background: 'var(--color-background-primary,#fff)', cursor: 'pointer', fontSize: '13px', color: 'var(--color-text-secondary)' }}>
                    Log in
                  </button>
                </Link>
                <Link to="/register" style={{ textDecoration: 'none' }}>
                  <button style={{ padding: '7px 16px', border: 'none', borderRadius: '9px', background: '#1D9E75', color: '#fff', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>
                    Sign up
                  </button>
                </Link>
              </div>
            )}

            {/* Mobile hamburger */}
            <button
              onClick={() => setIsMenuOpen(p => !p)}
              style={{
                display: 'none',
                width: '34px', height: '34px', borderRadius: '8px',
                border: '0.5px solid rgba(0,0,0,0.10)',
                background: 'var(--color-background-primary,#fff)',
                cursor: 'pointer', alignItems: 'center', justifyContent: 'center',
                color: 'var(--color-text-secondary)',
              }}
              className="mobile-menu-btn"
            >
              {isMenuOpen ? <X size={16} /> : <Menu size={16} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div style={{
          borderTop: '0.5px solid rgba(0,0,0,0.07)',
          background: 'var(--color-background-primary,#fff)',
          padding: '8px 16px 16px',
        }}>
          {user ? (
            <>
              {/* User info */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 0 12px', borderBottom: '0.5px solid rgba(0,0,0,0.07)', marginBottom: '8px' }}>
                <div style={{ width: '34px', height: '34px', borderRadius: '9px', background: T.emerald.bg, color: T.emerald.text, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px', fontWeight: 500 }}>
                  {initials}
                </div>
                <div>
                  <p style={{ fontSize: '13px', fontWeight: 500, margin: 0 }}>{user.name}</p>
                  <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)', margin: 0, textTransform: 'capitalize' }}>{user.role}</p>
                </div>
              </div>

              {/* Nav links */}
              {[...navLinks, { icon: <User size={15} />, text: 'Profile', path: profileRoute }].map((link, i) => (
                <button
                  key={i}
                  onClick={() => { navigate(link.path); setIsMenuOpen(false); }}
                  style={{
                    display: 'flex', alignItems: 'center', gap: '9px',
                    width: '100%', padding: '10px 12px', borderRadius: '9px',
                    border: 'none', background: 'none', cursor: 'pointer',
                    fontSize: '13px', color: 'var(--color-text-secondary)', textAlign: 'left', marginBottom: '2px',
                  }}
                  onMouseEnter={e => { e.currentTarget.style.background = 'var(--color-background-secondary,#f8f7f4)'; e.currentTarget.style.color = 'var(--color-text-primary)'; }}
                  onMouseLeave={e => { e.currentTarget.style.background = 'none'; e.currentTarget.style.color = 'var(--color-text-secondary)'; }}
                >
                  {link.icon} {link.text}
                </button>
              ))}

              <div style={{ borderTop: '0.5px solid rgba(0,0,0,0.07)', marginTop: '8px', paddingTop: '8px' }}>
                <button
                  onClick={handleLogout}
                  style={{
                    display: 'flex', alignItems: 'center', gap: '9px',
                    width: '100%', padding: '10px 12px', borderRadius: '9px',
                    border: 'none', background: 'none', cursor: 'pointer',
                    fontSize: '13px', color: '#D85A30', textAlign: 'left',
                  }}
                >
                  <LogOut size={15} /> Sign out
                </button>
              </div>
            </>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', padding: '8px 0' }}>
              <Link to="/login" style={{ textDecoration: 'none' }} onClick={() => setIsMenuOpen(false)}>
                <button style={{ width: '100%', padding: '10px', border: '0.5px solid rgba(0,0,0,0.12)', borderRadius: '9px', background: 'none', cursor: 'pointer', fontSize: '13px', color: 'var(--color-text-secondary)' }}>
                  Log in
                </button>
              </Link>
              <Link to="/register" style={{ textDecoration: 'none' }} onClick={() => setIsMenuOpen(false)}>
                <button style={{ width: '100%', padding: '10px', border: 'none', borderRadius: '9px', background: '#1D9E75', color: '#fff', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>
                  Sign up
                </button>
              </Link>
            </div>
          )}
        </div>
      )}

      <style>{`
        @media (min-width: 768px) {
          .desktop-nav { display: flex !important; }
          .mobile-menu-btn { display: none !important; }
        }
        @media (max-width: 767px) {
          .desktop-nav { display: none !important; }
          .mobile-menu-btn { display: flex !important; }
        }
      `}</style>
    </nav>
  );
};