import React from 'react';
import { formatDistanceToNow } from 'date-fns';
import { Message } from '../../types';
import { findUserById } from '../../data/users';

interface ChatMessageProps {
  message: Message;
  isCurrentUser: boolean;
}

const avatarColors = [
  { bg: '#EAF3DE', text: '#0F6E56' },
  { bg: '#EEEDFE', text: '#534AB7' },
  { bg: '#FAEEDA', text: '#854F0B' },
  { bg: '#FAECE7', text: '#993C1D' },
];

const getAv = (name: string) => avatarColors[(name.charCodeAt(0) + (name.charCodeAt(1) || 0)) % avatarColors.length];
const getInitials = (name: string) => name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, isCurrentUser }) => {
  const user = findUserById(message.senderId);
  if (!user) return null;

  const av = getAv(user.name);
  const initials = getInitials(user.name);
  const timeAgo = formatDistanceToNow(new Date(message.timestamp), { addSuffix: true });

  return (
    <div style={{
      display: 'flex',
      justifyContent: isCurrentUser ? 'flex-end' : 'flex-start',
      alignItems: 'flex-end',
      gap: '8px',
      marginBottom: '2px',
    }}>
      {/* Other user avatar */}
      {!isCurrentUser && (
        <div style={{
          width: '28px', height: '28px', borderRadius: '50%',
          background: av.bg, color: av.text,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: '10px', fontWeight: 500, flexShrink: 0,
        }}>
          {initials}
        </div>
      )}

      {/* Bubble + timestamp */}
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: isCurrentUser ? 'flex-end' : 'flex-start',
        maxWidth: '72%',
      }}>
        <div style={{
          padding: '8px 12px',
          borderRadius: isCurrentUser ? '12px 12px 3px 12px' : '12px 12px 12px 3px',
          background: isCurrentUser ? '#1D9E75' : 'var(--color-background-primary,#fff)',
          color: isCurrentUser ? '#fff' : 'var(--color-text-primary)',
          fontSize: '13px',
          lineHeight: 1.55,
          border: isCurrentUser ? 'none' : '0.5px solid rgba(0,0,0,0.08)',
          wordBreak: 'break-word',
        }}>
          {message.content}
        </div>
        <span style={{
          fontSize: '10px',
          color: 'var(--color-text-tertiary,#b0b0b0)',
          marginTop: '3px',
        }}>
          {timeAgo}
        </span>
      </div>

      {/* Current user avatar */}
      {isCurrentUser && (
        <div style={{
          width: '28px', height: '28px', borderRadius: '50%',
          background: '#EAF3DE', color: '#0F6E56',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: '10px', fontWeight: 500, flexShrink: 0,
        }}>
          {initials}
        </div>
      )}
    </div>
  );
};