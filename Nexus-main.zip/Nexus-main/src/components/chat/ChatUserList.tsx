import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { ChatConversation } from '../../types';
import { findUserById } from '../../data/users';
import { useAuth } from '../../context/AuthContext';

interface ChatUserListProps {
  conversations: ChatConversation[];
}

const avatarColors = [
  { bg: '#EAF3DE', text: '#0F6E56' },
  { bg: '#EEEDFE', text: '#534AB7' },
  { bg: '#FAEEDA', text: '#854F0B' },
  { bg: '#FAECE7', text: '#993C1D' },
  { bg: '#FBEAF0', text: '#993556' },
];

const getAv = (name: string) => avatarColors[(name.charCodeAt(0) + (name.charCodeAt(1) || 0)) % avatarColors.length];
const getInitials = (name: string) => name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();

export const ChatUserList: React.FC<ChatUserListProps> = ({ conversations }) => {
  const navigate = useNavigate();
  const { userId: activeUserId } = useParams<{ userId: string }>();
  const { user: currentUser } = useAuth();

  if (!currentUser) return null;

  if (conversations.length === 0) {
    return (
      <div style={{ padding: '40px 20px', textAlign: 'center' }}>
        <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>No conversations yet</p>
      </div>
    );
  }

  return (
    <div style={{ overflowY: 'auto', fontFamily: 'var(--font-sans,system-ui,sans-serif)' }}>
      {conversations.map(conversation => {
        const otherParticipantId = conversation.participants.find(id => id !== currentUser.id);
        if (!otherParticipantId) return null;

        const otherUser = findUserById(otherParticipantId);
        if (!otherUser) return null;

        const lastMessage = conversation.lastMessage;
        const isActive = activeUserId === otherParticipantId;
        const hasUnread = lastMessage && !lastMessage.isRead && lastMessage.senderId !== currentUser.id;
        const av = getAv(otherUser.name);
        const initials = getInitials(otherUser.name);

        return (
          <div
            key={conversation.id}
            onClick={() => navigate(`/chat/${otherUser.id}`)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              padding: '12px 20px',
              cursor: 'pointer',
              background: isActive ? '#EAF3DE' : 'transparent',
              borderLeft: `3px solid ${isActive ? '#1D9E75' : 'transparent'}`,
              borderBottom: '0.5px solid rgba(0,0,0,0.04)',
              transition: 'all 0.12s',
            }}
            onMouseEnter={e => {
              if (!isActive) (e.currentTarget as HTMLElement).style.background = 'var(--color-background-secondary,#f8f7f4)';
            }}
            onMouseLeave={e => {
              if (!isActive) (e.currentTarget as HTMLElement).style.background = 'transparent';
            }}
          >
            {/* Avatar with online indicator */}
            <div style={{ position: 'relative', flexShrink: 0 }}>
              <div style={{
                width: '38px', height: '38px', borderRadius: '50%',
                background: av.bg, color: av.text,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '12px', fontWeight: 500,
              }}>
                {initials}
              </div>
              {otherUser.isOnline && (
                <span style={{
                  position: 'absolute', bottom: '0px', right: '0px',
                  width: '9px', height: '9px', borderRadius: '50%',
                  background: '#1D9E75', border: '1.5px solid var(--color-background-primary,#fff)',
                }} />
              )}
            </div>

            {/* Content */}
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '2px' }}>
                <span style={{
                  fontSize: '13px',
                  fontWeight: hasUnread ? 500 : 400,
                  color: 'var(--color-text-primary)',
                  overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                }}>
                  {otherUser.name}
                </span>
                {lastMessage && (
                  <span style={{ fontSize: '10px', color: 'var(--color-text-tertiary,#b0b0b0)', flexShrink: 0, marginLeft: '6px' }}>
                    {formatDistanceToNow(new Date(lastMessage.timestamp), { addSuffix: false })}
                  </span>
                )}
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                {lastMessage && (
                  <p style={{
                    fontSize: '12px',
                    color: hasUnread ? 'var(--color-text-primary)' : 'var(--color-text-secondary)',
                    fontWeight: hasUnread ? 500 : 400,
                    overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                    margin: 0, flex: 1,
                  }}>
                    {lastMessage.senderId === currentUser.id ? 'You: ' : ''}
                    {lastMessage.content}
                  </p>
                )}
                {hasUnread && (
                  <span style={{
                    width: '7px', height: '7px', borderRadius: '50%',
                    background: '#1D9E75', flexShrink: 0, marginLeft: '6px',
                  }} />
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};