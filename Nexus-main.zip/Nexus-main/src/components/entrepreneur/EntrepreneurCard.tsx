import React from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageCircle, ExternalLink, Users, DollarSign, MapPin } from 'lucide-react';
import { Entrepreneur } from '../../types';

const avatarColors = [
  { bg: '#EAF3DE', text: '#0F6E56' },
  { bg: '#EEEDFE', text: '#534AB7' },
  { bg: '#FAEEDA', text: '#854F0B' },
  { bg: '#FAECE7', text: '#993C1D' },
];

const getAv = (name: string) => avatarColors[(name.charCodeAt(0) + (name.charCodeAt(1) || 0)) % 4];
const getInitials = (name: string) => name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();

const industryColors: Record<string, { bg: string; text: string }> = {
  FinTech:    { bg: '#EEEDFE', text: '#534AB7' },
  CleanTech:  { bg: '#EAF3DE', text: '#0F6E56' },
  HealthTech: { bg: '#FAEEDA', text: '#854F0B' },
  'AI/ML':    { bg: '#FAECE7', text: '#993C1D' },
  SaaS:       { bg: '#FBEAF0', text: '#993556' },
};

const getIndustryColor = (ind: string) => industryColors[ind] || { bg: '#EAF3DE', text: '#0F6E56' };

interface EntrepreneurCardProps {
  entrepreneur: Entrepreneur;
  showActions?: boolean;
}

export const EntrepreneurCard: React.FC<EntrepreneurCardProps> = ({
  entrepreneur,
  showActions = true,
}) => {
  const navigate = useNavigate();
  const av = getAv(entrepreneur.name);
  const initials = getInitials(entrepreneur.name);
  const ic = getIndustryColor(entrepreneur.industry);

  return (
    <div
      onClick={() => navigate(`/profile/entrepreneur/${entrepreneur.id}`)}
      style={{
        background: 'var(--color-background-primary,#fff)',
        border: '0.5px solid rgba(0,0,0,0.08)',
        borderRadius: '14px',
        overflow: 'hidden',
        cursor: 'pointer',
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        transition: 'border-color 0.15s, transform 0.15s',
        fontFamily: 'var(--font-sans,system-ui,sans-serif)',
      }}
      onMouseEnter={e => {
        (e.currentTarget as HTMLElement).style.borderColor = '#1D9E75';
        (e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)';
      }}
      onMouseLeave={e => {
        (e.currentTarget as HTMLElement).style.borderColor = 'rgba(0,0,0,0.08)';
        (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
      }}
    >
      {/* Accent top */}
      <div style={{ height: '2px', background: '#1D9E75' }} />

      {/* Body */}
      <div style={{ padding: '18px 18px 14px', flex: 1 }}>
        {/* Header row */}
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px', marginBottom: '12px' }}>
          <div style={{ position: 'relative', flexShrink: 0 }}>
            <div style={{
              width: '44px', height: '44px', borderRadius: '11px',
              background: av.bg, color: av.text,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '14px', fontWeight: 500,
            }}>
              {initials}
            </div>
            {entrepreneur.isOnline && (
              <span style={{
                position: 'absolute', bottom: '1px', right: '1px',
                width: '9px', height: '9px', borderRadius: '50%',
                background: '#1D9E75', border: '1.5px solid var(--color-background-primary,#fff)',
              }} />
            )}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <h3 style={{ fontSize: '14px', fontWeight: 500, margin: '0 0 2px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: 'var(--color-text-primary)' }}>
              {entrepreneur.name}
            </h3>
            <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: '0 0 8px' }}>
              {entrepreneur.startupName}
            </p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px' }}>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: '3px', padding: '3px 8px', borderRadius: '20px', fontSize: '10px', fontWeight: 500, background: ic.bg, color: ic.text }}>
                {entrepreneur.industry}
              </span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: '3px', padding: '3px 8px', borderRadius: '20px', fontSize: '10px', color: 'var(--color-text-secondary)', background: 'var(--color-background-secondary,#f5f4f0)', border: '0.5px solid rgba(0,0,0,0.07)' }}>
                <MapPin size={9} /> {entrepreneur.location}
              </span>
            </div>
          </div>
        </div>

        {/* Pitch */}
        <div style={{ marginBottom: '12px' }}>
          <p style={{ fontSize: '11px', fontWeight: 500, color: 'var(--color-text-secondary)', margin: '0 0 4px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Pitch</p>
          <p style={{
            fontSize: '12px', color: 'var(--color-text-secondary)', lineHeight: 1.6, margin: 0,
            display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden',
          }}>
            {entrepreneur.pitchSummary}
          </p>
        </div>

        {/* Stats row */}
        <div style={{ display: 'flex', gap: '10px' }}>
          <div style={{ flex: 1, padding: '8px 10px', background: 'var(--color-background-secondary,#f8f7f4)', borderRadius: '8px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '4px', marginBottom: '2px' }}>
              <DollarSign size={11} color="#1D9E75" />
              <span style={{ fontSize: '10px', color: 'var(--color-text-secondary)', fontWeight: 500 }}>Funding</span>
            </div>
            <p style={{ fontSize: '12px', fontWeight: 500, margin: 0, color: 'var(--color-text-primary)' }}>{entrepreneur.fundingNeeded}</p>
          </div>
          <div style={{ flex: 1, padding: '8px 10px', background: 'var(--color-background-secondary,#f8f7f4)', borderRadius: '8px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '4px', marginBottom: '2px' }}>
              <Users size={11} color="#7F77DD" />
              <span style={{ fontSize: '10px', color: 'var(--color-text-secondary)', fontWeight: 500 }}>Team</span>
            </div>
            <p style={{ fontSize: '12px', fontWeight: 500, margin: 0, color: 'var(--color-text-primary)' }}>{entrepreneur.teamSize} people</p>
          </div>
        </div>
      </div>

      {/* Footer actions */}
      {showActions && (
        <div style={{
          padding: '10px 18px',
          borderTop: '0.5px solid rgba(0,0,0,0.06)',
          background: 'var(--color-background-secondary,#f8f7f4)',
          display: 'flex',
          justifyContent: 'space-between',
          gap: '8px',
        }}>
          <button
            onClick={e => { e.stopPropagation(); navigate(`/chat/${entrepreneur.id}`); }}
            style={{
              display: 'flex', alignItems: 'center', gap: '5px',
              padding: '7px 12px', borderRadius: '8px',
              border: '0.5px solid rgba(0,0,0,0.12)',
              background: 'var(--color-background-primary,#fff)',
              color: 'var(--color-text-secondary)',
              cursor: 'pointer', fontSize: '12px',
            }}
          >
            <MessageCircle size={13} /> Message
          </button>
          <button
            onClick={e => { e.stopPropagation(); navigate(`/profile/entrepreneur/${entrepreneur.id}`); }}
            style={{
              display: 'flex', alignItems: 'center', gap: '5px',
              padding: '7px 12px', borderRadius: '8px',
              border: 'none', background: '#1D9E75', color: '#fff',
              cursor: 'pointer', fontSize: '12px', fontWeight: 500,
            }}
          >
            View profile <ExternalLink size={11} />
          </button>
        </div>
      )}
    </div>
  );
};