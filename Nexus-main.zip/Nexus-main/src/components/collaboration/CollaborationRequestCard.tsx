import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, X, MessageCircle, ExternalLink, Clock } from 'lucide-react';
import { CollaborationRequest } from '../../types';
import { findUserById } from '../../data/users';
import { updateRequestStatus } from '../../data/collaborationRequests';
import { formatDistanceToNow } from 'date-fns';

interface CollaborationRequestCardProps {
  request: CollaborationRequest;
  onStatusUpdate?: (requestId: string, status: 'accepted' | 'rejected') => void;
}

const avatarColors = [
  { bg: '#EAF3DE', text: '#0F6E56' },
  { bg: '#EEEDFE', text: '#534AB7' },
  { bg: '#FAEEDA', text: '#854F0B' },
  { bg: '#FAECE7', text: '#993C1D' },
];

const statusConf = {
  pending:  { bg: '#FAEEDA', text: '#854F0B', dot: '#BA7517', label: 'Pending' },
  accepted: { bg: '#EAF3DE', text: '#0F6E56', dot: '#1D9E75', label: 'Accepted' },
  rejected: { bg: '#FAECE7', text: '#993C1D', dot: '#D85A30', label: 'Declined' },
};

const getAv = (name: string) => avatarColors[(name.charCodeAt(0) + (name.charCodeAt(1) || 0)) % 4];
const getInitials = (name: string) => name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();

export const CollaborationRequestCard: React.FC<CollaborationRequestCardProps> = ({
  request,
  onStatusUpdate,
}) => {
  const navigate = useNavigate();
  const investor = findUserById(request.investorId);
  if (!investor) return null;

  const av = getAv(investor.name);
  const initials = getInitials(investor.name);
  const sc = statusConf[request.status as keyof typeof statusConf] || statusConf.pending;
  const timeAgo = formatDistanceToNow(new Date(request.createdAt), { addSuffix: true });

  const handleAccept = () => {
    updateRequestStatus(request.id, 'accepted');
    onStatusUpdate?.(request.id, 'accepted');
  };

  const handleReject = () => {
    updateRequestStatus(request.id, 'rejected');
    onStatusUpdate?.(request.id, 'rejected');
  };

  return (
    <div style={{
      background: 'var(--color-background-primary,#fff)',
      border: '0.5px solid rgba(0,0,0,0.08)',
      borderRadius: '12px',
      overflow: 'hidden',
      marginBottom: '8px',
    }}>
      {/* Card body */}
      <div style={{ padding: '14px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: '10px', flex: 1, minWidth: 0 }}>
            {/* Avatar */}
            <div style={{ position: 'relative', flexShrink: 0 }}>
              <div style={{
                width: '36px', height: '36px', borderRadius: '50%',
                background: av.bg, color: av.text,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '12px', fontWeight: 500,
              }}>
                {initials}
              </div>
              {investor.isOnline && (
                <span style={{
                  position: 'absolute', bottom: '0px', right: '0px',
                  width: '9px', height: '9px', borderRadius: '50%',
                  background: '#1D9E75', border: '1.5px solid var(--color-background-primary,#fff)',
                }} />
              )}
            </div>

            {/* Info */}
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '2px' }}>
                <span style={{ fontSize: '13px', fontWeight: 500, color: 'var(--color-text-primary)' }}>
                  {investor.name}
                </span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                <Clock size={10} color="var(--color-text-tertiary,#b0b0b0)" />
                <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>{timeAgo}</span>
              </div>
            </div>
          </div>

          {/* Status badge */}
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: '4px',
            padding: '3px 9px', borderRadius: '20px',
            fontSize: '10px', fontWeight: 500,
            background: sc.bg, color: sc.text,
            flexShrink: 0,
          }}>
            <span style={{ width: '5px', height: '5px', borderRadius: '50%', background: sc.dot }} />
            {sc.label}
          </span>
        </div>

        {/* Message */}
        <p style={{
          fontSize: '12px',
          color: 'var(--color-text-secondary)',
          lineHeight: 1.6,
          margin: '10px 0 0',
          padding: '10px 12px',
          background: 'var(--color-background-secondary,#f8f7f4)',
          borderRadius: '8px',
          border: '0.5px solid rgba(0,0,0,0.06)',
        }}>
          {request.message}
        </p>
      </div>

      {/* Card footer actions */}
      <div style={{
        padding: '10px 16px',
        borderTop: '0.5px solid rgba(0,0,0,0.06)',
        background: 'var(--color-background-secondary,#f8f7f4)',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        gap: '8px',
      }}>
        {request.status === 'pending' ? (
          <>
            <div style={{ display: 'flex', gap: '6px' }}>
              <button
                onClick={handleReject}
                style={{
                  display: 'flex', alignItems: 'center', gap: '5px',
                  padding: '6px 12px', borderRadius: '8px',
                  border: '0.5px solid #F5C4B3',
                  background: '#FAECE7', color: '#993C1D',
                  cursor: 'pointer', fontSize: '12px', fontWeight: 500,
                }}
              >
                <X size={12} /> Decline
              </button>
              <button
                onClick={handleAccept}
                style={{
                  display: 'flex', alignItems: 'center', gap: '5px',
                  padding: '6px 12px', borderRadius: '8px',
                  border: 'none', background: '#1D9E75', color: '#fff',
                  cursor: 'pointer', fontSize: '12px', fontWeight: 500,
                }}
              >
                <Check size={12} /> Accept
              </button>
            </div>
            <button
              onClick={() => navigate(`/chat/${investor.id}`)}
              style={{
                display: 'flex', alignItems: 'center', gap: '5px',
                padding: '6px 12px', borderRadius: '8px',
                border: '0.5px solid rgba(0,0,0,0.12)',
                background: 'var(--color-background-primary,#fff)',
                color: 'var(--color-text-secondary)',
                cursor: 'pointer', fontSize: '12px',
              }}
            >
              <MessageCircle size={12} /> Message
            </button>
          </>
        ) : (
          <>
            <button
              onClick={() => navigate(`/chat/${investor.id}`)}
              style={{
                display: 'flex', alignItems: 'center', gap: '5px',
                padding: '6px 12px', borderRadius: '8px',
                border: '0.5px solid rgba(0,0,0,0.12)',
                background: 'var(--color-background-primary,#fff)',
                color: 'var(--color-text-secondary)',
                cursor: 'pointer', fontSize: '12px',
              }}
            >
              <MessageCircle size={12} /> Message
            </button>
            <button
              onClick={() => navigate(`/profile/investor/${investor.id}`)}
              style={{
                display: 'flex', alignItems: 'center', gap: '5px',
                padding: '6px 12px', borderRadius: '8px',
                border: 'none', background: '#1D9E75', color: '#fff',
                cursor: 'pointer', fontSize: '12px', fontWeight: 500,
              }}
            >
              View profile <ExternalLink size={11} />
            </button>
          </>
        )}
      </div>
    </div>
  );
};