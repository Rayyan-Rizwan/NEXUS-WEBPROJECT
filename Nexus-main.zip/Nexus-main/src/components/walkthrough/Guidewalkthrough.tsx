import React, { useState, useEffect } from 'react';
import { X, ChevronRight, ChevronLeft, Check, Zap, MapPin } from 'lucide-react';

interface Step {
  id: string;
  title: string;
  description: string;
  target: string;
  placement: 'bottom' | 'top' | 'left' | 'right';
  icon: React.ReactNode;
}

interface WalkthroughProps {
  onComplete?: () => void;
  onSkip?: () => void;
}

const STEPS: Step[] = [
  {
    id: 'dashboard',
    title: 'Welcome to Nexus',
    description: 'This is your command center. Track your funding progress, connections, upcoming meetings, and key metrics all in one place.',
    target: 'dashboard',
    placement: 'bottom',
    icon: <Zap size={18} color="#1D9E75"/>,
  },
  {
    id: 'investors',
    title: 'Find investors',
    description: 'Browse our curated directory of verified investors. Filter by industry, stage, and investment range to find your perfect match.',
    target: 'investors',
    placement: 'right',
    icon: <span style={{fontSize:'16px'}}>💼</span>,
  },
  {
    id: 'documents',
    title: 'Document Chamber',
    description: 'Securely upload, preview, and e-sign your deal documents. Track every contract from Draft → In Review → Signed.',
    target: 'documents',
    placement: 'right',
    icon: <span style={{fontSize:'16px'}}>📄</span>,
  },
  {
    id: 'meetings',
    title: 'Meeting scheduler',
    description: 'Set your availability and let investors book time with you. Manage meeting requests and confirm with one click.',
    target: 'meetings',
    placement: 'right',
    icon: <span style={{fontSize:'16px'}}>📅</span>,
  },
  {
    id: 'video',
    title: 'Video calls',
    description: 'Start or join investor video calls directly on Nexus. Share your screen, toggle audio/video, and chat during calls.',
    target: 'video-call',
    placement: 'right',
    icon: <span style={{fontSize:'16px'}}>🎥</span>,
  },
  {
    id: 'payments',
    title: 'Payments & wallet',
    description: 'Track your investment wallet balance, manage deposits, withdrawals, and transfers. See full transaction history.',
    target: 'payments',
    placement: 'right',
    icon: <span style={{fontSize:'16px'}}>💰</span>,
  },
  {
    id: 'security',
    title: 'Security settings',
    description: 'Protect your account with a strong password and two-factor authentication. Manage active sessions and role permissions.',
    target: 'security',
    placement: 'right',
    icon: <span style={{fontSize:'16px'}}>🔐</span>,
  },
];

export const GuidedWalkthrough: React.FC<WalkthroughProps> = ({ onComplete, onSkip }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [visible, setVisible] = useState(true);
  const [animating, setAnimating] = useState(false);

  const step = STEPS[currentStep];
  const isFirst = currentStep === 0;
  const isLast = currentStep === STEPS.length - 1;
  const progress = ((currentStep + 1) / STEPS.length) * 100;

  const goTo = (idx: number) => {
    setAnimating(true);
    setTimeout(() => {
      setCurrentStep(idx);
      setAnimating(false);
    }, 180);
  };

  const handleComplete = () => {
    setVisible(false);
    onComplete?.();
  };

  const handleSkip = () => {
    setVisible(false);
    onSkip?.();
  };

  if (!visible) return null;

  return (
    <>
      {/* Backdrop */}
      <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 998, backdropFilter: 'blur(1px)' }} onClick={handleSkip} />

      {/* Modal */}
      <div style={{
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        zIndex: 999,
        width: '460px',
        background: 'var(--color-background-primary,#fff)',
        borderRadius: '18px',
        overflow: 'hidden',
        border: '0.5px solid rgba(0,0,0,0.10)',
        fontFamily: 'var(--font-sans,system-ui,sans-serif)',
        opacity: animating ? 0 : 1,
        transition: 'opacity 0.18s',
      }}>
        {/* Progress bar */}
        <div style={{ height: '3px', background: 'rgba(0,0,0,0.06)' }}>
          <div style={{ height: '100%', width: `${progress}%`, background: '#1D9E75', borderRadius: '3px', transition: 'width 0.35s ease' }} />
        </div>

        {/* Header */}
        <div style={{ padding: '20px 24px 0', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{ width: '34px', height: '34px', borderRadius: '9px', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              {step.icon}
            </div>
            <span style={{ fontSize: '11px', fontWeight: 500, color: '#1D9E75', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
              Step {currentStep + 1} of {STEPS.length}
            </span>
          </div>
          <button onClick={handleSkip} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--color-text-tertiary,#b0b0b0)', display: 'flex', alignItems: 'center', padding: '2px' }}>
            <X size={16}/>
          </button>
        </div>

        {/* Content */}
        <div style={{ padding: '16px 24px 24px' }}>
          <h2 style={{ fontSize: '20px', fontWeight: 500, margin: '0 0 10px', letterSpacing: '-0.01em' }}>{step.title}</h2>
          <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)', margin: '0 0 24px', lineHeight: 1.7 }}>{step.description}</p>

          {/* Step dots */}
          <div style={{ display: 'flex', gap: '6px', marginBottom: '20px' }}>
            {STEPS.map((_, i) => (
              <button key={i} onClick={() => goTo(i)}
                style={{ height: '6px', width: i === currentStep ? '20px' : '6px', borderRadius: '3px', background: i === currentStep ? '#1D9E75' : i < currentStep ? '#C0DD97' : 'rgba(0,0,0,0.08)', border: 'none', cursor: 'pointer', padding: 0, transition: 'all 0.25s' }}
              />
            ))}
          </div>

          {/* Navigation */}
          <div style={{ display: 'flex', gap: '8px' }}>
            {!isFirst && (
              <button onClick={() => goTo(currentStep - 1)}
                style={{ display: 'flex', alignItems: 'center', gap: '5px', padding: '9px 16px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '9px', background: 'none', cursor: 'pointer', fontSize: '13px', color: 'var(--color-text-secondary)' }}>
                <ChevronLeft size={14}/> Back
              </button>
            )}
            <button onClick={handleSkip}
              style={{ padding: '9px 16px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '9px', background: 'none', cursor: 'pointer', fontSize: '13px', color: 'var(--color-text-secondary)' }}>
              Skip tour
            </button>
            <button onClick={isLast ? handleComplete : () => goTo(currentStep + 1)}
              style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '9px 20px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>
              {isLast ? <><Check size={14}/> Complete tour</> : <>Next <ChevronRight size={14}/></>}
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

// ── Tooltip component for individual element hints ──────────────────────────

interface TooltipProps {
  text: string;
  children: React.ReactElement;
  placement?: 'top' | 'bottom' | 'left' | 'right';
}

export const Tooltip: React.FC<TooltipProps> = ({ text, children, placement = 'top' }) => {
  const [show, setShow] = useState(false);

  const tipStyle: React.CSSProperties = {
    position: 'absolute',
    background: '#1A1A1A',
    color: '#fff',
    fontSize: '11px',
    fontWeight: 400,
    padding: '5px 10px',
    borderRadius: '7px',
    whiteSpace: 'nowrap',
    pointerEvents: 'none',
    zIndex: 100,
    lineHeight: 1.4,
    fontFamily: 'var(--font-sans,system-ui,sans-serif)',
    ...(placement === 'top'    && { bottom: 'calc(100% + 7px)', left: '50%', transform: 'translateX(-50%)' }),
    ...(placement === 'bottom' && { top: 'calc(100% + 7px)',    left: '50%', transform: 'translateX(-50%)' }),
    ...(placement === 'left'   && { right: 'calc(100% + 7px)',  top: '50%',  transform: 'translateY(-50%)' }),
    ...(placement === 'right'  && { left: 'calc(100% + 7px)',   top: '50%',  transform: 'translateY(-50%)' }),
  };

  return (
    <div style={{ position: 'relative', display: 'inline-flex' }}
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}>
      {children}
      {show && <div style={tipStyle}>{text}</div>}
    </div>
  );
};

// ── Walkthrough trigger button ───────────────────────────────────────────────

interface WalkthroughTriggerProps {
  onStart: () => void;
}

export const WalkthroughTrigger: React.FC<WalkthroughTriggerProps> = ({ onStart }) => (
  <button onClick={onStart}
    style={{ display: 'flex', alignItems: 'center', gap: '7px', padding: '8px 16px', background: '#EAF3DE', color: '#0F6E56', border: '0.5px solid #C0DD97', borderRadius: '20px', cursor: 'pointer', fontSize: '12px', fontWeight: 500, fontFamily: 'var(--font-sans,system-ui,sans-serif)' }}>
    <MapPin size={13}/> Take a tour
  </button>
);