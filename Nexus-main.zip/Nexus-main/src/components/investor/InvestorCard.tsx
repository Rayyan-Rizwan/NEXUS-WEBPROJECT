import React from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageCircle, ExternalLink, TrendingUp } from 'lucide-react';
import { Investor } from '../../types';

const avatarColors = [
  { bg: '#EEEDFE', text: '#534AB7' },
  { bg: '#EAF3DE', text: '#0F6E56' },
  { bg: '#FAEEDA', text: '#854F0B' },
  { bg: '#FAECE7', text: '#993C1D' },
];

const getAv = (name: string) => avatarColors[(name.charCodeAt(0) + (name.charCodeAt(1) || 0)) % 4];
const getInitials = (name: string) => name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();

const stageColors: Record<string, { bg: string; text: string }> = {
  'Pre-seed': { bg: '#FAEEDA', text: '#854F0B' },
  'Seed':     { bg: '#EAF3DE', text: '#0F6E56' },
  'Series A': { bg: '#EEEDFE', text: '#534AB7' },
  'Series B': { bg: '#FAECE7', text: '#993C1D' },
  'Growth':   { bg: '#FBEAF0', text: '#993556' },
};

const getStageColor = (s: string) => stageColors[s] || { bg: '#EAF3DE', text: '#0F6E56' };

interface InvestorCardProps {
  investor: Investor;
  showActions?: boolean;
}

export const InvestorCard: React.FC<InvestorCardProps> = ({
  investor,
  showActions = true,
}) => {
  const navigate = useNavigate();
  const av = getAv(investor.name);
  const initials = getInitials(investor.name);

  return (
    <div
      onClick={() => navigate(`/profile/investor/${investor.id}`)}
      style={{
        background: 'var(--color-background-primary,#fff)',
        border: '0.5px solid rgba(0,0,0,0.08)',
        borderRadius: '14px',
        overflow: 'hidden',
        cursor: 'pointer',
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        transition: 'border-color 0.15s, transform 0.15s',
        fontFamily: 'var(--font-sans,system-ui,sans-serif)',
      }}
      onMouseEnter={e => {
        (e.currentTarget as HTMLElement).style.borderColor = '#7F77DD';
        (e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)';
      }}
      onMouseLeave={e => {
        (e.currentTarget as HTMLElement).style.borderColor = 'rgba(0,0,0,0.08)';
        (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
      }}
    >
      {/* Violet accent top */}
      <div style={{ height: '2px', background: '#7F77DD' }} />

      {/* Body */}
      <div style={{ padding: '18px 18px 14px', flex: 1 }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px', marginBottom: '12px' }}>
          <div style={{ position: 'relative', flexShrink: 0 }}>
            <div style={{
              width: '44px', height: '44px', borderRadius: '11px',
              background: av.bg, color: av.text,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '14px', fontWeight: 500,
            }}>
              {initials}
            </div>
            {investor.isOnline && (
              <span style={{
                position: 'absolute', bottom: '1px', right: '1px',
                width: '9px', height: '9px', borderRadius: '50%',
                background: '#1D9E75', border: '1.5px solid var(--color-background-primary,#fff)',
              }} />
            )}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <h3 style={{ fontSize: '14px', fontWeight: 500, margin: '0 0 2px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: 'var(--color-text-primary)' }}>
              {investor.name}
            </h3>
            <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: '0 0 8px' }}>
              Investor · {investor.totalInvestments} investments
            </p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px' }}>
              {investor.investmentStage.slice(0, 2).map((stage: string, i: number) => {
                const sc = getStageColor(stage);
                return (
                  <span key={i} style={{ padding: '3px 8px', borderRadius: '20px', fontSize: '10px', fontWeight: 500, background: sc.bg, color: sc.text }}>
                    {stage}
                  </span>
                );
              })}
              {investor.investmentStage.length > 2 && (
                <span style={{ padding: '3px 8px', borderRadius: '20px', fontSize: '10px', color: 'var(--color-text-secondary)', background: 'var(--color-background-secondary,#f5f4f0)', border: '0.5px solid rgba(0,0,0,0.07)' }}>
                  +{investor.investmentStage.length - 2}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Interests */}
        <div style={{ marginBottom: '10px' }}>
          <p style={{ fontSize: '11px', fontWeight: 500, color: 'var(--color-text-secondary)', margin: '0 0 6px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Interests</p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px' }}>
            {investor.investmentInterests.slice(0, 3).map((interest: string, i: number) => (
              <span key={i} style={{ padding: '3px 8px', borderRadius: '20px', fontSize: '10px', fontWeight: 500, background: '#EAF3DE', color: '#0F6E56' }}>
                {interest}
              </span>
            ))}
            {investor.investmentInterests.length > 3 && (
              <span style={{ padding: '3px 8px', borderRadius: '20px', fontSize: '10px', color: 'var(--color-text-secondary)', background: 'var(--color-background-secondary,#f5f4f0)', border: '0.5px solid rgba(0,0,0,0.07)' }}>
                +{investor.investmentInterests.length - 3}
              </span>
            )}
          </div>
        </div>

        {/* Bio */}
        <p style={{
          fontSize: '12px', color: 'var(--color-text-secondary)', lineHeight: 1.6,
          margin: '0 0 12px',
          display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden',
        }}>
          {investor.bio}
        </p>

        {/* Investment range */}
        <div style={{ padding: '8px 10px', background: 'var(--color-background-secondary,#f8f7f4)', borderRadius: '8px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '4px', marginBottom: '2px' }}>
            <TrendingUp size={11} color="#7F77DD" />
            <span style={{ fontSize: '10px', color: 'var(--color-text-secondary)', fontWeight: 500 }}>Investment range</span>
          </div>
          <p style={{ fontSize: '12px', fontWeight: 500, margin: 0, color: 'var(--color-text-primary)' }}>
            {investor.minimumInvestment} – {investor.maximumInvestment}
          </p>
        </div>
      </div>

      {/* Footer */}
      {showActions && (
        <div style={{
          padding: '10px 18px',
          borderTop: '0.5px solid rgba(0,0,0,0.06)',
          background: 'var(--color-background-secondary,#f8f7f4)',
          display: 'flex',
          justifyContent: 'space-between',
          gap: '8px',
        }}>
          <button
            onClick={e => { e.stopPropagation(); navigate(`/chat/${investor.id}`); }}
            style={{
              display: 'flex', alignItems: 'center', gap: '5px',
              padding: '7px 12px', borderRadius: '8px',
              border: '0.5px solid rgba(0,0,0,0.12)',
              background: 'var(--color-background-primary,#fff)',
              color: 'var(--color-text-secondary)',
              cursor: 'pointer', fontSize: '12px',
            }}
          >
            <MessageCircle size={13} /> Message
          </button>
          <button
            onClick={e => { e.stopPropagation(); navigate(`/profile/investor/${investor.id}`); }}
            style={{
              display: 'flex', alignItems: 'center', gap: '5px',
              padding: '7px 12px', borderRadius: '8px',
              border: 'none', background: '#7F77DD', color: '#fff',
              cursor: 'pointer', fontSize: '12px', fontWeight: 500,
            }}
          >
            View profile <ExternalLink size={11} />
          </button>
        </div>
      )}
    </div>
  );
};