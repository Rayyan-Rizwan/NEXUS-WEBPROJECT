import React, { useState } from 'react';
import { Bell, MessageCircle, UserPlus, DollarSign, Check } from 'lucide-react';

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD' },
  amber:   { bg: '#FAEEDA', text: '#854F0B', fill: '#BA7517' },
  coral:   { bg: '#FAECE7', text: '#993C1D', fill: '#D85A30' },
};

interface Notification {
  id: number;
  type: 'message' | 'connection' | 'investment' | 'general';
  user: { name: string; avatar: string; initials: string; colorIdx: number };
  content: string;
  time: string;
  unread: boolean;
}

const avatarColors = [T.emerald, T.violet, T.amber, T.coral];

const INITIAL_NOTIFICATIONS: Notification[] = [
  {
    id: 1, type: 'message',
    user: { name: 'Sarah Johnson', avatar: '', initials: 'SJ', colorIdx: 0 },
    content: 'sent you a message about your startup pitch deck',
    time: '5 minutes ago', unread: true,
  },
  {
    id: 2, type: 'connection',
    user: { name: 'Michael Rodriguez', avatar: '', initials: 'MR', colorIdx: 1 },
    content: 'accepted your connection request',
    time: '2 hours ago', unread: true,
  },
  {
    id: 3, type: 'investment',
    user: { name: 'Jennifer Lee', avatar: '', initials: 'JL', colorIdx: 2 },
    content: 'showed interest in investing in your startup',
    time: '1 day ago', unread: false,
  },
  {
    id: 4, type: 'message',
    user: { name: 'David Chen', avatar: '', initials: 'DC', colorIdx: 3 },
    content: 'replied to your collaboration request',
    time: '2 days ago', unread: false,
  },
];

const typeConf = {
  message:    { label: 'Message',    color: 'violet' as const, icon: (c: typeof T.violet) => <MessageCircle size={14} color={c.fill} /> },
  connection: { label: 'Connection', color: 'emerald' as const, icon: (c: typeof T.emerald) => <UserPlus size={14} color={c.fill} /> },
  investment: { label: 'Investment', color: 'amber' as const, icon: (c: typeof T.amber) => <DollarSign size={14} color={c.fill} /> },
  general:    { label: 'General',    color: 'coral' as const, icon: (c: typeof T.coral) => <Bell size={14} color={c.fill} /> },
};

const baseCard: React.CSSProperties = {
  background: 'var(--color-background-primary,#fff)',
  border: '0.5px solid rgba(0,0,0,0.08)',
  borderRadius: '14px',
  overflow: 'hidden',
};

export const NotificationsPage: React.FC = () => {
  const [notifications, setNotifications] = useState<Notification[]>(INITIAL_NOTIFICATIONS);
  const [activeFilter, setActiveFilter] = useState<'all' | 'unread'>('all');

  const markAllRead = () => setNotifications(p => p.map(n => ({ ...n, unread: false })));
  const markRead = (id: number) => setNotifications(p => p.map(n => n.id === id ? { ...n, unread: false } : n));

  const filtered = activeFilter === 'unread' ? notifications.filter(n => n.unread) : notifications;
  const unreadCount = notifications.filter(n => n.unread).length;

  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '32px' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '28px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '4px' }}>
            <h1 style={{ fontSize: '20px', fontWeight: 500, margin: 0, letterSpacing: '-0.01em' }}>Notifications</h1>
            {unreadCount > 0 && (
              <span style={{ fontSize: '11px', fontWeight: 500, padding: '2px 8px', borderRadius: '20px', background: '#FAECE7', color: '#993C1D' }}>
                {unreadCount} unread
              </span>
            )}
          </div>
          <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>Stay updated with your network activity</p>
        </div>
        {unreadCount > 0 && (
          <button
            onClick={markAllRead}
            style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '8px 16px', background: 'var(--color-background-primary,#fff)', color: '#0F6E56', border: '0.5px solid #C0DD97', borderRadius: '9px', cursor: 'pointer', fontSize: '12px', fontWeight: 500 }}
          >
            <Check size={13} /> Mark all as read
          </button>
        )}
      </div>

      {/* Filter tabs */}
      <div style={{ display: 'flex', borderBottom: '0.5px solid rgba(0,0,0,0.08)', marginBottom: '20px' }}>
        {(['all', 'unread'] as const).map(f => (
          <button
            key={f}
            onClick={() => setActiveFilter(f)}
            style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '10px 20px', background: 'none', border: 'none', cursor: 'pointer', fontSize: '13px', fontWeight: activeFilter === f ? 500 : 400, color: activeFilter === f ? '#1D9E75' : 'var(--color-text-secondary)', borderBottom: activeFilter === f ? '2px solid #1D9E75' : '2px solid transparent', marginBottom: '-0.5px', transition: 'all 0.15s' }}
          >
            {f === 'all' ? 'All' : 'Unread'}
            {f === 'unread' && unreadCount > 0 && (
              <span style={{ fontSize: '10px', fontWeight: 500, padding: '1px 6px', borderRadius: '20px', background: activeFilter === 'unread' ? '#EAF3DE' : 'rgba(0,0,0,0.06)', color: activeFilter === 'unread' ? '#0F6E56' : 'var(--color-text-secondary)' }}>{unreadCount}</span>
            )}
          </button>
        ))}
      </div>

      {/* Notifications list */}
      {filtered.length === 0 ? (
        <div style={{ ...baseCard, padding: '60px', textAlign: 'center' }}>
          <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: '#EAF3DE', margin: '0 auto 14px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Bell size={22} color="#1D9E75" />
          </div>
          <p style={{ fontSize: '14px', fontWeight: 500, margin: '0 0 4px' }}>All caught up</p>
          <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>No unread notifications</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {filtered.map(n => {
            const tc = typeConf[n.type];
            const c = T[tc.color];
            const av = avatarColors[n.user.colorIdx % avatarColors.length];

            return (
              <div
                key={n.id}
                style={{ ...baseCard, background: n.unread ? 'var(--color-background-primary,#fff)' : 'var(--color-background-primary,#fff)', borderLeft: n.unread ? `3px solid ${T.emerald.fill}` : '3px solid transparent', cursor: 'pointer' }}
                onClick={() => markRead(n.id)}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = 'var(--color-background-secondary,#f8f7f4)'; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = 'var(--color-background-primary,#fff)'; }}
              >
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '14px', padding: '16px 20px' }}>
                  {/* Avatar */}
                  <div style={{ position: 'relative', flexShrink: 0 }}>
                    <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: av.bg, color: av.text, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '13px', fontWeight: 500 }}>
                      {n.user.initials}
                    </div>
                    {/* Type badge */}
                    <div style={{ position: 'absolute', bottom: '-2px', right: '-2px', width: '18px', height: '18px', borderRadius: '50%', background: c.bg, border: '1.5px solid var(--color-background-primary,#fff)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      {tc.icon(c as any)}
                    </div>
                  </div>

                  {/* Content */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '8px' }}>
                      <div>
                        <span style={{ fontSize: '13px', fontWeight: 500 }}>{n.user.name}</span>
                        <span style={{ fontSize: '13px', color: 'var(--color-text-secondary)', marginLeft: '4px' }}>{n.content}</span>
                      </div>
                      {n.unread && (
                        <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#1D9E75', flexShrink: 0, marginTop: '4px' }} />
                      )}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '6px' }}>
                      <span style={{ fontSize: '11px', fontWeight: 500, padding: '2px 8px', borderRadius: '20px', background: c.bg, color: c.text }}>{tc.label}</span>
                      <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>{n.time}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};