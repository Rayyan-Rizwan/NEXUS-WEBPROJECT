import React, { useState } from 'react';
import { Search, MapPin, SlidersHorizontal, X } from 'lucide-react';
import { InvestorCard } from '../../components/investor/InvestorCard';
import { investors } from '../../data/users';

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD' },
  amber:   { bg: '#FAEEDA', text: '#854F0B', fill: '#BA7517' },
};

const baseCard: React.CSSProperties = { background: 'var(--color-background-primary,#fff)', border: '0.5px solid rgba(0,0,0,0.08)', borderRadius: '14px', overflow: 'hidden' };

const locations = ['San Francisco, CA', 'New York, NY', 'Boston, MA', 'Austin, TX'];

export const InvestorsPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStages, setSelectedStages] = useState<string[]>([]);
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [selectedLocations, setSelectedLocations] = useState<string[]>([]);

  const allStages = Array.from(new Set(investors.flatMap(i => i.investmentStage)));
  const allInterests = Array.from(new Set(investors.flatMap(i => i.investmentInterests)));

  const filtered = investors.filter(inv => {
    const q = searchQuery.toLowerCase();
    const matchSearch = !searchQuery || inv.name.toLowerCase().includes(q) || inv.bio.toLowerCase().includes(q) || inv.investmentInterests.some(i => i.toLowerCase().includes(q));
    const matchStages = !selectedStages.length || inv.investmentStage.some(s => selectedStages.includes(s));
    const matchInterests = !selectedInterests.length || inv.investmentInterests.some(i => selectedInterests.includes(i));
    return matchSearch && matchStages && matchInterests;
  });

  const toggle = (arr: string[], setArr: (a: string[]) => void, val: string) =>
    setArr(arr.includes(val) ? arr.filter(x => x !== val) : [...arr, val]);

  const hasFilters = selectedStages.length || selectedInterests.length || selectedLocations.length || searchQuery;
  const clearAll = () => { setSearchQuery(''); setSelectedStages([]); setSelectedInterests([]); setSelectedLocations([]); };

  const FilterSection = ({ title, items, selected, onToggle, colorKey }: { title: string; items: string[]; selected: string[]; onToggle: (v: string) => void; colorKey: keyof typeof T }) => {
    const c = T[colorKey];
    return (
      <div style={{ paddingBottom: '16px', borderBottom: '0.5px solid rgba(0,0,0,0.06)', marginBottom: '16px' }}>
        <div style={{ fontSize: '11px', fontWeight: 500, color: 'var(--color-text-secondary)', letterSpacing: '0.06em', textTransform: 'uppercase' as const, marginBottom: '8px' }}>{title}</div>
        <div style={{ display: 'flex', flexDirection: 'column' as const, gap: '3px' }}>
          {items.map(item => {
            const active = selected.includes(item);
            return (
              <button key={item} onClick={() => onToggle(item)}
                style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '7px 10px', borderRadius: '8px', border: 'none', cursor: 'pointer', fontSize: '12px', textAlign: 'left' as const, background: active ? c.bg : 'transparent', color: active ? c.text : 'var(--color-text-secondary)', transition: 'all 0.15s' }}
                onMouseEnter={e => { if (!active) e.currentTarget.style.background = 'var(--color-background-secondary,#f8f7f4)'; }}
                onMouseLeave={e => { if (!active) e.currentTarget.style.background = 'transparent'; }}>
                <span style={{ width: '14px', height: '14px', borderRadius: '4px', border: `0.5px solid ${active ? c.fill : 'rgba(0,0,0,0.15)'}`, background: active ? c.fill : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  {active && <svg width="8" height="8" viewBox="0 0 8 8"><polyline points="1,4 3,6 7,2" fill="none" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                </span>
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item}</span>
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '32px' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '28px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <h1 style={{ fontSize: '20px', fontWeight: 500, margin: '0 0 4px', letterSpacing: '-0.01em' }}>Find investors</h1>
          <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>Connect with investors who match your startup's needs</p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          {hasFilters && (
            <button onClick={clearAll} style={{ display: 'flex', alignItems: 'center', gap: '5px', padding: '7px 14px', background: '#FAECE7', color: '#993C1D', border: '0.5px solid #D85A30', borderRadius: '9px', cursor: 'pointer', fontSize: '12px', fontWeight: 500 }}>
              <X size={12} /> Clear all
            </button>
          )}
          <span style={{ fontSize: '13px', color: 'var(--color-text-secondary)' }}>
            <span style={{ fontWeight: 500, color: 'var(--color-text-primary)' }}>{filtered.length}</span> investors
          </span>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', gap: '16px', alignItems: 'start' }}>

        {/* Filters sidebar */}
        <div style={baseCard}>
          <div style={{ padding: '14px 20px', borderBottom: '0.5px solid rgba(0,0,0,0.07)', display: 'flex', alignItems: 'center', gap: '6px' }}>
            <SlidersHorizontal size={13} color="#1D9E75" />
            <span style={{ fontSize: '13px', fontWeight: 500 }}>Filters</span>
            {hasFilters ? <span style={{ marginLeft: 'auto', fontSize: '10px', fontWeight: 500, background: '#EAF3DE', color: '#0F6E56', padding: '2px 7px', borderRadius: '20px' }}>{selectedStages.length + selectedInterests.length + selectedLocations.length} active</span> : null}
          </div>
          <div style={{ padding: '16px 16px 8px' }}>
            <FilterSection title="Investment stage" items={allStages} selected={selectedStages} onToggle={v => toggle(selectedStages, setSelectedStages, v)} colorKey="emerald" />
            <FilterSection title="Interests" items={allInterests} selected={selectedInterests} onToggle={v => toggle(selectedInterests, setSelectedInterests, v)} colorKey="violet" />
            <div>
              <div style={{ fontSize: '11px', fontWeight: 500, color: 'var(--color-text-secondary)', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: '8px' }}>Location</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '3px' }}>
                {locations.map(loc => {
                  const active = selectedLocations.includes(loc);
                  return (
                    <button key={loc} onClick={() => toggle(selectedLocations, setSelectedLocations, loc)}
                      style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '7px 10px', borderRadius: '8px', border: 'none', cursor: 'pointer', fontSize: '12px', background: active ? '#EAF3DE' : 'transparent', color: active ? '#0F6E56' : 'var(--color-text-secondary)', transition: 'all 0.15s' }}
                      onMouseEnter={e => { if (!active) e.currentTarget.style.background = 'var(--color-background-secondary,#f8f7f4)'; }}
                      onMouseLeave={e => { if (!active) e.currentTarget.style.background = active ? '#EAF3DE' : 'transparent'; }}>
                      <MapPin size={12} color={active ? '#1D9E75' : 'var(--color-text-tertiary,#b0b0b0)'} />
                      {loc}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Main */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <div style={{ position: 'relative' }}>
            <Search size={15} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: 'var(--color-text-tertiary,#b0b0b0)' }} />
            <input
              placeholder="Search investors by name, interests, or keywords…"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              style={{ width: '100%', padding: '11px 14px 11px 40px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '11px', fontSize: '13px', outline: 'none', background: 'var(--color-background-primary,#fff)', color: 'var(--color-text-primary)', boxSizing: 'border-box' as const }}
            />
          </div>

          {filtered.length > 0 ? (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(280px,1fr))', gap: '14px' }}>
              {filtered.map(inv => <InvestorCard key={inv.id} investor={inv} />)}
            </div>
          ) : (
            <div style={{ ...baseCard, padding: '60px', textAlign: 'center' }}>
              <p style={{ fontSize: '15px', fontWeight: 500, margin: '0 0 6px' }}>No investors found</p>
              <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: '0 0 20px' }}>Try adjusting your filters</p>
              <button onClick={clearAll} style={{ padding: '9px 20px', background: '#EAF3DE', color: '#0F6E56', border: '0.5px solid #C0DD97', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>
                Clear filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};