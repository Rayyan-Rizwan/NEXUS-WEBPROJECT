import React from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageCircle, Search, Plus } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { getConversationsForUser } from '../../data/messages';
import { ChatUserList } from '../../components/chat/ChatUserList';

const baseCard: React.CSSProperties = {
  background: 'var(--color-background-primary,#fff)',
  border: '0.5px solid rgba(0,0,0,0.08)',
  borderRadius: '14px',
  overflow: 'hidden',
};

export const MessagesPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  const conversations = getConversationsForUser(user.id);

  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '32px' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '28px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <h1 style={{ fontSize: '20px', fontWeight: 500, margin: '0 0 4px', letterSpacing: '-0.01em' }}>Messages</h1>
          <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>Your conversations with investors and entrepreneurs</p>
        </div>
        <button
          style={{ display: 'flex', alignItems: 'center', gap: '7px', padding: '9px 18px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '10px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}
          onClick={() => navigate('/investors')}
        >
          <Plus size={14} /> New message
        </button>
      </div>

      <div style={baseCard}>
        {conversations.length > 0 ? (
          <>
            {/* Search bar */}
            <div style={{ padding: '14px 20px', borderBottom: '0.5px solid rgba(0,0,0,0.07)' }}>
              <div style={{ position: 'relative' }}>
                <Search size={14} style={{ position: 'absolute', left: '11px', top: '50%', transform: 'translateY(-50%)', color: 'var(--color-text-tertiary,#b0b0b0)' }} />
                <input
                  placeholder="Search conversations…"
                  style={{ width: '100%', padding: '8px 12px 8px 32px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '9px', fontSize: '13px', outline: 'none', background: 'var(--color-background-secondary,#f8f7f4)', color: 'var(--color-text-primary)', boxSizing: 'border-box' as const }}
                />
              </div>
            </div>
            <ChatUserList conversations={conversations} />
          </>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '400px', padding: '48px 24px', gap: '16px' }}>
            <div style={{ width: '60px', height: '60px', borderRadius: '16px', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <MessageCircle size={28} color="#1D9E75" />
            </div>
            <div style={{ textAlign: 'center' }}>
              <h2 style={{ fontSize: '16px', fontWeight: 500, margin: '0 0 6px' }}>No messages yet</h2>
              <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: '0 0 20px', lineHeight: 1.6, maxWidth: '320px' }}>
                Start connecting with entrepreneurs and investors to begin conversations
              </p>
              <button
                onClick={() => navigate('/investors')}
                style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '9px 20px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '10px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}
              >
                <Plus size={14} /> Find people to message
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};