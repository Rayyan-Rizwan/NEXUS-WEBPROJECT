import React, { useState } from 'react';
import { User, Lock, Bell, Globe, Palette, CreditCard, Camera, Check, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75', mid: '#C0DD97' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD', mid: '#AFA9EC' },
  amber:   { bg: '#FAEEDA', text: '#854F0B', fill: '#BA7517', mid: '#FAC775' },
  coral:   { bg: '#FAECE7', text: '#993C1D', fill: '#D85A30', mid: '#F5C4B3' },
};

const baseCard: React.CSSProperties = {
  background: 'var(--color-background-primary,#fff)',
  border: '0.5px solid rgba(0,0,0,0.08)',
  borderRadius: '14px',
  overflow: 'hidden',
};

const panelHead: React.CSSProperties = {
  padding: '16px 24px',
  borderBottom: '0.5px solid rgba(0,0,0,0.07)',
};

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '9px 12px',
  border: '0.5px solid rgba(0,0,0,0.12)',
  borderRadius: '9px',
  fontSize: '13px',
  outline: 'none',
  background: 'var(--color-background-primary,#fff)',
  color: 'var(--color-text-primary)',
  boxSizing: 'border-box',
};

const labelStyle: React.CSSProperties = {
  display: 'block',
  fontSize: '11px',
  fontWeight: 500,
  color: 'var(--color-text-secondary)',
  marginBottom: '5px',
  textTransform: 'uppercase',
  letterSpacing: '0.05em',
};

type NavSection = 'profile' | 'security' | 'notifications' | 'language' | 'appearance' | 'billing';

const navItems: { key: NavSection; label: string; icon: React.ReactNode }[] = [
  { key: 'profile',       label: 'Profile',       icon: <User size={15} /> },
  { key: 'security',      label: 'Security',      icon: <Lock size={15} /> },
  { key: 'notifications', label: 'Notifications', icon: <Bell size={15} /> },
  { key: 'language',      label: 'Language',      icon: <Globe size={15} /> },
  { key: 'appearance',    label: 'Appearance',    icon: <Palette size={15} /> },
  { key: 'billing',       label: 'Billing',       icon: <CreditCard size={15} /> },
];

export const SettingsPage: React.FC = () => {
  const { user } = useAuth();
  const [activeSection, setActiveSection] = useState<NavSection>('profile');
  const [saved, setSaved] = useState(false);
  const [showCurrentPw, setShowCurrentPw] = useState(false);
  const [showNewPw, setShowNewPw] = useState(false);
  const [showConfirmPw, setShowConfirmPw] = useState(false);
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  const [notifPrefs, setNotifPrefs] = useState({
    messages: true, connections: true, investments: false, weekly: true,
  });

  if (!user) return null;

  const initials = user.name.split(' ').map((w: string) => w[0]).join('').slice(0, 2).toUpperCase();

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const focusStyle = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    e.currentTarget.style.borderColor = '#1D9E75';
  };
  const blurStyle = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    e.currentTarget.style.borderColor = 'rgba(0,0,0,0.12)';
  };

  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '32px' }}>

      {/* Header */}
      <div style={{ marginBottom: '28px' }}>
        <h1 style={{ fontSize: '20px', fontWeight: 500, margin: '0 0 4px', letterSpacing: '-0.01em' }}>Settings</h1>
        <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>Manage your account preferences and settings</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: '16px', alignItems: 'start' }}>

        {/* Sidebar nav */}
        <div style={baseCard}>
          <div style={{ padding: '6px 0' }}>
            {navItems.map(item => {
              const active = activeSection === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => setActiveSection(item.key)}
                  style={{ display: 'flex', alignItems: 'center', gap: '9px', width: '100%', padding: '10px 16px', background: active ? '#EAF3DE' : 'none', border: 'none', cursor: 'pointer', fontSize: '13px', fontWeight: active ? 500 : 400, color: active ? '#0F6E56' : 'var(--color-text-secondary)', textAlign: 'left', transition: 'all 0.12s', borderLeft: active ? '2px solid #1D9E75' : '2px solid transparent' }}
                  onMouseEnter={e => { if (!active) { e.currentTarget.style.background = 'var(--color-background-secondary,#f8f7f4)'; e.currentTarget.style.color = 'var(--color-text-primary)'; } }}
                  onMouseLeave={e => { if (!active) { e.currentTarget.style.background = 'none'; e.currentTarget.style.color = 'var(--color-text-secondary)'; } }}
                >
                  {item.icon} {item.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Main content */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>

          {/* Saved banner */}
          {saved && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 16px', background: '#EAF3DE', border: '0.5px solid #C0DD97', borderRadius: '10px' }}>
              <Check size={15} color="#1D9E75" />
              <span style={{ fontSize: '13px', color: '#0F6E56', fontWeight: 500 }}>Changes saved successfully</span>
            </div>
          )}

          {/* PROFILE */}
          {activeSection === 'profile' && (
            <>
              <div style={baseCard}>
                <div style={panelHead}>
                  <div style={{ fontSize: '14px', fontWeight: 500 }}>Profile settings</div>
                  <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>Update your personal information</div>
                </div>
                <div style={{ padding: '24px' }}>
                  {/* Avatar */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '24px', paddingBottom: '24px', borderBottom: '0.5px solid rgba(0,0,0,0.07)' }}>
                    <div style={{ position: 'relative' }}>
                      <div style={{ width: '68px', height: '68px', borderRadius: '16px', background: '#EAF3DE', color: '#0F6E56', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '22px', fontWeight: 500 }}>{initials}</div>
                      <button style={{ position: 'absolute', bottom: '-3px', right: '-3px', width: '22px', height: '22px', borderRadius: '50%', background: '#1D9E75', border: '2px solid var(--color-background-primary,#fff)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
                        <Camera size={11} color="#fff" />
                      </button>
                    </div>
                    <div>
                      <button style={{ padding: '7px 14px', border: '0.5px solid rgba(0,0,0,0.12)', borderRadius: '8px', background: 'var(--color-background-primary,#fff)', cursor: 'pointer', fontSize: '12px', color: 'var(--color-text-secondary)' }}>
                        Change photo
                      </button>
                      <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)', margin: '4px 0 0' }}>JPG, GIF or PNG · max 800KB</p>
                    </div>
                  </div>

                  {/* Form fields */}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                    {[
                      { label: 'Full name', defaultVal: user.name, type: 'text', ph: 'Your full name' },
                      { label: 'Email address', defaultVal: user.email, type: 'email', ph: 'you@company.com' },
                      { label: 'Role', defaultVal: user.role, type: 'text', disabled: true, ph: '' },
                      { label: 'Location', defaultVal: 'San Francisco, CA', type: 'text', ph: 'City, Country' },
                    ].map((f, i) => (
                      <div key={i}>
                        <label style={labelStyle}>{f.label}</label>
                        <input
                          type={f.type}
                          defaultValue={f.defaultVal}
                          placeholder={f.ph}
                          disabled={f.disabled}
                          onFocus={focusStyle}
                          onBlur={blurStyle}
                          style={{ ...inputStyle, opacity: f.disabled ? 0.55 : 1, cursor: f.disabled ? 'not-allowed' : 'text' }}
                        />
                      </div>
                    ))}
                  </div>
                  <div style={{ marginBottom: '20px' }}>
                    <label style={labelStyle}>Bio</label>
                    <textarea
                      rows={4}
                      defaultValue={user.bio}
                      onFocus={focusStyle as any}
                      onBlur={blurStyle as any}
                      style={{ ...inputStyle, resize: 'vertical', fontFamily: 'inherit', lineHeight: 1.6 }}
                    />
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
                    <button style={{ padding: '9px 18px', border: '0.5px solid rgba(0,0,0,0.12)', borderRadius: '9px', background: 'var(--color-background-primary,#fff)', cursor: 'pointer', fontSize: '13px', color: 'var(--color-text-secondary)' }}>Cancel</button>
                    <button onClick={handleSave} style={{ padding: '9px 18px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>Save changes</button>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* SECURITY */}
          {activeSection === 'security' && (
            <>
              <div style={baseCard}>
                <div style={panelHead}>
                  <div style={{ fontSize: '14px', fontWeight: 500 }}>Two-factor authentication</div>
                </div>
                <div style={{ padding: '20px 24px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
                    <div>
                      <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: '0 0 6px', lineHeight: 1.5 }}>
                        Add an extra layer of security to your account with two-factor authentication.
                      </p>
                      <span style={{ fontSize: '10px', fontWeight: 500, padding: '2px 8px', borderRadius: '20px', background: twoFactorEnabled ? '#EAF3DE' : '#FAECE7', color: twoFactorEnabled ? '#0F6E56' : '#993C1D' }}>
                        {twoFactorEnabled ? 'Enabled' : 'Not enabled'}
                      </span>
                    </div>
                    <button
                      onClick={() => setTwoFactorEnabled(p => !p)}
                      style={{ padding: '8px 16px', border: '0.5px solid', borderRadius: '9px', background: twoFactorEnabled ? '#FAECE7' : '#EAF3DE', color: twoFactorEnabled ? '#993C1D' : '#0F6E56', borderColor: twoFactorEnabled ? '#F5C4B3' : '#C0DD97', cursor: 'pointer', fontSize: '12px', fontWeight: 500 }}
                    >
                      {twoFactorEnabled ? 'Disable' : 'Enable'}
                    </button>
                  </div>
                </div>
              </div>

              <div style={baseCard}>
                <div style={panelHead}>
                  <div style={{ fontSize: '14px', fontWeight: 500 }}>Change password</div>
                </div>
                <div style={{ padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
                  {[
                    { label: 'Current password', show: showCurrentPw, setShow: setShowCurrentPw },
                    { label: 'New password', show: showNewPw, setShow: setShowNewPw },
                    { label: 'Confirm new password', show: showConfirmPw, setShow: setShowConfirmPw },
                  ].map((f, i) => (
                    <div key={i}>
                      <label style={labelStyle}>{f.label}</label>
                      <div style={{ position: 'relative' }}>
                        <input
                          type={f.show ? 'text' : 'password'}
                          onFocus={focusStyle}
                          onBlur={blurStyle}
                          style={{ ...inputStyle, paddingRight: '38px' }}
                        />
                        <button
                          type="button"
                          onClick={() => f.setShow((p: boolean) => !p)}
                          style={{ position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--color-text-tertiary,#b0b0b0)', display: 'flex', alignItems: 'center' }}
                        >
                          {f.show ? <EyeOff size={14} /> : <Eye size={14} />}
                        </button>
                      </div>
                    </div>
                  ))}
                  <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <button onClick={handleSave} style={{ padding: '9px 18px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>
                      Update password
                    </button>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* NOTIFICATIONS */}
          {activeSection === 'notifications' && (
            <div style={baseCard}>
              <div style={panelHead}>
                <div style={{ fontSize: '14px', fontWeight: 500 }}>Notification preferences</div>
                <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>Choose what you want to be notified about</div>
              </div>
              <div style={{ padding: '8px 0' }}>
                {[
                  { key: 'messages',    label: 'New messages', desc: 'When someone sends you a message', color: 'violet' as const },
                  { key: 'connections', label: 'Connections',  desc: 'When someone accepts your request', color: 'emerald' as const },
                  { key: 'investments', label: 'Investment interest', desc: 'When an investor views your profile', color: 'amber' as const },
                  { key: 'weekly',      label: 'Weekly digest', desc: 'A weekly summary of your activity', color: 'coral' as const },
                ].map((n, i) => {
                  const active = notifPrefs[n.key as keyof typeof notifPrefs];
                  const c = T[n.color];
                  return (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 24px', borderBottom: '0.5px solid rgba(0,0,0,0.05)' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: c.bg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: c.fill }} />
                        </div>
                        <div>
                          <p style={{ fontSize: '13px', fontWeight: 500, margin: 0 }}>{n.label}</p>
                          <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)', margin: 0 }}>{n.desc}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => setNotifPrefs(p => ({ ...p, [n.key]: !active }))}
                        style={{ width: '40px', height: '22px', borderRadius: '11px', border: 'none', cursor: 'pointer', background: active ? '#1D9E75' : 'rgba(0,0,0,0.12)', position: 'relative', transition: 'background 0.2s', flexShrink: 0 }}
                      >
                        <span style={{ position: 'absolute', top: '3px', width: '16px', height: '16px', borderRadius: '50%', background: '#fff', transition: 'left 0.2s', left: active ? '21px' : '3px' }} />
                      </button>
                    </div>
                  );
                })}
              </div>
              <div style={{ padding: '14px 24px', borderTop: '0.5px solid rgba(0,0,0,0.06)', display: 'flex', justifyContent: 'flex-end' }}>
                <button onClick={handleSave} style={{ padding: '9px 18px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>Save preferences</button>
              </div>
            </div>
          )}

          {/* Other sections — placeholder */}
          {(activeSection === 'language' || activeSection === 'appearance' || activeSection === 'billing') && (
            <div style={{ ...baseCard, padding: '60px', textAlign: 'center' }}>
              <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: '#EAF3DE', margin: '0 auto 14px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {navItems.find(n => n.key === activeSection)?.icon}
              </div>
              <p style={{ fontSize: '14px', fontWeight: 500, margin: '0 0 4px' }}>
                {navItems.find(n => n.key === activeSection)?.label} settings
              </p>
              <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>This section is coming soon.</p>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};