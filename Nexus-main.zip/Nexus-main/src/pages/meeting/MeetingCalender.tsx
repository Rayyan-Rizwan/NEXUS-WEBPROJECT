import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Clock, Plus, Check, X, Video, MapPin, CalendarDays } from 'lucide-react';

type MeetingStatus = 'confirmed' | 'pending' | 'declined';
type ViewTab = 'calendar' | 'requests' | 'availability';

interface Meeting {
  id: string; title: string; date: Date; time: string; duration: number; with: string; status: MeetingStatus; type: 'video'|'in-person'; avatar: string;
}

const DAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const TIME_SLOTS = ['9:00 AM','9:30 AM','10:00 AM','10:30 AM','11:00 AM','11:30 AM','12:00 PM','12:30 PM','1:00 PM','1:30 PM','2:00 PM','2:30 PM','3:00 PM','3:30 PM','4:00 PM','4:30 PM','5:00 PM'];

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75', mid: '#C0DD97' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD', mid: '#AFA9EC' },
  amber:   { bg: '#FAEEDA', text: '#854F0B', fill: '#BA7517', mid: '#FAC775' },
  coral:   { bg: '#FAECE7', text: '#993C1D', fill: '#D85A30', mid: '#F5C4B3' },
};

const statusStyle: Record<MeetingStatus, { bg: string; text: string; dot: string }> = {
  confirmed: { bg: '#EAF3DE', text: '#0F6E56', dot: '#1D9E75' },
  pending:   { bg: '#FAEEDA', text: '#854F0B', dot: '#BA7517' },
  declined:  { bg: '#FAECE7', text: '#993C1D', dot: '#D85A30' },
};

const avatarPalette = [T.emerald, T.violet, T.amber, T.coral];
const getAv = (initials: string) => avatarPalette[(initials.charCodeAt(0) + (initials.charCodeAt(1)||0)) % 4];

const INITIAL_MEETINGS: Meeting[] = [
  { id:'1', title:'Pitch Review', date: new Date(2026,2,16), time:'10:00 AM', duration:60, with:'Sarah Chen', status:'confirmed', type:'video', avatar:'SC' },
  { id:'2', title:'Due Diligence Call', date: new Date(2026,2,18), time:'2:00 PM', duration:45, with:'Michael Torres', status:'pending', type:'video', avatar:'MT' },
  { id:'3', title:'Term Sheet Discussion', date: new Date(2026,2,20), time:'11:00 AM', duration:30, with:'Priya Nair', status:'confirmed', type:'in-person', avatar:'PN' },
  { id:'4', title:'Portfolio Update', date: new Date(2026,2,25), time:'3:30 PM', duration:60, with:'David Lim', status:'pending', type:'video', avatar:'DL' },
];

const baseCard: React.CSSProperties = { background: 'var(--color-background-primary,#fff)', border: '0.5px solid rgba(0,0,0,0.08)', borderRadius: '14px', overflow: 'hidden' };

export const MeetingCalendar: React.FC = () => {
  const today = new Date(2026,2,13);
  const [currentDate, setCurrentDate] = useState(new Date(2026,2,1));
  const [meetings, setMeetings] = useState<Meeting[]>(INITIAL_MEETINGS);
  const [selectedDate, setSelectedDate] = useState<Date|null>(null);
  const [availability, setAvailability] = useState<{day:number;slots:string[]}[]>([
    {day:1,slots:['10:00 AM','2:00 PM','4:00 PM']},
    {day:3,slots:['9:00 AM','11:00 AM','3:00 PM']},
    {day:5,slots:['10:30 AM','1:00 PM']},
  ]);
  const [showModal, setShowModal] = useState(false);
  const [activeTab, setActiveTab] = useState<ViewTab>('calendar');
  const [newM, setNewM] = useState({ title:'', time:'10:00 AM', with:'', type:'video' as 'video'|'in-person', duration:30 });

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const firstDay = new Date(year,month,1).getDay();
  const daysInMonth = new Date(year,month+1,0).getDate();

  const getMeetings = (day:number) => meetings.filter(m => m.date.getFullYear()===year && m.date.getMonth()===month && m.date.getDate()===day);
  const getSlots = (day:number) => availability.find(a=>a.day===day)?.slots || [];
  const selectedMeetings = selectedDate ? getMeetings(selectedDate.getDate()) : [];
  const pending = meetings.filter(m=>m.status==='pending');
  const confirmed = meetings.filter(m=>m.status==='confirmed');

  const toggleSlot = (day:number,slot:string) => {
    setAvailability(prev=>{
      const ex = prev.find(a=>a.day===day);
      if(ex){ const slots = ex.slots.includes(slot) ? ex.slots.filter(s=>s!==slot) : [...ex.slots,slot]; return prev.map(a=>a.day===day?{...a,slots}:a); }
      return [...prev,{day,slots:[slot]}];
    });
  };

  const handleAdd = () => {
    if (!selectedDate||!newM.title||!newM.with) return;
    setMeetings(prev=>[...prev,{id:Date.now().toString(),title:newM.title,date:selectedDate,time:newM.time,duration:newM.duration,with:newM.with,status:'confirmed',type:newM.type,avatar:newM.with.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase()}]);
    setShowModal(false);
    setNewM({title:'',time:'10:00 AM',with:'',type:'video',duration:30});
  };

  const cells: (number|null)[] = [];
  for(let i=0;i<firstDay;i++) cells.push(null);
  for(let d=1;d<=daysInMonth;d++) cells.push(d);

  const tabs: {key:ViewTab;label:string;badge?:number}[] = [
    {key:'calendar',label:'Calendar'},
    {key:'requests',label:'Requests',badge:pending.length},
    {key:'availability',label:'Availability'},
  ];

  const inputStyle: React.CSSProperties = { width:'100%', padding:'8px 11px', border:'0.5px solid rgba(0,0,0,0.12)', borderRadius:'8px', fontSize:'13px', outline:'none', background:'var(--color-background-primary,#fff)', color:'var(--color-text-primary)', boxSizing:'border-box' };

  return (
    <div style={{ fontFamily:'var(--font-sans,system-ui,sans-serif)', color:'var(--color-text-primary)', paddingBottom:'32px' }}>

      {/* Header */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'28px', flexWrap:'wrap', gap:'12px' }}>
        <div>
          <h1 style={{ fontSize:'20px', fontWeight:500, margin:'0 0 4px', letterSpacing:'-0.01em' }}>Meeting scheduler</h1>
          <p style={{ fontSize:'13px', color:'var(--color-text-secondary)', margin:0 }}>Manage availability and meetings</p>
        </div>
        <div style={{ display:'flex', gap:'8px', alignItems:'center' }}>
          <span style={{ fontSize:'11px', fontWeight:500, padding:'3px 10px', borderRadius:'20px', background:'#EAF3DE', color:'#0F6E56' }}>{confirmed.length} confirmed</span>
          <span style={{ fontSize:'11px', fontWeight:500, padding:'3px 10px', borderRadius:'20px', background:'#FAEEDA', color:'#854F0B' }}>{pending.length} pending</span>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display:'flex', borderBottom:'0.5px solid rgba(0,0,0,0.08)', marginBottom:'20px' }}>
        {tabs.map(t=>(
          <button key={t.key} onClick={()=>setActiveTab(t.key)} style={{ display:'flex', alignItems:'center', gap:'6px', padding:'10px 20px', background:'none', border:'none', cursor:'pointer', fontSize:'13px', fontWeight:activeTab===t.key?500:400, color:activeTab===t.key?'#1D9E75':'var(--color-text-secondary)', borderBottom:activeTab===t.key?'2px solid #1D9E75':'2px solid transparent', marginBottom:'-0.5px', transition:'all 0.15s' }}>
            {t.label}
            {t.badge ? <span style={{ fontSize:'10px', fontWeight:500, padding:'1px 6px', borderRadius:'20px', background:activeTab===t.key?'#EAF3DE':'rgba(0,0,0,0.06)', color:activeTab===t.key?'#0F6E56':'var(--color-text-secondary)' }}>{t.badge}</span> : null}
          </button>
        ))}
      </div>

      {/* CALENDAR TAB */}
      {activeTab==='calendar' && (
        <div style={{ display:'grid', gridTemplateColumns:'1fr 300px', gap:'16px' }}>
          {/* Calendar */}
          <div style={baseCard}>
            <div style={{ padding:'14px 20px', borderBottom:'0.5px solid rgba(0,0,0,0.07)', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
              <button onClick={()=>setCurrentDate(new Date(year,month-1,1))} style={{ width:'30px',height:'30px',borderRadius:'8px',border:'0.5px solid rgba(0,0,0,0.10)',background:'none',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',color:'var(--color-text-secondary)' }}><ChevronLeft size={15}/></button>
              <span style={{ fontSize:'14px', fontWeight:500 }}>{MONTHS[month]} {year}</span>
              <button onClick={()=>setCurrentDate(new Date(year,month+1,1))} style={{ width:'30px',height:'30px',borderRadius:'8px',border:'0.5px solid rgba(0,0,0,0.10)',background:'none',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',color:'var(--color-text-secondary)' }}><ChevronRight size={15}/></button>
            </div>
            {/* Day headers */}
            <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', borderBottom:'0.5px solid rgba(0,0,0,0.06)' }}>
              {DAYS.map(d=><div key={d} style={{ padding:'8px 0', textAlign:'center', fontSize:'11px', fontWeight:500, color:'var(--color-text-secondary)', textTransform:'uppercase', letterSpacing:'0.06em' }}>{d}</div>)}
            </div>
            {/* Cells */}
            <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)' }}>
              {cells.map((day,idx)=>{
                if(!day) return <div key={`e${idx}`} style={{ minHeight:'72px', borderRight:(idx+1)%7===0?'none':'0.5px solid rgba(0,0,0,0.04)', borderBottom:'0.5px solid rgba(0,0,0,0.04)', background:'var(--color-background-secondary,#f8f7f4)', opacity:0.5 }}/>;
                const dayMs = getMeetings(day);
                const isToday = today.getDate()===day&&today.getMonth()===month&&today.getFullYear()===year;
                const isSel = selectedDate?.getDate()===day&&selectedDate?.getMonth()===month&&selectedDate?.getFullYear()===year;
                const hasSlots = getSlots(new Date(year,month,day).getDay()).length>0;
                return (
                  <div key={day} onClick={()=>setSelectedDate(new Date(year,month,day))} style={{ minHeight:'72px', padding:'6px', cursor:'pointer', borderRight:(idx+1)%7===0?'none':'0.5px solid rgba(0,0,0,0.04)', borderBottom:'0.5px solid rgba(0,0,0,0.04)', background:isSel?'#EAF3DE':'var(--color-background-primary,#fff)', transition:'background 0.1s' }}>
                    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:'4px' }}>
                      <span style={{ fontSize:'13px', fontWeight:isToday?500:400, width:'24px', height:'24px', borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', background:isToday?'#1D9E75':'transparent', color:isToday?'#fff':isSel?'#0F6E56':'var(--color-text-primary)' }}>{day}</span>
                      {hasSlots&&<span style={{ width:'5px',height:'5px',borderRadius:'50%',background:'#1D9E75',flexShrink:0 }}/>}
                    </div>
                    {dayMs.slice(0,2).map(m=>(
                      <div key={m.id} style={{ fontSize:'10px', padding:'2px 4px', borderRadius:'4px', fontWeight:500, background:statusStyle[m.status].bg, color:statusStyle[m.status].text, overflow:'hidden', whiteSpace:'nowrap', textOverflow:'ellipsis', marginBottom:'2px' }}>
                        {m.time.replace(' AM','a').replace(' PM','p')} {m.title}
                      </div>
                    ))}
                    {dayMs.length>2&&<span style={{ fontSize:'10px', color:'var(--color-text-secondary)' }}>+{dayMs.length-2}</span>}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Side panel */}
          <div style={{ display:'flex', flexDirection:'column', gap:'14px' }}>
            {selectedDate ? (
              <div style={baseCard}>
                <div style={{ padding:'14px 20px', borderBottom:'0.5px solid rgba(0,0,0,0.07)', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                  <div>
                    <div style={{ fontSize:'11px', color:'var(--color-text-secondary)', textTransform:'uppercase', letterSpacing:'0.06em', fontWeight:500 }}>{DAYS[selectedDate.getDay()]}</div>
                    <div style={{ fontSize:'16px', fontWeight:500, marginTop:'1px' }}>{selectedDate.getDate()} {MONTHS[selectedDate.getMonth()]}</div>
                  </div>
                  <button onClick={()=>setShowModal(true)} style={{ display:'flex', alignItems:'center', gap:'5px', padding:'6px 12px', background:'#1D9E75', color:'#fff', border:'none', borderRadius:'8px', cursor:'pointer', fontSize:'12px', fontWeight:500 }}>
                    <Plus size={13}/> Add
                  </button>
                </div>
                <div style={{ padding:'12px 20px' }}>
                  {selectedMeetings.length===0 ? (
                    <div style={{ textAlign:'center', padding:'24px 0' }}>
                      <CalendarDays size={24} color="var(--color-text-tertiary,#c0c0c0)" style={{ margin:'0 auto 8px', display:'block' }}/>
                      <p style={{ fontSize:'12px', color:'var(--color-text-secondary)', margin:0 }}>No meetings on this day</p>
                    </div>
                  ) : (
                    <div style={{ display:'flex', flexDirection:'column', gap:'8px' }}>
                      {selectedMeetings.map(m=>{
                        const av = getAv(m.avatar);
                        const ss = statusStyle[m.status];
                        return (
                          <div key={m.id} style={{ padding:'10px 12px', border:`0.5px solid rgba(0,0,0,0.08)`, borderRadius:'10px', borderLeft:`2px solid ${ss.dot}` }}>
                            <div style={{ display:'flex', alignItems:'center', gap:'8px', marginBottom:'6px' }}>
                              <div style={{ width:'26px', height:'26px', borderRadius:'6px', background:av.bg, color:av.text, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'10px', fontWeight:500, flexShrink:0 }}>{m.avatar}</div>
                              <div style={{ flex:1, minWidth:0 }}>
                                <p style={{ fontSize:'12px', fontWeight:500, margin:0, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{m.title}</p>
                                <p style={{ fontSize:'11px', color:'var(--color-text-secondary)', margin:0 }}>with {m.with}</p>
                              </div>
                            </div>
                            <div style={{ display:'flex', alignItems:'center', gap:'8px', flexWrap:'wrap' }}>
                              <span style={{ display:'flex', alignItems:'center', gap:'3px', fontSize:'11px', color:'var(--color-text-secondary)' }}><Clock size={10}/> {m.time} · {m.duration}min</span>
                              <span style={{ display:'flex', alignItems:'center', gap:'3px', fontSize:'11px', color:'var(--color-text-secondary)' }}>{m.type==='video'?<Video size={10}/>:<MapPin size={10}/>} {m.type}</span>
                              <span style={{ fontSize:'10px', padding:'2px 6px', borderRadius:'10px', background:ss.bg, color:ss.text, fontWeight:500 }}>{m.status}</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div style={{ ...baseCard, padding:'32px 20px', textAlign:'center' }}>
                <CalendarDays size={28} color="var(--color-text-tertiary,#c0c0c0)" style={{ margin:'0 auto 10px', display:'block' }}/>
                <p style={{ fontSize:'13px', color:'var(--color-text-secondary)', margin:0 }}>Select a date to view meetings</p>
              </div>
            )}

            {/* Upcoming */}
            <div style={baseCard}>
              <div style={{ padding:'14px 20px', borderBottom:'0.5px solid rgba(0,0,0,0.07)', fontSize:'13px', fontWeight:500 }}>Upcoming</div>
              <div style={{ padding:'8px 20px 12px', display:'flex', flexDirection:'column', gap:'8px' }}>
                {confirmed.slice(0,3).map(m=>{
                  const av=getAv(m.avatar);
                  return (
                    <div key={m.id} style={{ display:'flex', alignItems:'center', gap:'8px' }}>
                      <div style={{ width:'28px', height:'28px', borderRadius:'7px', background:av.bg, color:av.text, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'10px', fontWeight:500, flexShrink:0 }}>{m.avatar}</div>
                      <div style={{ flex:1, minWidth:0 }}>
                        <p style={{ fontSize:'12px', fontWeight:500, margin:0, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{m.title}</p>
                        <p style={{ fontSize:'11px', color:'var(--color-text-secondary)', margin:0 }}>{m.date.getDate()} {MONTHS[m.date.getMonth()].slice(0,3)} · {m.time}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* REQUESTS TAB */}
      {activeTab==='requests' && (
        <div style={{ display:'flex', flexDirection:'column', gap:'10px' }}>
          {pending.length===0 ? (
            <div style={{ ...baseCard, padding:'60px', textAlign:'center' }}>
              <Check size={28} color="#1D9E75" style={{ margin:'0 auto 10px', display:'block' }}/>
              <p style={{ fontSize:'14px', fontWeight:500, margin:'0 0 4px' }}>All caught up</p>
              <p style={{ fontSize:'12px', color:'var(--color-text-secondary)', margin:0 }}>No pending meeting requests</p>
            </div>
          ) : pending.map(m=>{
            const av=getAv(m.avatar);
            return (
              <div key={m.id} style={{ ...baseCard, padding:'18px 24px', display:'flex', alignItems:'center', gap:'14px' }}>
                <div style={{ width:'40px', height:'40px', borderRadius:'10px', background:av.bg, color:av.text, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'13px', fontWeight:500, flexShrink:0 }}>{m.avatar}</div>
                <div style={{ flex:1 }}>
                  <p style={{ fontSize:'14px', fontWeight:500, margin:'0 0 2px' }}>{m.with} requested a meeting</p>
                  <p style={{ fontSize:'13px', color:'var(--color-text-secondary)', margin:'0 0 6px' }}>{m.title}</p>
                  <div style={{ display:'flex', gap:'14px', flexWrap:'wrap' }}>
                    <span style={{ display:'flex', alignItems:'center', gap:'4px', fontSize:'12px', color:'var(--color-text-secondary)' }}><Clock size={12}/> {m.date.getDate()} {MONTHS[m.date.getMonth()]} · {m.time} ({m.duration}min)</span>
                    <span style={{ display:'flex', alignItems:'center', gap:'4px', fontSize:'12px', color:'var(--color-text-secondary)' }}>{m.type==='video'?<Video size={12}/>:<MapPin size={12}/>} {m.type}</span>
                  </div>
                </div>
                <div style={{ display:'flex', gap:'8px', flexShrink:0 }}>
                  <button onClick={()=>setMeetings(prev=>prev.map(x=>x.id===m.id?{...x,status:'confirmed'}:x))} style={{ display:'flex', alignItems:'center', gap:'5px', padding:'8px 14px', background:'#EAF3DE', color:'#0F6E56', border:'0.5px solid #C0DD97', borderRadius:'8px', cursor:'pointer', fontSize:'12px', fontWeight:500 }}>
                    <Check size={13}/> Accept
                  </button>
                  <button onClick={()=>setMeetings(prev=>prev.map(x=>x.id===m.id?{...x,status:'declined'}:x))} style={{ display:'flex', alignItems:'center', gap:'5px', padding:'8px 14px', background:'#FAECE7', color:'#993C1D', border:'0.5px solid #F5C4B3', borderRadius:'8px', cursor:'pointer', fontSize:'12px', fontWeight:500 }}>
                    <X size={13}/> Decline
                  </button>
                </div>
              </div>
            );
          })}
          {meetings.filter(m=>m.status!=='pending').slice(0,3).map(m=>{
            const av=getAv(m.avatar);
            const ss=statusStyle[m.status];
            return (
              <div key={m.id} style={{ ...baseCard, padding:'14px 24px', display:'flex', alignItems:'center', gap:'12px', opacity:0.65 }}>
                <div style={{ width:'34px', height:'34px', borderRadius:'8px', background:av.bg, color:av.text, display:'flex', alignItems:'center', justifyContent:'center', fontSize:'11px', fontWeight:500, flexShrink:0 }}>{m.avatar}</div>
                <div style={{ flex:1 }}>
                  <p style={{ fontSize:'13px', fontWeight:500, margin:'0 0 2px' }}>{m.title}</p>
                  <p style={{ fontSize:'12px', color:'var(--color-text-secondary)', margin:0 }}>{m.date.getDate()} {MONTHS[m.date.getMonth()]} · {m.time} · with {m.with}</p>
                </div>
                <span style={{ fontSize:'11px', fontWeight:500, padding:'3px 10px', borderRadius:'20px', background:ss.bg, color:ss.text }}>{m.status}</span>
              </div>
            );
          })}
        </div>
      )}

      {/* AVAILABILITY TAB */}
      {activeTab==='availability' && (
        <div style={baseCard}>
          <div style={{ padding:'16px 24px', borderBottom:'0.5px solid rgba(0,0,0,0.07)' }}>
            <div style={{ fontSize:'14px', fontWeight:500 }}>Weekly availability</div>
            <div style={{ fontSize:'12px', color:'var(--color-text-secondary)', marginTop:'2px' }}>Click time slots to toggle your availability for investors</div>
          </div>
          <div style={{ padding:'20px 24px', overflowX:'auto' }}>
            <div style={{ display:'grid', gridTemplateColumns:'80px repeat(5,1fr)', gap:'4px', minWidth:'560px' }}>
              <div/>
              {['Mon','Tue','Wed','Thu','Fri'].map(d=>(
                <div key={d} style={{ textAlign:'center', fontSize:'11px', fontWeight:500, color:'var(--color-text-secondary)', padding:'6px 0', textTransform:'uppercase', letterSpacing:'0.06em' }}>{d}</div>
              ))}
              {TIME_SLOTS.map(slot=>(
                <React.Fragment key={slot}>
                  <div style={{ fontSize:'11px', color:'var(--color-text-secondary)', display:'flex', alignItems:'center' }}>{slot}</div>
                  {[1,2,3,4,5].map(dayIdx=>{
                    const active = getSlots(dayIdx).includes(slot);
                    return (
                      <button key={dayIdx} onClick={()=>toggleSlot(dayIdx,slot)} style={{ height:'30px', borderRadius:'6px', border:`0.5px solid ${active?'#C0DD97':'rgba(0,0,0,0.08)'}`, background:active?'#EAF3DE':'var(--color-background-secondary,#f8f7f4)', cursor:'pointer', fontSize:'11px', fontWeight:500, color:active?'#0F6E56':'transparent', transition:'all 0.15s' }}>
                        {active?'✓':''}
                      </button>
                    );
                  })}
                </React.Fragment>
              ))}
            </div>
          </div>
          <div style={{ padding:'12px 24px', borderTop:'0.5px solid rgba(0,0,0,0.07)', display:'flex', gap:'16px', background:'var(--color-background-secondary,#f8f7f4)' }}>
            {[{bg:'#EAF3DE',border:'#C0DD97',label:'Available'},{bg:'var(--color-background-secondary,#f8f7f4)',border:'rgba(0,0,0,0.08)',label:'Unavailable'}].map(l=>(
              <div key={l.label} style={{ display:'flex', alignItems:'center', gap:'6px' }}>
                <div style={{ width:'14px', height:'14px', borderRadius:'3px', background:l.bg, border:`0.5px solid ${l.border}` }}/>
                <span style={{ fontSize:'12px', color:'var(--color-text-secondary)' }}>{l.label}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add Meeting Modal */}
      {showModal && selectedDate && (
        <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.35)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:50 }}>
          <div style={{ background:'var(--color-background-primary,#fff)', borderRadius:'16px', padding:'24px', width:'380px', border:'0.5px solid rgba(0,0,0,0.08)' }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'4px' }}>
              <h3 style={{ fontSize:'15px', fontWeight:500, margin:0 }}>Schedule meeting</h3>
              <button onClick={()=>setShowModal(false)} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--color-text-secondary)', padding:'4px' }}><X size={16}/></button>
            </div>
            <p style={{ fontSize:'12px', color:'var(--color-text-secondary)', margin:'0 0 16px' }}>{selectedDate.getDate()} {MONTHS[selectedDate.getMonth()]} {selectedDate.getFullYear()}</p>
            <div style={{ display:'flex', flexDirection:'column', gap:'12px' }}>
              {[{k:'title',label:'Title',ph:'e.g. Pitch Review'},{k:'with',label:'With',ph:"Person's name"}].map(f=>(
                <div key={f.k}>
                  <label style={{ display:'block', fontSize:'11px', fontWeight:500, color:'var(--color-text-secondary)', marginBottom:'4px', textTransform:'uppercase', letterSpacing:'0.05em' }}>{f.label}</label>
                  <input value={(newM as any)[f.k]} onChange={e=>setNewM(p=>({...p,[f.k]:e.target.value}))} placeholder={f.ph} style={{ width:'100%', padding:'8px 11px', border:'0.5px solid rgba(0,0,0,0.12)', borderRadius:'8px', fontSize:'13px', outline:'none', background:'var(--color-background-primary,#fff)', color:'var(--color-text-primary)', boxSizing:'border-box' as const }}/>
                </div>
              ))}
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'10px' }}>
                <div>
                  <label style={{ display:'block', fontSize:'11px', fontWeight:500, color:'var(--color-text-secondary)', marginBottom:'4px', textTransform:'uppercase', letterSpacing:'0.05em' }}>Time</label>
                  <select value={newM.time} onChange={e=>setNewM(p=>({...p,time:e.target.value}))} style={{ width:'100%', padding:'8px 11px', border:'0.5px solid rgba(0,0,0,0.12)', borderRadius:'8px', fontSize:'13px', background:'var(--color-background-primary,#fff)', outline:'none', color:'var(--color-text-primary)' }}>
                    {TIME_SLOTS.map(s=><option key={s}>{s}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ display:'block', fontSize:'11px', fontWeight:500, color:'var(--color-text-secondary)', marginBottom:'4px', textTransform:'uppercase', letterSpacing:'0.05em' }}>Duration</label>
                  <select value={newM.duration} onChange={e=>setNewM(p=>({...p,duration:+e.target.value}))} style={{ width:'100%', padding:'8px 11px', border:'0.5px solid rgba(0,0,0,0.12)', borderRadius:'8px', fontSize:'13px', background:'var(--color-background-primary,#fff)', outline:'none', color:'var(--color-text-primary)' }}>
                    {[15,30,45,60].map(d=><option key={d} value={d}>{d} min</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label style={{ display:'block', fontSize:'11px', fontWeight:500, color:'var(--color-text-secondary)', marginBottom:'4px', textTransform:'uppercase', letterSpacing:'0.05em' }}>Type</label>
                <div style={{ display:'flex', gap:'8px' }}>
                  {(['video','in-person'] as const).map(t=>(
                    <button key={t} onClick={()=>setNewM(p=>({...p,type:t}))} style={{ flex:1, padding:'8px', border:`0.5px solid ${newM.type===t?'#1D9E75':'rgba(0,0,0,0.12)'}`, borderRadius:'8px', background:newM.type===t?'#EAF3DE':'var(--color-background-primary,#fff)', color:newM.type===t?'#0F6E56':'var(--color-text-secondary)', cursor:'pointer', fontSize:'12px', fontWeight:500, display:'flex', alignItems:'center', justifyContent:'center', gap:'5px' }}>
                      {t==='video'?<Video size={12}/>:<MapPin size={12}/>} {t}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div style={{ display:'flex', gap:'8px', marginTop:'16px' }}>
              <button onClick={()=>setShowModal(false)} style={{ flex:1, padding:'9px', border:'0.5px solid rgba(0,0,0,0.12)', borderRadius:'9px', background:'var(--color-background-primary,#fff)', cursor:'pointer', fontSize:'13px', color:'var(--color-text-secondary)' }}>Cancel</button>
              <button onClick={handleAdd} style={{ flex:1, padding:'9px', border:'none', borderRadius:'9px', background:'#1D9E75', color:'#fff', cursor:'pointer', fontSize:'13px', fontWeight:500 }}>Schedule</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};