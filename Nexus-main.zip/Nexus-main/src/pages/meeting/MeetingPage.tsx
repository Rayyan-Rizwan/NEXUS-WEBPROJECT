import React from 'react';
import { MeetingCalendar } from './MeetingCalender';

export const MeetingsPage: React.FC = () => {
  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,-apple-system,sans-serif)', color: 'var(--color-text-primary)' }}>
      <MeetingCalendar />
    </div>
  );
};