import React, { useState, useEffect, useRef } from 'react';
import {
  Mic, MicOff, Video, VideoOff, Monitor, PhoneOff, MessageCircle,
  Users, Copy, Check, Link2, Clock, Grid2X2, Maximize2, Send, X, ChevronRight
} from 'lucide-react';

type CallState = 'idle' | 'connecting' | 'active';
type ViewLayout = 'grid' | 'spotlight';

interface Participant {
  id: string; name: string; initials: string; colorIdx: number;
  isMuted: boolean; isVideoOff: boolean; isSpeaking: boolean; isHost: boolean;
}

const avatarColors = [
  { bg: '#EAF3DE', text: '#0F6E56' },
  { bg: '#EEEDFE', text: '#534AB7' },
  { bg: '#FAEEDA', text: '#854F0B' },
  { bg: '#FAECE7', text: '#993C1D' },
  { bg: '#FBEAF0', text: '#993556' },
];

const PARTICIPANTS: Participant[] = [
  { id: '1', name: 'Sarah Chen',    initials: 'SC', colorIdx: 0, isMuted: false, isVideoOff: false, isSpeaking: true,  isHost: true  },
  { id: '2', name: 'Michael Torres',initials: 'MT', colorIdx: 1, isMuted: true,  isVideoOff: false, isSpeaking: false, isHost: false },
  { id: '3', name: 'Priya Nair',    initials: 'PN', colorIdx: 2, isMuted: false, isVideoOff: true,  isSpeaking: false, isHost: false },
];

interface ChatMsg { id: string; from: string; text: string; isMe: boolean; time: string; }

const INIT_MSGS: ChatMsg[] = [
  { id: '1', from: 'Sarah Chen',     text: 'Thanks for joining everyone!', isMe: false, time: '10:02 AM' },
  { id: '2', from: 'Michael Torres', text: "Ready when you are — I've reviewed the deck.", isMe: false, time: '10:03 AM' },
];

const SCHEDULED = [
  { id: 's1', title: 'Pitch Review',  with: 'Sarah Chen',     firm: 'Sequoia', time: 'Today, 10:00 AM',  avatar: 'SC', colorIdx: 0 },
  { id: 's2', title: 'Due Diligence', with: 'Michael Torres', firm: 'a16z',    time: 'Mar 18, 2:00 PM', avatar: 'MT', colorIdx: 1 },
];

const MEETING_LINK = 'nexus.vc/call/inv-2026-abc7';

const baseCard: React.CSSProperties = {
  background: 'var(--color-background-primary,#fff)',
  border: '0.5px solid rgba(0,0,0,0.08)',
  borderRadius: '14px',
  overflow: 'hidden',
};

const VideoCallPage: React.FC = () => {
  const [callState, setCallState] = useState<CallState>('idle');
  const [layout, setLayout] = useState<ViewLayout>('grid');
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [showParticipants, setShowParticipants] = useState(false);
  const [spotlightId, setSpotlightId] = useState<string | null>(null);
  const [chatInput, setChatInput] = useState('');
  const [messages, setMessages] = useState<ChatMsg[]>(INIT_MSGS);
  const [copied, setCopied] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [unread, setUnread] = useState(0);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let t: ReturnType<typeof setInterval>;
    if (callState === 'active') {
      t = setInterval(() => setElapsed(p => p + 1), 1000);
    }
    return () => clearInterval(t);
  }, [callState]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleStart = () => {
    setCallState('connecting');
    setTimeout(() => setCallState('active'), 1800);
  };

  const handleEnd = () => {
    setCallState('idle');
    setElapsed(0);
    setIsScreenSharing(false);
    setIsMuted(false);
    setIsVideoOff(false);
    setShowChat(false);
    setShowParticipants(false);
  };

  const formatTime = (s: number) =>
    `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

  const handleCopy = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const sendChat = () => {
    if (!chatInput.trim()) return;
    setMessages(p => [...p, {
      id: Date.now().toString(), from: 'You', text: chatInput, isMe: true,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    }]);
    setChatInput('');
  };

  const toggleChat = () => {
    const next = !showChat;
    setShowChat(next);
    if (next) { setUnread(0); setShowParticipants(false); }
  };

  const allParticipants: Participant[] = [
    ...PARTICIPANTS,
    { id: 'you', name: 'You', initials: 'AK', colorIdx: 3, isMuted, isVideoOff, isSpeaking: false, isHost: false },
  ];
  const spotlight = allParticipants.find(p => p.id === spotlightId) ?? allParticipants[0];
  const sideParticipants = allParticipants.filter(p => p.id !== spotlight.id);

  const ParticipantTile = ({ p, large = false, onClick }: { p: Participant; large?: boolean; onClick?: () => void }) => {
    const c = avatarColors[p.colorIdx % avatarColors.length];
    const isYou = p.id === 'you';
    return (
      <div onClick={onClick} style={{
        position: 'relative', borderRadius: '12px', overflow: 'hidden',
        background: '#1A1A1A', cursor: onClick ? 'pointer' : 'default',
        border: isYou ? '2px solid #1D9E75' : p.isSpeaking ? '2px solid rgba(29,158,117,0.45)' : '1px solid rgba(255,255,255,0.06)',
        aspectRatio: large ? 'unset' : '16/9',
        flex: large ? 1 : 'unset',
        minHeight: large ? '100%' : 'unset',
      }}>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ width: large ? '72px' : '44px', height: large ? '72px' : '44px', borderRadius: '50%', background: c.bg, color: c.text, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: large ? '24px' : '15px', fontWeight: 500 }}>
            {p.initials}
          </div>
        </div>
        {p.isSpeaking && (
          <div style={{ position: 'absolute', bottom: large ? '14px' : '8px', left: large ? '14px' : '8px', display: 'flex', alignItems: 'flex-end', gap: '2px', height: '14px' }}>
            {[4,8,6,10,5].map((h, i) => (
              <div key={i} style={{ width: '3px', height: `${h}px`, background: '#1D9E75', borderRadius: '2px', animation: `pulse ${0.5 + i * 0.1}s ease-in-out infinite alternate` }} />
            ))}
          </div>
        )}
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: large ? '32px 14px 12px' : '20px 8px 6px', background: 'linear-gradient(transparent, rgba(0,0,0,0.65))' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
            <span style={{ fontSize: large ? '13px' : '11px', fontWeight: 500, color: '#fff' }}>{isYou ? 'You' : p.name}</span>
            {p.isHost && <span style={{ fontSize: '9px', fontWeight: 500, padding: '1px 5px', borderRadius: '4px', background: '#1D9E75', color: '#fff' }}>HOST</span>}
            {isYou && isScreenSharing && <span style={{ fontSize: '9px', fontWeight: 500, padding: '1px 5px', borderRadius: '4px', background: '#BA7517', color: '#fff' }}>SHARING</span>}
          </div>
        </div>
        <div style={{ position: 'absolute', top: '8px', right: '8px', display: 'flex', gap: '4px' }}>
          {p.isMuted && <div style={{ width: '20px', height: '20px', borderRadius: '50%', background: '#D85A30', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><MicOff size={10} color="#fff" /></div>}
          {p.isVideoOff && <div style={{ width: '20px', height: '20px', borderRadius: '50%', background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><VideoOff size={10} color="#fff" /></div>}
        </div>
      </div>
    );
  };

  /* ── IDLE ── */
  if (callState === 'idle') return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '32px' }}>
      <div style={{ marginBottom: '28px' }}>
        <h1 style={{ fontSize: '20px', fontWeight: 500, margin: '0 0 4px', letterSpacing: '-0.01em' }}>Video calls</h1>
        <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>Start or join a meeting with your investors</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '20px' }}>
        <div style={baseCard}>
          <div style={{ height: '2px', background: '#1D9E75' }} />
          <div style={{ padding: '26px 26px 20px' }}>
            <div style={{ width: '42px', height: '42px', borderRadius: '11px', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '12px' }}>
              <Video size={19} color="#1D9E75" />
            </div>
            <h2 style={{ fontSize: '15px', fontWeight: 500, margin: '0 0 5px' }}>Start a new call</h2>
            <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: '0 0 18px', lineHeight: 1.6 }}>Create an instant meeting and share the link</p>
            <button onClick={handleStart} style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '9px 18px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '10px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>
              <Video size={13} /> Start meeting
            </button>
          </div>
          <div style={{ padding: '12px 26px', background: 'var(--color-background-secondary,#f8f7f4)', borderTop: '0.5px solid rgba(0,0,0,0.07)' }}>
            <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginBottom: '5px', fontWeight: 500 }}>Meeting link</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
              <code style={{ flex: 1, fontSize: '11px', color: 'var(--color-text-secondary)', background: 'var(--color-background-primary,#fff)', padding: '5px 9px', borderRadius: '7px', border: '0.5px solid rgba(0,0,0,0.08)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' as const }}>
                {MEETING_LINK}
              </code>
              <button onClick={handleCopy} style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '5px 10px', background: copied ? '#EAF3DE' : 'var(--color-background-primary,#fff)', color: copied ? '#0F6E56' : 'var(--color-text-secondary)', border: '0.5px solid', borderColor: copied ? '#C0DD97' : 'rgba(0,0,0,0.12)', borderRadius: '7px', cursor: 'pointer', fontSize: '11px', fontWeight: 500, flexShrink: 0, transition: 'all 0.2s' }}>
                {copied ? <Check size={11} /> : <Copy size={11} />} {copied ? 'Copied' : 'Copy'}
              </button>
            </div>
          </div>
        </div>

        <div style={baseCard}>
          <div style={{ height: '2px', background: '#7F77DD' }} />
          <div style={{ padding: '26px 26px 24px' }}>
            <div style={{ width: '42px', height: '42px', borderRadius: '11px', background: '#EEEDFE', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '12px' }}>
              <Link2 size={19} color="#7F77DD" />
            </div>
            <h2 style={{ fontSize: '15px', fontWeight: 500, margin: '0 0 5px' }}>Join with a link</h2>
            <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: '0 0 18px', lineHeight: 1.6 }}>Enter a meeting link or code to join</p>
            <div style={{ display: 'flex', gap: '7px' }}>
              <input placeholder="nexus.vc/call/..." style={{ flex: 1, padding: '8px 11px', border: '0.5px solid rgba(0,0,0,0.12)', borderRadius: '9px', fontSize: '13px', outline: 'none', background: 'var(--color-background-primary,#fff)', color: 'var(--color-text-primary)' }} />
              <button onClick={handleStart} style={{ display: 'flex', alignItems: 'center', gap: '5px', padding: '8px 14px', background: '#7F77DD', color: '#fff', border: 'none', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', fontWeight: 500, flexShrink: 0 }}>
                Join <ChevronRight size={13} />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div style={baseCard}>
        <div style={{ padding: '14px 22px', borderBottom: '0.5px solid rgba(0,0,0,0.07)' }}>
          <div style={{ fontSize: '14px', fontWeight: 500 }}>Scheduled calls</div>
          <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>Upcoming video meetings</div>
        </div>
        <div style={{ padding: '10px 22px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {SCHEDULED.map(s => {
            const c = avatarColors[s.colorIdx];
            return (
              <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '11px 14px', border: '0.5px solid rgba(0,0,0,0.07)', borderRadius: '10px', background: 'var(--color-background-secondary,#f8f7f4)' }}>
                <div style={{ width: '36px', height: '36px', borderRadius: '9px', background: c.bg, color: c.text, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px', fontWeight: 500, flexShrink: 0 }}>{s.avatar}</div>
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: '13px', fontWeight: 500, margin: '0 0 2px' }}>{s.title}</p>
                  <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                    <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>with {s.with} · {s.firm}</span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '3px', fontSize: '11px', color: 'var(--color-text-secondary)' }}><Clock size={10} />{s.time}</span>
                  </div>
                </div>
                <button onClick={handleStart} style={{ display: 'flex', alignItems: 'center', gap: '5px', padding: '6px 13px', background: '#EAF3DE', color: '#0F6E56', border: '0.5px solid #C0DD97', borderRadius: '8px', cursor: 'pointer', fontSize: '12px', fontWeight: 500, flexShrink: 0 }}>
                  <Video size={12} /> Join
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );

  /* ── CONNECTING ── */
  if (callState === 'connecting') return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', flexDirection: 'column', gap: '20px' }}>
      <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
      <div style={{ width: '52px', height: '52px', borderRadius: '50%', border: '3px solid #EAF3DE', borderTopColor: '#1D9E75', animation: 'spin 0.9s linear infinite' }} />
      <div style={{ textAlign: 'center' }}>
        <p style={{ fontSize: '15px', fontWeight: 500, margin: '0 0 4px' }}>Connecting…</p>
        <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>Joining your secure meeting room</p>
      </div>
    </div>
  );

  /* ── ACTIVE ── */
  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '16px' }}>
      <style>{`@keyframes pulse { from { transform: scaleY(0.4) } to { transform: scaleY(1) } }`}</style>

      {/* Top bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px', flexWrap: 'wrap', gap: '8px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '5px', padding: '4px 11px', background: '#EAF3DE', border: '0.5px solid #C0DD97', borderRadius: '20px' }}>
            <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#1D9E75' }} />
            <span style={{ fontSize: '11px', fontWeight: 500, color: '#0F6E56' }}>Live</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '4px 11px', background: 'var(--color-background-secondary,#f5f4f0)', border: '0.5px solid rgba(0,0,0,0.08)', borderRadius: '20px' }}>
            <Clock size={11} color="var(--color-text-secondary)" />
            <span style={{ fontSize: '11px', fontWeight: 500, color: 'var(--color-text-secondary)', fontVariantNumeric: 'tabular-nums' }}>{formatTime(elapsed)}</span>
          </div>
          <span style={{ fontSize: '12px', color: 'var(--color-text-secondary)' }}>{allParticipants.length} participants</span>
        </div>
        <div style={{ display: 'flex', gap: '6px' }}>
          {(['grid','spotlight'] as const).map(v => (
            <button key={v} onClick={() => setLayout(v)} style={{ display: 'flex', alignItems: 'center', gap: '5px', padding: '5px 12px', borderRadius: '8px', border: '0.5px solid', cursor: 'pointer', fontSize: '12px', fontWeight: layout === v ? 500 : 400, background: layout === v ? '#EAF3DE' : 'var(--color-background-primary,#fff)', color: layout === v ? '#0F6E56' : 'var(--color-text-secondary)', borderColor: layout === v ? '#C0DD97' : 'rgba(0,0,0,0.10)' }}>
              {v === 'grid' ? <Grid2X2 size={12} /> : <Maximize2 size={12} />}
              {v.charAt(0).toUpperCase() + v.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: showChat || showParticipants ? '1fr 290px' : '1fr', gap: '12px', alignItems: 'start' }}>

        {/* Video area */}
        <div>
          {layout === 'grid' ? (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '10px' }}>
              {allParticipants.map(p => (
                <ParticipantTile key={p.id} p={p} onClick={() => { setLayout('spotlight'); setSpotlightId(p.id); }} />
              ))}
            </div>
          ) : (
            <div style={{ marginBottom: '10px' }}>
              <div style={{ height: '360px', marginBottom: '7px', display: 'flex' }}>
                <ParticipantTile p={spotlight} large onClick={() => setLayout('grid')} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(130px,1fr))', gap: '6px' }}>
                {sideParticipants.map(p => (
                  <div key={p.id} onClick={() => setSpotlightId(p.id)} style={{ cursor: 'pointer' }}>
                    <ParticipantTile p={p} />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Controls */}
          <div style={{ background: 'var(--color-background-primary,#fff)', border: '0.5px solid rgba(0,0,0,0.08)', borderRadius: '14px', padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', flexWrap: 'wrap' }}>
            {[
              { label: isMuted ? 'Unmute' : 'Mute', icon: isMuted ? <MicOff size={17} /> : <Mic size={17} />, active: isMuted, danger: isMuted, onClick: () => setIsMuted(p => !p) },
              { label: isVideoOff ? 'Start cam' : 'Stop cam', icon: isVideoOff ? <VideoOff size={17} /> : <Video size={17} />, active: isVideoOff, danger: isVideoOff, onClick: () => setIsVideoOff(p => !p) },
              { label: isScreenSharing ? 'Sharing' : 'Share', icon: <Monitor size={17} />, active: isScreenSharing, success: isScreenSharing, onClick: () => setIsScreenSharing(p => !p) },
            ].map(btn => (
              <button key={btn.label} onClick={btn.onClick} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '3px', padding: '9px 14px', borderRadius: '10px', border: '0.5px solid', cursor: 'pointer', minWidth: '68px', transition: 'all 0.15s', background: btn.danger ? '#FAECE7' : btn.success ? '#EAF3DE' : 'var(--color-background-secondary,#f8f7f4)', color: btn.danger ? '#993C1D' : btn.success ? '#0F6E56' : 'var(--color-text-secondary)', borderColor: btn.danger ? '#F5C4B3' : btn.success ? '#C0DD97' : 'rgba(0,0,0,0.10)' }}>
                {btn.icon}
                <span style={{ fontSize: '10px', fontWeight: 500 }}>{btn.label}</span>
              </button>
            ))}

            <button onClick={handleEnd} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '3px', padding: '9px 18px', borderRadius: '10px', border: 'none', cursor: 'pointer', background: '#D85A30', color: '#fff', minWidth: '68px' }}>
              <PhoneOff size={17} />
              <span style={{ fontSize: '10px', fontWeight: 500 }}>End</span>
            </button>

            <button onClick={toggleChat} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '3px', padding: '9px 14px', borderRadius: '10px', border: '0.5px solid', cursor: 'pointer', minWidth: '68px', background: showChat ? '#EAF3DE' : 'var(--color-background-secondary,#f8f7f4)', color: showChat ? '#0F6E56' : 'var(--color-text-secondary)', borderColor: showChat ? '#C0DD97' : 'rgba(0,0,0,0.10)', position: 'relative' }}>
              <MessageCircle size={17} />
              <span style={{ fontSize: '10px', fontWeight: 500 }}>Chat</span>
              {unread > 0 && <span style={{ position: 'absolute', top: '5px', right: '5px', width: '15px', height: '15px', borderRadius: '50%', background: '#D85A30', color: '#fff', fontSize: '9px', fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{unread}</span>}
            </button>

            <button onClick={() => { setShowParticipants(p => !p); if (!showParticipants) setShowChat(false); }} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '3px', padding: '9px 14px', borderRadius: '10px', border: '0.5px solid', cursor: 'pointer', minWidth: '68px', background: showParticipants ? '#EAF3DE' : 'var(--color-background-secondary,#f8f7f4)', color: showParticipants ? '#0F6E56' : 'var(--color-text-secondary)', borderColor: showParticipants ? '#C0DD97' : 'rgba(0,0,0,0.10)' }}>
              <Users size={17} />
              <span style={{ fontSize: '10px', fontWeight: 500 }}>People</span>
            </button>
          </div>
        </div>

        {/* Side panel */}
        {(showChat || showParticipants) && (
          <div style={{ background: 'var(--color-background-primary,#fff)', border: '0.5px solid rgba(0,0,0,0.08)', borderRadius: '14px', overflow: 'hidden', display: 'flex', flexDirection: 'column', height: '500px' }}>
            <div style={{ padding: '11px 15px', borderBottom: '0.5px solid rgba(0,0,0,0.07)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: '13px', fontWeight: 500 }}>{showChat ? 'Meeting chat' : `People (${allParticipants.length})`}</span>
              <button onClick={() => { setShowChat(false); setShowParticipants(false); }} style={{ width: '24px', height: '24px', borderRadius: '6px', border: 'none', background: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--color-text-secondary)' }}><X size={13} /></button>
            </div>

            {showChat && (
              <>
                <div style={{ flex: 1, padding: '10px 12px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '10px', background: 'var(--color-background-secondary,#f8f7f4)' }}>
                  {messages.map(msg => (
                    <div key={msg.id} style={{ display: 'flex', flexDirection: 'column', alignItems: msg.isMe ? 'flex-end' : 'flex-start' }}>
                      {!msg.isMe && <span style={{ fontSize: '10px', fontWeight: 500, color: 'var(--color-text-secondary)', marginBottom: '3px' }}>{msg.from}</span>}
                      <div style={{ maxWidth: '88%', padding: '7px 10px', borderRadius: msg.isMe ? '10px 10px 3px 10px' : '10px 10px 10px 3px', background: msg.isMe ? '#1D9E75' : 'var(--color-background-primary,#fff)', color: msg.isMe ? '#fff' : 'var(--color-text-primary)', fontSize: '12px', lineHeight: 1.5, border: msg.isMe ? 'none' : '0.5px solid rgba(0,0,0,0.07)' }}>
                        {msg.text}
                      </div>
                      <span style={{ fontSize: '10px', color: 'var(--color-text-tertiary,#b0b0b0)', marginTop: '2px' }}>{msg.time}</span>
                    </div>
                  ))}
                  <div ref={chatEndRef} />
                </div>
                <div style={{ padding: '9px 11px', borderTop: '0.5px solid rgba(0,0,0,0.07)', display: 'flex', gap: '6px' }}>
                  <input value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendChat()} placeholder="Send a message…" style={{ flex: 1, padding: '7px 9px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '8px', fontSize: '12px', outline: 'none', background: 'var(--color-background-secondary,#f8f7f4)', color: 'var(--color-text-primary)' }} />
                  <button onClick={sendChat} disabled={!chatInput.trim()} style={{ width: '30px', height: '30px', borderRadius: '8px', border: 'none', background: chatInput.trim() ? '#1D9E75' : 'rgba(0,0,0,0.08)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: chatInput.trim() ? 'pointer' : 'default', flexShrink: 0 }}>
                    <Send size={12} />
                  </button>
                </div>
              </>
            )}

            {showParticipants && (
              <div style={{ flex: 1, overflowY: 'auto', padding: '6px 0' }}>
                {allParticipants.map(p => {
                  const c = avatarColors[p.colorIdx % avatarColors.length];
                  return (
                    <div key={p.id} style={{ display: 'flex', alignItems: 'center', gap: '9px', padding: '9px 14px' }}>
                      <div style={{ width: '30px', height: '30px', borderRadius: '50%', background: c.bg, color: c.text, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', fontWeight: 500, flexShrink: 0 }}>{p.initials}</div>
                      <div style={{ flex: 1 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                          <span style={{ fontSize: '13px', fontWeight: 500 }}>{p.id === 'you' ? 'You' : p.name}</span>
                          {p.isHost && <span style={{ fontSize: '9px', fontWeight: 500, padding: '1px 5px', borderRadius: '4px', background: '#EAF3DE', color: '#0F6E56' }}>HOST</span>}
                        </div>
                      </div>
                      <div style={{ display: 'flex', gap: '4px' }}>
                        <div style={{ width: '20px', height: '20px', borderRadius: '50%', background: p.isMuted ? '#FAECE7' : '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          {p.isMuted ? <MicOff size={10} color="#993C1D" /> : <Mic size={10} color="#1D9E75" />}
                        </div>
                        <div style={{ width: '20px', height: '20px', borderRadius: '50%', background: p.isVideoOff ? 'rgba(0,0,0,0.06)' : '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          {p.isVideoOff ? <VideoOff size={10} color="var(--color-text-secondary)" /> : <Video size={10} color="#1D9E75" />}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default VideoCallPage;