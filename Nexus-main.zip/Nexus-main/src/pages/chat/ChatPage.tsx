import React, { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { Send, Phone, Video, Info, Smile, Search, MessageCircle, MoreVertical } from 'lucide-react';
import { Avatar } from '../../components/ui/Avatar';
import { ChatMessage } from '../../components/chat/ChatMessage';
import { ChatUserList } from '../../components/chat/ChatUserList';
import { useAuth } from '../../context/AuthContext';
import { Message } from '../../types';
import { findUserById } from '../../data/users';
import { getMessagesBetweenUsers, sendMessage, getConversationsForUser } from '../../data/messages';

const avatarColors = ['#EAF3DE', '#EEEDFE', '#FAEEDA', '#FAECE7', '#FBEAF0'];
const avatarTextColors = ['#0F6E56', '#534AB7', '#854F0B', '#993C1D', '#993556'];

export const ChatPage: React.FC = () => {
  const { userId } = useParams<{ userId: string }>();
  const { user: currentUser } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [conversations, setConversations] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const messagesEndRef = useRef<null | HTMLDivElement>(null);

  const chatPartner = userId ? findUserById(userId) : null;

  useEffect(() => {
    if (currentUser) setConversations(getConversationsForUser(currentUser.id));
  }, [currentUser]);

  useEffect(() => {
    if (currentUser && userId) setMessages(getMessagesBetweenUsers(currentUser.id, userId));
  }, [currentUser, userId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !currentUser || !userId) return;
    const msg = sendMessage({ senderId: currentUser.id, receiverId: userId, content: newMessage });
    setMessages(prev => [...prev, msg]);
    setNewMessage('');
    setConversations(getConversationsForUser(currentUser.id));
  };

  if (!currentUser) return null;

  const initials = chatPartner?.name.split(' ').map((w: string) => w[0]).join('').slice(0, 2) || '??';
  const colorIdx = initials.charCodeAt(0) % avatarColors.length;

  return (
    <div style={{
      display: 'flex',
      height: 'calc(100vh - 5rem)',
      background: 'var(--color-background-primary,#fff)',
      border: '0.5px solid rgba(0,0,0,0.08)',
      borderRadius: '14px',
      overflow: 'hidden',
      fontFamily: 'var(--font-sans,system-ui,sans-serif)',
    }}>

      {/* Sidebar */}
      <div style={{ width: '272px', borderRight: '0.5px solid rgba(0,0,0,0.07)', display: 'flex', flexDirection: 'column', flexShrink: 0, background: 'var(--color-background-primary,#fff)' }}>
        {/* Sidebar header */}
        <div style={{ padding: '16px 20px', borderBottom: '0.5px solid rgba(0,0,0,0.07)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
            <h2 style={{ fontSize: '15px', fontWeight: 500, margin: 0 }}>Messages</h2>
            <button style={{ width: '28px', height: '28px', borderRadius: '7px', border: 'none', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="#1D9E75" strokeWidth="1.5"><line x1="6" y1="1" x2="6" y2="11"/><line x1="1" y1="6" x2="11" y2="6"/></svg>
            </button>
          </div>
          <div style={{ position: 'relative' }}>
            <Search size={13} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: 'var(--color-text-tertiary,#b0b0b0)' }} />
            <input
              placeholder="Search conversations…"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              style={{ width: '100%', padding: '7px 10px 7px 28px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '8px', fontSize: '12px', outline: 'none', background: 'var(--color-background-secondary,#f8f7f4)', color: 'var(--color-text-primary)', boxSizing: 'border-box' as const }}
            />
          </div>
        </div>
        <div style={{ flex: 1, overflowY: 'auto' }}>
          <ChatUserList conversations={conversations} />
        </div>
      </div>

      {/* Chat area */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        {chatPartner ? (
          <>
            {/* Chat header */}
            <div style={{ padding: '12px 24px', borderBottom: '0.5px solid rgba(0,0,0,0.07)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0, background: 'var(--color-background-primary,#fff)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{ position: 'relative' }}>
                  <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: avatarColors[colorIdx], color: avatarTextColors[colorIdx], display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '12px', fontWeight: 500 }}>
                    {initials}
                  </div>
                  {chatPartner.isOnline && (
                    <span style={{ position: 'absolute', bottom: '1px', right: '1px', width: '8px', height: '8px', borderRadius: '50%', background: '#1D9E75', border: '1.5px solid var(--color-background-primary,#fff)' }} />
                  )}
                </div>
                <div>
                  <h3 style={{ fontSize: '14px', fontWeight: 500, margin: 0 }}>{chatPartner.name}</h3>
                  <p style={{ fontSize: '11px', color: chatPartner.isOnline ? '#1D9E75' : 'var(--color-text-secondary)', margin: 0, fontWeight: chatPartner.isOnline ? 500 : 400 }}>
                    {chatPartner.isOnline ? 'Online now' : 'Last seen recently'}
                  </p>
                </div>
              </div>
              <div style={{ display: 'flex', gap: '4px' }}>
                {[
                  { icon: <Phone size={15} />, tip: 'Voice call' },
                  { icon: <Video size={15} />, tip: 'Video call' },
                  { icon: <Info size={15} />, tip: 'Profile' },
                  { icon: <MoreVertical size={15} />, tip: 'More' },
                ].map((btn, i) => (
                  <button key={i} title={btn.tip} style={{ width: '32px', height: '32px', borderRadius: '8px', border: '0.5px solid rgba(0,0,0,0.10)', background: 'var(--color-background-primary,#fff)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'var(--color-text-secondary)' }}
                    onMouseEnter={e => { e.currentTarget.style.background = '#EAF3DE'; e.currentTarget.style.color = '#0F6E56'; e.currentTarget.style.borderColor = '#C0DD97'; }}
                    onMouseLeave={e => { e.currentTarget.style.background = 'var(--color-background-primary,#fff)'; e.currentTarget.style.color = 'var(--color-text-secondary)'; e.currentTarget.style.borderColor = 'rgba(0,0,0,0.10)'; }}>
                    {btn.icon}
                  </button>
                ))}
              </div>
            </div>

            {/* Messages */}
            <div style={{ flex: 1, padding: '20px 24px', overflowY: 'auto', background: 'var(--color-background-secondary,#f8f7f4)', display: 'flex', flexDirection: 'column', gap: '2px' }}>
              {messages.length > 0 ? (
                <>
                  <div style={{ textAlign: 'center', marginBottom: '16px' }}>
                    <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)', background: 'var(--color-background-primary,#fff)', padding: '4px 12px', borderRadius: '20px', border: '0.5px solid rgba(0,0,0,0.08)' }}>Today</span>
                  </div>
                  {messages.map(msg => (
                    <ChatMessage key={msg.id} message={msg} isCurrentUser={msg.senderId === currentUser.id} />
                  ))}
                  <div ref={messagesEndRef} />
                </>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flex: 1, gap: '12px' }}>
                  <div style={{ width: '52px', height: '52px', borderRadius: '14px', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <MessageCircle size={24} color="#1D9E75" />
                  </div>
                  <div style={{ textAlign: 'center' }}>
                    <p style={{ fontSize: '14px', fontWeight: 500, margin: '0 0 4px' }}>No messages yet</p>
                    <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: 0 }}>Send a message to start the conversation</p>
                  </div>
                </div>
              )}
            </div>

            {/* Input */}
            <div style={{ padding: '12px 20px', borderTop: '0.5px solid rgba(0,0,0,0.07)', background: 'var(--color-background-primary,#fff)', flexShrink: 0 }}>
              <form onSubmit={handleSend} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <button type="button" style={{ width: '32px', height: '32px', borderRadius: '8px', border: 'none', background: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'var(--color-text-tertiary,#b0b0b0)', flexShrink: 0 }}>
                  <Smile size={17} />
                </button>
                <input
                  type="text"
                  placeholder="Type a message…"
                  value={newMessage}
                  onChange={e => setNewMessage(e.target.value)}
                  style={{ flex: 1, padding: '9px 16px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '22px', fontSize: '13px', outline: 'none', background: 'var(--color-background-secondary,#f8f7f4)', color: 'var(--color-text-primary)' }}
                />
                <button
                  type="submit"
                  disabled={!newMessage.trim()}
                  style={{ width: '34px', height: '34px', borderRadius: '50%', border: 'none', background: newMessage.trim() ? '#1D9E75' : 'rgba(0,0,0,0.08)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: newMessage.trim() ? 'pointer' : 'default', flexShrink: 0, transition: 'all 0.15s' }}>
                  <Send size={14} />
                </button>
              </form>
            </div>
          </>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flex: 1, gap: '16px' }}>
            <div style={{ width: '60px', height: '60px', borderRadius: '16px', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <MessageCircle size={28} color="#1D9E75" />
            </div>
            <div style={{ textAlign: 'center' }}>
              <h3 style={{ fontSize: '15px', fontWeight: 500, margin: '0 0 4px' }}>Select a conversation</h3>
              <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>Choose a contact to start chatting</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};