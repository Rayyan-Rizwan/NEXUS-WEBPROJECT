import React, { useState, useRef, useEffect } from 'react';
import {
  Shield, Lock, Smartphone, Key, Eye, EyeOff, Check, X,
  AlertCircle, CheckCircle, RefreshCw, Clock, LogOut, Monitor,
  Activity, ChevronRight, Zap
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75', mid: '#C0DD97' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD', mid: '#AFA9EC' },
  amber:   { bg: '#FAEEDA', text: '#854F0B', fill: '#BA7517', mid: '#FAC775' },
  coral:   { bg: '#FAECE7', text: '#993C1D', fill: '#D85A30', mid: '#F5C4B3' },
};

const baseCard: React.CSSProperties = {
  background: 'var(--color-background-primary,#fff)',
  border: '0.5px solid rgba(0,0,0,0.08)',
  borderRadius: '14px',
  overflow: 'hidden',
};

const panelHead: React.CSSProperties = {
  padding: '16px 24px',
  borderBottom: '0.5px solid rgba(0,0,0,0.07)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
};

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '9px 12px',
  border: '0.5px solid rgba(0,0,0,0.12)',
  borderRadius: '9px',
  fontSize: '13px',
  outline: 'none',
  background: 'var(--color-background-primary,#fff)',
  color: 'var(--color-text-primary)',
  boxSizing: 'border-box',
};

const labelStyle: React.CSSProperties = {
  display: 'block',
  fontSize: '11px',
  fontWeight: 500,
  color: 'var(--color-text-secondary)',
  marginBottom: '5px',
  textTransform: 'uppercase',
  letterSpacing: '0.05em',
};

function getPasswordStrength(pw: string): { score: number; label: string; color: string } {
  let score = 0;
  if (pw.length >= 8)  score++;
  if (pw.length >= 12) score++;
  if (/[A-Z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  const levels = [
    { label: 'Too short', color: '#D85A30' },
    { label: 'Weak',      color: '#D85A30' },
    { label: 'Fair',      color: '#BA7517' },
    { label: 'Good',      color: '#BA7517' },
    { label: 'Strong',    color: '#1D9E75' },
    { label: 'Very strong',color: '#1D9E75' },
  ];
  return { score, ...levels[Math.min(score, levels.length - 1)] };
}

const SESSIONS = [
  { device: 'MacBook Pro', location: 'Rawalpindi, PK', time: 'Active now',     current: true  },
  { device: 'iPhone 15',   location: 'Lahore, PK',    time: '2 hours ago',    current: false },
  { device: 'Chrome / Win',location: 'Karachi, PK',   time: '3 days ago',     current: false },
];

export const SecurityPage: React.FC = () => {
  const { user } = useAuth();
  const [activeSection, setActiveSection] = useState<'password'|'2fa'|'sessions'|'roles'>('password');

  // Password section
  const [currentPw,  setCurrentPw]  = useState('');
  const [newPw,      setNewPw]      = useState('');
  const [confirmPw,  setConfirmPw]  = useState('');
  const [showCurrent,setShowCurrent]= useState(false);
  const [showNew,    setShowNew]    = useState(false);
  const [showConf,   setShowConf]   = useState(false);
  const [pwSaved,    setPwSaved]    = useState(false);
  const strength = getPasswordStrength(newPw);
  const mismatch = confirmPw.length > 0 && newPw !== confirmPw;

  // 2FA section
  const [twoFaEnabled, setTwoFaEnabled] = useState(false);
  const [twoFaStep, setTwoFaStep] = useState<'idle'|'qr'|'otp'|'done'>('idle');
  const [otp, setOtp] = useState(['','','','','','']);
  const [otpError, setOtpError] = useState(false);
  const [otpSuccess, setOtpSuccess] = useState(false);
  const otpRefs = useRef<(HTMLInputElement|null)[]>([]);

  const handleOtpChange = (i: number, v: string) => {
    if (!/^\d*$/.test(v)) return;
    const next = [...otp];
    next[i] = v.slice(-1);
    setOtp(next);
    setOtpError(false);
    if (v && i < 5) otpRefs.current[i+1]?.focus();
  };

  const handleOtpKeyDown = (i: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[i] && i > 0) otpRefs.current[i-1]?.focus();
  };

  const verifyOtp = () => {
    const code = otp.join('');
    if (code === '123456') {
      setOtpSuccess(true);
      setTwoFaEnabled(true);
      setTimeout(() => { setTwoFaStep('done'); setOtpSuccess(false); }, 1500);
    } else {
      setOtpError(true);
      setOtp(['','','','','','']);
      otpRefs.current[0]?.focus();
    }
  };

  const savePassword = () => {
    if (!newPw || mismatch || strength.score < 2) return;
    setPwSaved(true);
    setCurrentPw(''); setNewPw(''); setConfirmPw('');
    setTimeout(() => setPwSaved(false), 2500);
  };

  const PasswordField = ({ label, value, onChange, show, setShow, error }: any) => (
    <div>
      <label style={labelStyle}>{label}</label>
      <div style={{ position: 'relative' }}>
        <input type={show ? 'text' : 'password'} value={value} onChange={e => onChange(e.target.value)}
          placeholder="••••••••"
          onFocus={e => (e.currentTarget.style.borderColor = '#1D9E75')}
          onBlur={e => (e.currentTarget.style.borderColor = error ? '#D85A30' : 'rgba(0,0,0,0.12)')}
          style={{ ...inputStyle, paddingRight: '38px', borderColor: error ? '#D85A30' : 'rgba(0,0,0,0.12)' }} />
        <button type="button" onClick={() => setShow((p: boolean) => !p)}
          style={{ position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--color-text-tertiary,#b0b0b0)', display: 'flex', alignItems: 'center' }}>
          {show ? <EyeOff size={14}/> : <Eye size={14}/>}
        </button>
      </div>
      {error && <p style={{ fontSize: '11px', color: '#D85A30', margin: '4px 0 0' }}>{error}</p>}
    </div>
  );

  const navItems = [
    { key: 'password', label: 'Password',        icon: <Lock size={14}/> },
    { key: '2fa',      label: '2FA / Multi-step', icon: <Smartphone size={14}/> },
    { key: 'sessions', label: 'Active sessions',  icon: <Monitor size={14}/> },
    { key: 'roles',    label: 'Role & access',    icon: <Shield size={14}/> },
  ] as const;

  if (!user) return null;

  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '32px' }}>

      {/* Header */}
      <div style={{ marginBottom: '28px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '4px' }}>
          <div style={{ width: '28px', height: '28px', borderRadius: '7px', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Shield size={14} color="#1D9E75"/>
          </div>
          <h1 style={{ fontSize: '20px', fontWeight: 500, margin: 0, letterSpacing: '-0.01em' }}>Security & access</h1>
        </div>
        <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0, paddingLeft: '38px' }}>Manage your security settings, 2FA, and role-based access</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: '16px', alignItems: 'start' }}>

        {/* Nav */}
        <div style={baseCard}>
          <div style={{ padding: '6px 0' }}>
            {navItems.map(item => {
              const active = activeSection === item.key;
              return (
                <button key={item.key} onClick={() => setActiveSection(item.key)}
                  style={{ display: 'flex', alignItems: 'center', gap: '9px', width: '100%', padding: '10px 16px', background: active ? '#EAF3DE' : 'none', border: 'none', cursor: 'pointer', fontSize: '13px', fontWeight: active ? 500 : 400, color: active ? '#0F6E56' : 'var(--color-text-secondary)', textAlign: 'left', borderLeft: active ? '2px solid #1D9E75' : '2px solid transparent', transition: 'all 0.12s' }}
                  onMouseEnter={e => { if (!active) { (e.currentTarget as HTMLElement).style.background = 'var(--color-background-secondary,#f8f7f4)'; } }}
                  onMouseLeave={e => { if (!active) { (e.currentTarget as HTMLElement).style.background = 'none'; } }}>
                  {item.icon} {item.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Content */}
        <div>

          {/* PASSWORD */}
          {activeSection === 'password' && (
            <div style={baseCard}>
              <div style={panelHead}>
                <div>
                  <div style={{ fontSize: '14px', fontWeight: 500 }}>Change password</div>
                  <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>Use a strong, unique password</div>
                </div>
                {pwSaved && (
                  <span style={{ display: 'flex', alignItems: 'center', gap: '5px', fontSize: '12px', fontWeight: 500, color: '#1D9E75' }}>
                    <CheckCircle size={13}/> Saved
                  </span>
                )}
              </div>
              <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <PasswordField label="Current password"    value={currentPw}  onChange={setCurrentPw}  show={showCurrent} setShow={setShowCurrent} />
                <PasswordField label="New password"        value={newPw}      onChange={setNewPw}      show={showNew}     setShow={setShowNew} />

                {/* Strength meter */}
                {newPw.length > 0 && (
                  <div>
                    <div style={{ display: 'flex', gap: '4px', marginBottom: '6px' }}>
                      {[1,2,3,4,5].map(i => (
                        <div key={i} style={{ flex: 1, height: '4px', borderRadius: '2px', background: i <= strength.score ? strength.color : 'rgba(0,0,0,0.08)', transition: 'background 0.25s' }} />
                      ))}
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: '11px', fontWeight: 500, color: strength.color }}>{strength.label}</span>
                      <div style={{ display: 'flex', gap: '12px' }}>
                        {[
                          { ok: newPw.length >= 8,       label: '8+ chars' },
                          { ok: /[A-Z]/.test(newPw),     label: 'Uppercase' },
                          { ok: /[0-9]/.test(newPw),     label: 'Number' },
                          { ok: /[^A-Za-z0-9]/.test(newPw), label: 'Symbol' },
                        ].map((r,i) => (
                          <span key={i} style={{ display: 'flex', alignItems: 'center', gap: '3px', fontSize: '10px', color: r.ok ? '#1D9E75' : 'var(--color-text-tertiary,#b0b0b0)' }}>
                            {r.ok ? <Check size={10}/> : <X size={10}/>} {r.label}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                <PasswordField label="Confirm new password" value={confirmPw} onChange={setConfirmPw} show={showConf} setShow={setShowConf}
                  error={mismatch ? 'Passwords do not match' : undefined} />

                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px', paddingTop: '4px' }}>
                  <button onClick={() => { setCurrentPw(''); setNewPw(''); setConfirmPw(''); }}
                    style={{ padding: '9px 18px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '9px', background: 'none', cursor: 'pointer', fontSize: '13px', color: 'var(--color-text-secondary)' }}>
                    Cancel
                  </button>
                  <button onClick={savePassword} disabled={!newPw || mismatch || strength.score < 2}
                    style={{ padding: '9px 18px', background: (!newPw || mismatch || strength.score < 2) ? 'rgba(0,0,0,0.06)' : '#1D9E75', color: (!newPw || mismatch || strength.score < 2) ? 'var(--color-text-tertiary,#b0b0b0)' : '#fff', border: 'none', borderRadius: '9px', cursor: (!newPw || mismatch || strength.score < 2) ? 'default' : 'pointer', fontSize: '13px', fontWeight: 500 }}>
                    Update password
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 2FA */}
          {activeSection === '2fa' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div style={baseCard}>
                <div style={panelHead}>
                  <div>
                    <div style={{ fontSize: '14px', fontWeight: 500 }}>Two-factor authentication</div>
                    <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>Add a second layer of verification to your account</div>
                  </div>
                  <span style={{ fontSize: '10px', fontWeight: 500, padding: '3px 10px', borderRadius: '20px', background: twoFaEnabled ? '#EAF3DE' : '#FAECE7', color: twoFaEnabled ? '#0F6E56' : '#993C1D' }}>
                    {twoFaEnabled ? 'Enabled' : 'Disabled'}
                  </span>
                </div>
                <div style={{ padding: '20px 24px' }}>

                  {twoFaStep === 'idle' && !twoFaEnabled && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                      <div style={{ display: 'flex', gap: '12px', padding: '14px', background: 'var(--color-background-secondary,#f8f7f4)', borderRadius: '10px', border: '0.5px solid rgba(0,0,0,0.06)' }}>
                        <div style={{ width: '36px', height: '36px', borderRadius: '9px', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                          <Smartphone size={17} color="#1D9E75"/>
                        </div>
                        <div>
                          <p style={{ fontSize: '13px', fontWeight: 500, margin: '0 0 3px' }}>Authenticator app</p>
                          <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: 0, lineHeight: 1.5 }}>Use Google Authenticator or Authy to scan a QR code and generate time-based OTP codes.</p>
                        </div>
                      </div>
                      <button onClick={() => setTwoFaStep('qr')}
                        style={{ padding: '10px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                        <Smartphone size={14}/> Set up 2FA
                      </button>
                    </div>
                  )}

                  {twoFaStep === 'qr' && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                      <p style={{ fontSize: '13px', fontWeight: 500, margin: 0 }}>Step 1: Scan this QR code</p>
                      <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: 0 }}>Open your authenticator app and scan the QR code below.</p>
                      {/* QR code mockup */}
                      <div style={{ display: 'flex', justifyContent: 'center' }}>
                        <div style={{ width: '160px', height: '160px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '12px', padding: '12px', background: '#fff', display: 'grid', gridTemplateColumns: 'repeat(10,1fr)', gap: '2px' }}>
                          {Array.from({length:100},(_,i) => (
                            <div key={i} style={{ aspectRatio: '1', borderRadius: '1px', background: Math.random() > 0.5 ? '#1A1A1A' : 'transparent' }} />
                          ))}
                        </div>
                      </div>
                      <div style={{ padding: '10px 14px', background: 'var(--color-background-secondary,#f8f7f4)', borderRadius: '8px', fontSize: '12px', color: 'var(--color-text-secondary)', fontFamily: 'monospace', textAlign: 'center', letterSpacing: '0.05em' }}>
                        NEXUS2FA-{user.id.toUpperCase().slice(0,12)}
                      </div>
                      <button onClick={() => setTwoFaStep('otp')}
                        style={{ padding: '10px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                        I've scanned it <ChevronRight size={14}/>
                      </button>
                    </div>
                  )}

                  {twoFaStep === 'otp' && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                      <div>
                        <p style={{ fontSize: '13px', fontWeight: 500, margin: '0 0 4px' }}>Step 2: Enter verification code</p>
                        <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: 0 }}>Enter the 6-digit code from your authenticator app. (Demo: use <strong>123456</strong>)</p>
                      </div>
                      <div style={{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
                        {otp.map((digit, i) => (
                          <input
                            key={i}
                            ref={el => { otpRefs.current[i] = el; }}
                            type="text"
                            inputMode="numeric"
                            maxLength={1}
                            value={digit}
                            onChange={e => handleOtpChange(i, e.target.value)}
                            onKeyDown={e => handleOtpKeyDown(i, e)}
                            style={{
                              width: '44px', height: '52px', textAlign: 'center', fontSize: '20px', fontWeight: 500,
                              border: `2px solid ${otpError ? '#D85A30' : otpSuccess ? '#1D9E75' : digit ? '#1D9E75' : 'rgba(0,0,0,0.15)'}`,
                              borderRadius: '10px', outline: 'none', background: otpError ? '#FAECE7' : otpSuccess ? '#EAF3DE' : 'var(--color-background-primary,#fff)',
                              color: otpError ? '#D85A30' : otpSuccess ? '#1D9E75' : 'var(--color-text-primary)',
                              transition: 'all 0.15s',
                            }}
                          />
                        ))}
                      </div>
                      {otpError && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '8px 12px', background: '#FAECE7', borderRadius: '8px', fontSize: '12px', color: '#993C1D' }}>
                          <AlertCircle size={13}/> Incorrect code. Try again. (Demo code: 123456)
                        </div>
                      )}
                      {otpSuccess && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '8px 12px', background: '#EAF3DE', borderRadius: '8px', fontSize: '12px', color: '#0F6E56' }}>
                          <CheckCircle size={13}/> Code verified! Enabling 2FA…
                        </div>
                      )}
                      <button onClick={verifyOtp} disabled={otp.join('').length < 6}
                        style={{ padding: '10px', background: otp.join('').length < 6 ? 'rgba(0,0,0,0.06)' : '#1D9E75', color: otp.join('').length < 6 ? 'var(--color-text-tertiary,#b0b0b0)' : '#fff', border: 'none', borderRadius: '9px', cursor: otp.join('').length < 6 ? 'default' : 'pointer', fontSize: '13px', fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                        <Check size={14}/> Verify & enable 2FA
                      </button>
                    </div>
                  )}

                  {twoFaStep === 'done' && twoFaEnabled && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '14px', background: '#EAF3DE', borderRadius: '10px', border: '0.5px solid #C0DD97' }}>
                        <CheckCircle size={20} color="#1D9E75" style={{ flexShrink: 0 }}/>
                        <div>
                          <p style={{ fontSize: '13px', fontWeight: 500, margin: '0 0 2px', color: '#0F6E56' }}>2FA is active</p>
                          <p style={{ fontSize: '12px', color: '#0F6E56', margin: 0, opacity: 0.8 }}>Your account is protected with two-factor authentication.</p>
                        </div>
                      </div>
                      <button onClick={() => { setTwoFaEnabled(false); setTwoFaStep('idle'); setOtp(['','','','','','']); }}
                        style={{ padding: '9px', background: '#FAECE7', color: '#993C1D', border: '0.5px solid #F5C4B3', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>
                        Disable 2FA
                      </button>
                    </div>
                  )}

                  {twoFaEnabled && twoFaStep !== 'done' && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '14px', background: '#EAF3DE', borderRadius: '10px' }}>
                      <CheckCircle size={20} color="#1D9E75"/>
                      <p style={{ fontSize: '13px', margin: 0, color: '#0F6E56', fontWeight: 500 }}>2FA is currently enabled on your account</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Multi-step login mockup */}
              <div style={baseCard}>
                <div style={{ padding: '14px 24px', borderBottom: '0.5px solid rgba(0,0,0,0.07)', fontSize: '14px', fontWeight: 500 }}>Multi-step login preview</div>
                <div style={{ padding: '20px 24px' }}>
                  <div style={{ display: 'flex', gap: '0', position: 'relative', marginBottom: '20px' }}>
                    {['Email & password','Verification code','Access granted'].map((step,i) => (
                      <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px', position: 'relative' }}>
                        <div style={{ width: '28px', height: '28px', borderRadius: '50%', background: i <= 1 ? '#1D9E75' : 'rgba(0,0,0,0.08)', color: i <= 1 ? '#fff' : 'var(--color-text-tertiary,#b0b0b0)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', fontWeight: 500, zIndex: 1 }}>
                          {i <= 1 ? <Check size={13}/> : '3'}
                        </div>
                        {i < 2 && <div style={{ position: 'absolute', top: '14px', left: '50%', width: '100%', height: '2px', background: i === 0 ? '#1D9E75' : 'rgba(0,0,0,0.08)' }}/>}
                        <span style={{ fontSize: '10px', color: i <= 1 ? '#0F6E56' : 'var(--color-text-secondary)', fontWeight: i <= 1 ? 500 : 400, textAlign: 'center', maxWidth: '80px' }}>{step}</span>
                      </div>
                    ))}
                  </div>
                  <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: 0, lineHeight: 1.6 }}>
                    When 2FA is enabled, users must complete both steps: enter their password, then verify with a time-based OTP from their authenticator app before gaining access.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* SESSIONS */}
          {activeSection === 'sessions' && (
            <div style={baseCard}>
              <div style={panelHead}>
                <div>
                  <div style={{ fontSize: '14px', fontWeight: 500 }}>Active sessions</div>
                  <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>Devices logged in to your account</div>
                </div>
                <button style={{ display: 'flex', alignItems: 'center', gap: '5px', padding: '7px 14px', background: '#FAECE7', color: '#993C1D', border: '0.5px solid #F5C4B3', borderRadius: '8px', cursor: 'pointer', fontSize: '12px', fontWeight: 500 }}>
                  <LogOut size={12}/> Sign out all
                </button>
              </div>
              <div style={{ padding: '8px 0' }}>
                {SESSIONS.map((s,i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '14px', padding: '14px 24px', borderTop: i > 0 ? '0.5px solid rgba(0,0,0,0.05)' : 'none' }}>
                    <div style={{ width: '38px', height: '38px', borderRadius: '9px', background: s.current ? '#EAF3DE' : 'var(--color-background-secondary,#f5f4f0)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <Monitor size={17} color={s.current ? '#1D9E75' : 'var(--color-text-secondary)'}/>
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <p style={{ fontSize: '13px', fontWeight: 500, margin: 0 }}>{s.device}</p>
                        {s.current && <span style={{ fontSize: '10px', fontWeight: 500, padding: '2px 7px', borderRadius: '20px', background: '#EAF3DE', color: '#0F6E56' }}>Current</span>}
                      </div>
                      <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)', margin: '2px 0 0' }}>{s.location} · {s.time}</p>
                    </div>
                    {!s.current && (
                      <button style={{ padding: '6px 12px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '7px', background: 'none', cursor: 'pointer', fontSize: '11px', color: 'var(--color-text-secondary)' }}>
                        Revoke
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ROLES */}
          {activeSection === 'roles' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div style={baseCard}>
                <div style={{ height: '2px', background: T[user.role === 'entrepreneur' ? 'emerald' : 'violet'].fill }}/>
                <div style={panelHead}>
                  <div style={{ fontSize: '14px', fontWeight: 500 }}>Your role & permissions</div>
                </div>
                <div style={{ padding: '20px 24px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '14px', padding: '16px', background: 'var(--color-background-secondary,#f8f7f4)', borderRadius: '10px', marginBottom: '20px' }}>
                    <div style={{ width: '44px', height: '44px', borderRadius: '12px', background: user.role === 'entrepreneur' ? '#EAF3DE' : '#EEEDFE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      {user.role === 'entrepreneur' ? <Zap size={20} color="#1D9E75"/> : <Activity size={20} color="#7F77DD"/>}
                    </div>
                    <div>
                      <p style={{ fontSize: '14px', fontWeight: 500, margin: '0 0 3px', textTransform: 'capitalize' }}>{user.role}</p>
                      <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: 0 }}>
                        {user.role === 'entrepreneur' ? 'Manage your startup, deals, and investor connections' : 'Discover startups, manage portfolio, and track investments'}
                      </p>
                    </div>
                  </div>

                  {/* Role comparison */}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                    {[
                      { role: 'entrepreneur', color: 'emerald' as const, perms: ['Create startup profile','Receive collaboration requests','Share deal documents','Upload pitch deck','Schedule investor meetings','Access document chamber'] },
                      { role: 'investor',     color: 'violet' as const,  perms: ['Browse startup directory','Send collaboration requests','View pitch decks','Manage deal pipeline','Track portfolio companies','Access payment flows'] },
                    ].map(r => {
                      const c = T[r.color];
                      const isCurrent = user.role === r.role;
                      return (
                        <div key={r.role} style={{ border: `${isCurrent ? '2px' : '0.5px'} solid ${isCurrent ? c.fill : 'rgba(0,0,0,0.08)'}`, borderRadius: '12px', overflow: 'hidden' }}>
                          <div style={{ padding: '12px 16px', background: isCurrent ? c.bg : 'var(--color-background-secondary,#f8f7f4)', borderBottom: '0.5px solid rgba(0,0,0,0.07)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <span style={{ fontSize: '13px', fontWeight: 500, color: isCurrent ? c.text : 'var(--color-text-secondary)', textTransform: 'capitalize' }}>{r.role}</span>
                            {isCurrent && <span style={{ fontSize: '10px', fontWeight: 500, padding: '2px 8px', borderRadius: '20px', background: c.fill, color: '#fff' }}>Your role</span>}
                          </div>
                          <div style={{ padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                            {r.perms.map((p,i) => (
                              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
                                <Check size={12} color={isCurrent ? c.fill : 'rgba(0,0,0,0.20)'}/>
                                <span style={{ fontSize: '12px', color: isCurrent ? 'var(--color-text-primary)' : 'var(--color-text-secondary)' }}>{p}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};