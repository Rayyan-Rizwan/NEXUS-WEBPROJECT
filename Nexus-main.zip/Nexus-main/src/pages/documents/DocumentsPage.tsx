import React, { useState } from 'react';
import { FileText, Upload, Download, Trash2, Share2, Search, Grid, List, X } from 'lucide-react';

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD' },
  amber:   { bg: '#FAEEDA', text: '#854F0B', fill: '#BA7517' },
  coral:   { bg: '#FAECE7', text: '#993C1D', fill: '#D85A30' },
};

const fileTypeConf: Record<string, { color: keyof typeof T; ext: string }> = {
  PDF:        { color: 'coral', ext: 'PDF' },
  Spreadsheet:{ color: 'emerald', ext: 'XLS' },
  Document:   { color: 'violet', ext: 'DOC' },
};

const docs = [
  { id: 1, name: 'Pitch Deck 2024', type: 'PDF', size: '2.4 MB', lastModified: '2024-02-15', shared: true },
  { id: 2, name: 'Financial Projections', type: 'Spreadsheet', size: '1.8 MB', lastModified: '2024-02-10', shared: false },
  { id: 3, name: 'Business Plan', type: 'Document', size: '3.2 MB', lastModified: '2024-02-05', shared: true },
  { id: 4, name: 'Market Research', type: 'PDF', size: '5.1 MB', lastModified: '2024-01-28', shared: false },
  { id: 5, name: 'Cap Table', type: 'Spreadsheet', size: '0.9 MB', lastModified: '2024-01-20', shared: true },
  { id: 6, name: 'Team Bios', type: 'Document', size: '1.2 MB', lastModified: '2024-01-15', shared: false },
];

const baseCard: React.CSSProperties = { background: 'var(--color-background-primary,#fff)', border: '0.5px solid rgba(0,0,0,0.08)', borderRadius: '14px', overflow: 'hidden' };

export const DocumentsPage: React.FC = () => {
  const [search, setSearch] = useState('');
  const [viewMode, setViewMode] = useState<'list'|'grid'>('list');
  const [activeFilter, setActiveFilter] = useState('all');

  const filters = [
    { key: 'all', label: 'All' },
    { key: 'PDF', label: 'PDFs' },
    { key: 'Spreadsheet', label: 'Spreadsheets' },
    { key: 'Document', label: 'Documents' },
    { key: 'shared', label: 'Shared' },
  ];

  const filtered = docs.filter(d => {
    const matchSearch = !search || d.name.toLowerCase().includes(search.toLowerCase());
    const matchFilter = activeFilter === 'all' || (activeFilter === 'shared' ? d.shared : d.type === activeFilter);
    return matchSearch && matchFilter;
  });

  const usedGb = 12.5;
  const totalGb = 20;
  const pct = Math.round((usedGb / totalGb) * 100);

  const quickLinks = ['Recent files', 'Shared with me', 'Starred', 'Trash'];

  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '32px' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '28px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <h1 style={{ fontSize: '20px', fontWeight: 500, margin: '0 0 4px', letterSpacing: '-0.01em' }}>Documents</h1>
          <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>Manage your startup's important files</p>
        </div>
        <button style={{ display: 'flex', alignItems: 'center', gap: '7px', padding: '9px 18px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '10px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>
          <Upload size={14} /> Upload document
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', gap: '16px', alignItems: 'start' }}>

        {/* Sidebar */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>

          {/* Storage */}
          <div style={baseCard}>
            <div style={{ padding: '16px 20px', borderBottom: '0.5px solid rgba(0,0,0,0.07)' }}>
              <div style={{ fontSize: '13px', fontWeight: 500 }}>Storage</div>
            </div>
            <div style={{ padding: '16px 20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>Used</span>
                <span style={{ fontSize: '11px', fontWeight: 500 }}>{usedGb} GB</span>
              </div>
              <div style={{ height: '5px', background: 'var(--color-background-secondary,#f0efec)', borderRadius: '3px', overflow: 'hidden', marginBottom: '8px' }}>
                <div style={{ height: '100%', width: `${pct}%`, background: pct > 80 ? '#D85A30' : '#1D9E75', borderRadius: '3px' }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: '11px', color: '#1D9E75', fontWeight: 500 }}>{pct}% used</span>
                <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>{totalGb} GB total</span>
              </div>
              <div style={{ marginTop: '12px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                {[
                  { label: 'PDFs', pct: 40, color: '#D85A30', gb: '5.0 GB' },
                  { label: 'Spreadsheets', pct: 20, color: '#1D9E75', gb: '2.5 GB' },
                  { label: 'Documents', pct: 15, color: '#7F77DD', gb: '1.9 GB' },
                ].map(t => (
                  <div key={t.label} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: t.color, flexShrink: 0 }} />
                    <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)', flex: 1 }}>{t.label}</span>
                    <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>{t.gb}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Quick access */}
          <div style={baseCard}>
            <div style={{ padding: '14px 20px', borderBottom: '0.5px solid rgba(0,0,0,0.07)', fontSize: '13px', fontWeight: 500 }}>Quick access</div>
            <div style={{ padding: '6px 0' }}>
              {quickLinks.map(l => (
                <button key={l} style={{ display: 'block', width: '100%', textAlign: 'left', padding: '9px 20px', background: 'none', border: 'none', cursor: 'pointer', fontSize: '13px', color: 'var(--color-text-secondary)' }}
                  onMouseEnter={e => { e.currentTarget.style.background = 'var(--color-background-secondary,#f8f7f4)'; e.currentTarget.style.color = 'var(--color-text-primary)'; }}
                  onMouseLeave={e => { e.currentTarget.style.background = 'none'; e.currentTarget.style.color = 'var(--color-text-secondary)'; }}>
                  {l}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Main */}
        <div style={baseCard}>
          {/* Toolbar */}
          <div style={{ padding: '14px 20px', borderBottom: '0.5px solid rgba(0,0,0,0.07)', display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
            <div style={{ position: 'relative', flex: 1, minWidth: '180px' }}>
              <Search size={14} style={{ position: 'absolute', left: '11px', top: '50%', transform: 'translateY(-50%)', color: 'var(--color-text-tertiary,#b0b0b0)' }} />
              <input placeholder="Search documents…" value={search} onChange={e => setSearch(e.target.value)}
                style={{ width: '100%', padding: '8px 12px 8px 32px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '9px', fontSize: '13px', outline: 'none', background: 'var(--color-background-secondary,#f8f7f4)', color: 'var(--color-text-primary)', boxSizing: 'border-box' as const }} />
            </div>
            <div style={{ display: 'flex', gap: '5px', flexWrap: 'wrap' }}>
              {filters.map(f => {
                const active = activeFilter === f.key;
                return (
                  <button key={f.key} onClick={() => setActiveFilter(f.key)}
                    style={{ padding: '5px 12px', borderRadius: '20px', border: '0.5px solid', cursor: 'pointer', fontSize: '12px', fontWeight: active ? 500 : 400, background: active ? '#EAF3DE' : 'var(--color-background-primary,#fff)', color: active ? '#0F6E56' : 'var(--color-text-secondary)', borderColor: active ? '#1D9E75' : 'rgba(0,0,0,0.10)', transition: 'all 0.15s' }}>
                    {f.label}
                  </button>
                );
              })}
            </div>
            <div style={{ display: 'flex', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '8px', overflow: 'hidden', flexShrink: 0 }}>
              {(['list','grid'] as const).map((m, i) => (
                <button key={m} onClick={() => setViewMode(m)}
                  style={{ padding: '7px 10px', border: 'none', cursor: 'pointer', background: viewMode === m ? '#EAF3DE' : 'var(--color-background-primary,#fff)', color: viewMode === m ? '#0F6E56' : 'var(--color-text-secondary)', borderRight: i === 0 ? '0.5px solid rgba(0,0,0,0.10)' : 'none' }}>
                  {m === 'list' ? <List size={14} /> : <Grid size={14} />}
                </button>
              ))}
            </div>
            <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)', flexShrink: 0 }}>{filtered.length} files</span>
          </div>

          {/* Content */}
          <div style={{ padding: viewMode === 'grid' ? '20px' : '0' }}>
            {viewMode === 'list' ? (
              filtered.map((doc, idx) => {
                const fc = fileTypeConf[doc.type] || fileTypeConf.Document;
                const c = T[fc.color];
                return (
                  <div key={doc.id}
                    style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '13px 24px', borderTop: idx > 0 ? '0.5px solid rgba(0,0,0,0.05)' : 'none', cursor: 'pointer', transition: 'background 0.1s' }}
                    onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-background-secondary,#f8f7f4)')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                    <div style={{ width: '38px', height: '38px', borderRadius: '9px', background: c.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <span style={{ fontSize: '10px', fontWeight: 500, color: c.text }}>{fc.ext}</span>
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span style={{ fontSize: '13px', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{doc.name}</span>
                        {doc.shared && <span style={{ fontSize: '10px', fontWeight: 500, padding: '2px 7px', borderRadius: '20px', background: '#EEEDFE', color: '#534AB7', flexShrink: 0 }}>Shared</span>}
                      </div>
                      <div style={{ display: 'flex', gap: '12px', marginTop: '3px' }}>
                        <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>{doc.type}</span>
                        <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>{doc.size}</span>
                        <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>
                          {new Date(doc.lastModified).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                        </span>
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: '2px', flexShrink: 0 }}>
                      {[<Download size={14} />, <Share2 size={14} />, <Trash2 size={14} />].map((icon, i) => (
                        <button key={i} style={{ width: '30px', height: '30px', borderRadius: '7px', border: 'none', background: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'var(--color-text-tertiary,#b0b0b0)' }}
                          onMouseEnter={e => { e.currentTarget.style.background = 'var(--color-background-secondary,#f0efec)'; e.currentTarget.style.color = i === 2 ? '#D85A30' : '#1D9E75'; }}
                          onMouseLeave={e => { e.currentTarget.style.background = 'none'; e.currentTarget.style.color = 'var(--color-text-tertiary,#b0b0b0)'; }}>
                          {icon}
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(150px,1fr))', gap: '12px' }}>
                {filtered.map(doc => {
                  const fc = fileTypeConf[doc.type] || fileTypeConf.Document;
                  const c = T[fc.color];
                  return (
                    <div key={doc.id}
                      style={{ border: '0.5px solid rgba(0,0,0,0.08)', borderRadius: '12px', padding: '16px', cursor: 'pointer', transition: 'all 0.15s', background: 'var(--color-background-primary,#fff)' }}
                      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = c.fill; }}
                      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = 'rgba(0,0,0,0.08)'; }}>
                      <div style={{ width: '40px', height: '40px', borderRadius: '9px', background: c.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '10px' }}>
                        <span style={{ fontSize: '10px', fontWeight: 500, color: c.text }}>{fc.ext}</span>
                      </div>
                      <p style={{ fontSize: '12px', fontWeight: 500, margin: '0 0 4px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{doc.name}</p>
                      <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)', margin: 0 }}>{doc.size}</p>
                      {doc.shared && <span style={{ fontSize: '10px', fontWeight: 500, padding: '2px 6px', borderRadius: '8px', background: '#EEEDFE', color: '#534AB7', marginTop: '6px', display: 'inline-block' }}>Shared</span>}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};