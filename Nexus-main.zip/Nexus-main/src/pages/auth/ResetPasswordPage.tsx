import React, { useState } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { Lock, Eye, EyeOff, AlertCircle, ArrowLeft } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75', mid: '#C0DD97' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD', mid: '#AFA9EC' },
};

const pageWrapper: React.CSSProperties = {
  minHeight: '100vh',
  background: 'var(--color-background-tertiary,#F5F4F0)',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  padding: '40px 16px',
  fontFamily: 'var(--font-sans,system-ui,sans-serif)',
};

const formCard: React.CSSProperties = {
  width: '100%',
  maxWidth: '400px',
  background: 'var(--color-background-primary,#fff)',
  border: '0.5px solid rgba(0,0,0,0.08)',
  borderRadius: '16px',
  overflow: 'hidden',
};

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '9px 12px',
  border: '0.5px solid rgba(0,0,0,0.12)',
  borderRadius: '9px',
  fontSize: '13px',
  outline: 'none',
  background: 'var(--color-background-primary,#fff)',
  color: 'var(--color-text-primary)',
  boxSizing: 'border-box',
};

const labelStyle: React.CSSProperties = {
  display: 'block',
  fontSize: '11px',
  fontWeight: 500,
  color: 'var(--color-text-secondary)',
  marginBottom: '5px',
  textTransform: 'uppercase' as const,
  letterSpacing: '0.05em',
};

const Logo: React.FC = () => (
  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px', marginBottom: '24px' }}>
    <div style={{ width: '44px', height: '44px', borderRadius: '12px', background: T.emerald.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `0.5px solid ${T.emerald.mid}` }}>
      <svg width="20" height="20" viewBox="0 0 16 16" fill={T.emerald.fill}><polygon points="8,1 14,4.5 14,11.5 8,15 2,11.5 2,4.5"/></svg>
    </div>
    <div style={{ textAlign: 'center' }}>
      <div style={{ fontSize: '18px', fontWeight: 500, letterSpacing: '-0.01em', color: 'var(--color-text-primary)' }}>Nexus</div>
      <div style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginTop: '1px' }}>Venture Platform</div>
    </div>
  </div>
);

const PasswordField: React.FC<{
  label: string;
  value: string;
  onChange: (v: string) => void;
  error?: string;
}> = ({ label, value, onChange, error }) => {
  const [show, setShow] = useState(false);
  return (
    <div>
      <label style={labelStyle}>{label}</label>
      <div style={{ position: 'relative' }}>
        <input
          type={show ? 'text' : 'password'}
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder="••••••••"
          required
          onFocus={e => (e.currentTarget.style.borderColor = error ? '#D85A30' : '#1D9E75')}
          onBlur={e => (e.currentTarget.style.borderColor = error ? '#D85A30' : 'rgba(0,0,0,0.12)')}
          style={{ ...inputStyle, paddingRight: '38px', borderColor: error ? '#D85A30' : 'rgba(0,0,0,0.12)' }}
        />
        <button
          type="button"
          onClick={() => setShow(p => !p)}
          style={{ position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--color-text-tertiary,#b0b0b0)', display: 'flex', alignItems: 'center' }}
        >
          {show ? <EyeOff size={14} /> : <Eye size={14} />}
        </button>
      </div>
      {error && <p style={{ fontSize: '11px', color: '#D85A30', margin: '4px 0 0' }}>{error}</p>}
    </div>
  );
};

export const ResetPasswordPage: React.FC = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { resetPassword } = useAuth();
  const token = searchParams.get('token');

  const passwordMismatch = confirmPassword.length > 0 && password !== confirmPassword;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || password !== confirmPassword) return;
    setIsLoading(true);
    try {
      await resetPassword(token, password);
      navigate('/login');
    } catch {}
    finally { setIsLoading(false); }
  };

  if (!token) {
    return (
      <div style={pageWrapper}>
        <Logo />
        <div style={formCard}>
          <div style={{ height: '2px', background: '#D85A30' }} />
          <div style={{ padding: '32px 28px', display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', gap: '16px' }}>
            <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: '#FAECE7', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <AlertCircle size={22} color="#D85A30" />
            </div>
            <div>
              <h2 style={{ fontSize: '18px', fontWeight: 500, margin: '0 0 4px', letterSpacing: '-0.01em' }}>Invalid reset link</h2>
              <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0, lineHeight: 1.5 }}>
                This password reset link is invalid or has expired.
              </p>
            </div>
            <button
              onClick={() => navigate('/forgot-password')}
              style={{ width: '100%', padding: '10px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}
            >
              Request a new reset link
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={pageWrapper}>
      <Logo />
      <div style={formCard}>
        <div style={{ height: '2px', background: `linear-gradient(90deg, ${T.emerald.fill}, ${T.violet.fill})` }} />
        <div style={{ padding: '28px 28px 24px' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px', marginBottom: '20px' }}>
            <div style={{ width: '42px', height: '42px', borderRadius: '11px', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Lock size={19} color="#1D9E75" />
            </div>
            <div>
              <h2 style={{ fontSize: '18px', fontWeight: 500, margin: '0 0 4px', letterSpacing: '-0.01em' }}>Reset your password</h2>
              <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0, lineHeight: 1.5 }}>
                Enter your new password below. Make it strong!
              </p>
            </div>
          </div>

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            <PasswordField label="New password" value={password} onChange={setPassword} />
            <PasswordField
              label="Confirm new password"
              value={confirmPassword}
              onChange={setConfirmPassword}
              error={passwordMismatch ? 'Passwords do not match' : undefined}
            />

            {/* Password strength hint */}
            {password.length > 0 && (
              <div>
                <div style={{ display: 'flex', gap: '4px', marginBottom: '4px' }}>
                  {[1,2,3,4].map(i => {
                    const strength = password.length >= 12 ? 4 : password.length >= 8 ? 3 : password.length >= 6 ? 2 : 1;
                    const colors = ['#D85A30','#BA7517','#BA7517','#1D9E75'];
                    return (
                      <div key={i} style={{ flex: 1, height: '4px', borderRadius: '2px', background: i <= strength ? colors[strength-1] : 'rgba(0,0,0,0.08)', transition: 'all 0.2s' }} />
                    );
                  })}
                </div>
                <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)', margin: 0 }}>
                  {password.length < 6 ? 'Too short' : password.length < 8 ? 'Weak' : password.length < 12 ? 'Good' : 'Strong'}
                </p>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading || passwordMismatch || password.length < 6}
              style={{ width: '100%', padding: '10px', background: (isLoading || passwordMismatch || password.length < 6) ? '#C0DD97' : '#1D9E75', color: '#fff', border: 'none', borderRadius: '9px', cursor: (isLoading || passwordMismatch || password.length < 6) ? 'default' : 'pointer', fontSize: '13px', fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}
            >
              <Lock size={13} /> {isLoading ? 'Resetting…' : 'Reset password'}
            </button>

            <Link to="/login" style={{ textDecoration: 'none' }}>
              <button type="button" style={{ width: '100%', padding: '9px', background: 'none', color: 'var(--color-text-secondary)', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                <ArrowLeft size={13} /> Back to login
              </button>
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
};