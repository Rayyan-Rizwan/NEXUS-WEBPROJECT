import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, CircleDollarSign, Building2, LogIn, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types';

// ── Shared design tokens ──────────────────────────────────────────────────────

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75', mid: '#C0DD97' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD', mid: '#AFA9EC' },
};

const pageWrapper: React.CSSProperties = {
  minHeight: '100vh',
  background: 'var(--color-background-tertiary,#F5F4F0)',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  padding: '40px 16px',
  fontFamily: 'var(--font-sans,system-ui,sans-serif)',
};

const formCard: React.CSSProperties = {
  width: '100%',
  maxWidth: '420px',
  background: 'var(--color-background-primary,#fff)',
  border: '0.5px solid rgba(0,0,0,0.08)',
  borderRadius: '16px',
  overflow: 'hidden',
};

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '9px 12px',
  border: '0.5px solid rgba(0,0,0,0.12)',
  borderRadius: '9px',
  fontSize: '13px',
  outline: 'none',
  background: 'var(--color-background-primary,#fff)',
  color: 'var(--color-text-primary)',
  boxSizing: 'border-box',
};

const labelStyle: React.CSSProperties = {
  display: 'block',
  fontSize: '11px',
  fontWeight: 500,
  color: 'var(--color-text-secondary)',
  marginBottom: '5px',
  textTransform: 'uppercase' as const,
  letterSpacing: '0.05em',
};

const Logo: React.FC = () => (
  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px', marginBottom: '28px' }}>
    <div style={{ width: '44px', height: '44px', borderRadius: '12px', background: T.emerald.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `0.5px solid ${T.emerald.mid}` }}>
      <svg width="20" height="20" viewBox="0 0 16 16" fill={T.emerald.fill}>
        <polygon points="8,1 14,4.5 14,11.5 8,15 2,11.5 2,4.5" />
      </svg>
    </div>
    <div style={{ textAlign: 'center' }}>
      <div style={{ fontSize: '18px', fontWeight: 500, letterSpacing: '-0.01em', color: 'var(--color-text-primary)' }}>Nexus</div>
      <div style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>Venture Platform</div>
    </div>
  </div>
);

const ErrorBanner: React.FC<{ message: string }> = ({ message }) => (
  <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', padding: '10px 14px', background: '#FAECE7', border: '0.5px solid #F5C4B3', borderRadius: '10px', marginBottom: '16px' }}>
    <AlertCircle size={15} color="#D85A30" style={{ flexShrink: 0, marginTop: '1px' }} />
    <span style={{ fontSize: '13px', color: '#993C1D' }}>{message}</span>
  </div>
);

const Divider: React.FC<{ label: string }> = ({ label }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: '12px', margin: '20px 0' }}>
    <div style={{ flex: 1, height: '0.5px', background: 'rgba(0,0,0,0.08)' }} />
    <span style={{ fontSize: '12px', color: 'var(--color-text-secondary)' }}>{label}</span>
    <div style={{ flex: 1, height: '0.5px', background: 'rgba(0,0,0,0.08)' }} />
  </div>
);

const PasswordInput: React.FC<{ label: string; value: string; onChange: (v: string) => void; placeholder?: string }> = ({ label, value, onChange, placeholder }) => {
  const [show, setShow] = useState(false);
  return (
    <div>
      <label style={labelStyle}>{label}</label>
      <div style={{ position: 'relative' }}>
        <input
          type={show ? 'text' : 'password'}
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder || '••••••••'}
          required
          onFocus={e => (e.currentTarget.style.borderColor = '#1D9E75')}
          onBlur={e => (e.currentTarget.style.borderColor = 'rgba(0,0,0,0.12)')}
          style={{ ...inputStyle, paddingRight: '38px' }}
        />
        <button type="button" onClick={() => setShow(p => !p)} style={{ position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--color-text-tertiary,#b0b0b0)', display: 'flex', alignItems: 'center' }}>
          {show ? <EyeOff size={14} /> : <Eye size={14} />}
        </button>
      </div>
    </div>
  );
};

// ── LOGIN PAGE ────────────────────────────────────────────────────────────────

export const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('entrepreneur');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);
    try {
      await login(email, password, role);
      navigate(role === 'entrepreneur' ? '/dashboard/entrepreneur' : '/dashboard/investor');
    } catch (err) {
      setError((err as Error).message);
      setIsLoading(false);
    }
  };

  const fillDemo = (r: UserRole) => {
    if (r === 'entrepreneur') { setEmail('sarah@techwave.io'); setPassword('password123'); }
    else { setEmail('michael@vcinnovate.com'); setPassword('password123'); }
    setRole(r);
  };

  const roleBtn = (r: UserRole, label: string, icon: React.ReactNode) => {
    const active = role === r;
    const c = active ? T.emerald : { bg: 'var(--color-background-primary,#fff)', text: 'var(--color-text-secondary)', mid: 'rgba(0,0,0,0.12)' };
    return (
      <button type="button" onClick={() => setRole(r)} style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '7px', padding: '10px', border: `0.5px solid ${c.mid}`, borderRadius: '9px', background: c.bg, color: c.text, cursor: 'pointer', fontSize: '13px', fontWeight: active ? 500 : 400, transition: 'all 0.15s' }}>
        {icon} {label}
      </button>
    );
  };

  return (
    <div style={pageWrapper}>
      <Logo />
      <div style={formCard}>
        <div style={{ height: '2px', background: `linear-gradient(90deg, ${T.emerald.fill}, ${T.violet.fill})` }} />
        <div style={{ padding: '28px 28px 24px' }}>
          <h2 style={{ fontSize: '18px', fontWeight: 500, margin: '0 0 4px', letterSpacing: '-0.01em' }}>Sign in to your account</h2>
          <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: '0 0 20px' }}>Welcome back — connect with investors and entrepreneurs</p>

          {error && <ErrorBanner message={error} />}

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {/* Role toggle */}
            <div>
              <label style={labelStyle}>I am a</label>
              <div style={{ display: 'flex', gap: '8px' }}>
                {roleBtn('entrepreneur', 'Entrepreneur', <Building2 size={14} />)}
                {roleBtn('investor', 'Investor', <CircleDollarSign size={14} />)}
              </div>
            </div>

            <div>
              <label style={labelStyle}>Email address</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@company.com" required onFocus={e => (e.currentTarget.style.borderColor = '#1D9E75')} onBlur={e => (e.currentTarget.style.borderColor = 'rgba(0,0,0,0.12)')} style={inputStyle} />
            </div>

            <PasswordInput label="Password" value={password} onChange={setPassword} />

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '12px', color: 'var(--color-text-secondary)' }}>
                <input type="checkbox" style={{ width: '14px', height: '14px', cursor: 'pointer', accentColor: '#1D9E75' }} /> Remember me
              </label>
              <Link to="/forgot-password" style={{ fontSize: '12px', color: '#1D9E75', fontWeight: 500, textDecoration: 'none' }}>Forgot password?</Link>
            </div>

            <button type="submit" disabled={isLoading} style={{ width: '100%', padding: '10px', background: isLoading ? '#C0DD97' : '#1D9E75', color: '#fff', border: 'none', borderRadius: '9px', cursor: isLoading ? 'default' : 'pointer', fontSize: '13px', fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '7px' }}>
              <LogIn size={14} /> {isLoading ? 'Signing in…' : 'Sign in'}
            </button>
          </form>

          <Divider label="Demo accounts" />
          <div style={{ display: 'flex', gap: '8px' }}>
            {(['entrepreneur', 'investor'] as const).map(r => (
              <button key={r} onClick={() => fillDemo(r)} style={{ flex: 1, padding: '8px', background: 'var(--color-background-secondary,#f8f7f4)', color: 'var(--color-text-secondary)', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '8px', cursor: 'pointer', fontSize: '11px', fontWeight: 500, textTransform: 'capitalize' }}>
                {r}
              </button>
            ))}
          </div>

          <Divider label="Or" />
          <p style={{ textAlign: 'center', fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>
            Don't have an account?{' '}
            <Link to="/register" style={{ color: '#1D9E75', fontWeight: 500, textDecoration: 'none' }}>Sign up</Link>
          </p>
        </div>
      </div>
    </div>
  );
};