import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, ArrowLeft, CheckCircle, AlertCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75', mid: '#C0DD97' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD', mid: '#AFA9EC' },
};

const pageWrapper: React.CSSProperties = {
  minHeight: '100vh',
  background: 'var(--color-background-tertiary,#F5F4F0)',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  padding: '40px 16px',
  fontFamily: 'var(--font-sans,system-ui,sans-serif)',
};

const formCard: React.CSSProperties = {
  width: '100%',
  maxWidth: '400px',
  background: 'var(--color-background-primary,#fff)',
  border: '0.5px solid rgba(0,0,0,0.08)',
  borderRadius: '16px',
  overflow: 'hidden',
};

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '9px 12px',
  border: '0.5px solid rgba(0,0,0,0.12)',
  borderRadius: '9px',
  fontSize: '13px',
  outline: 'none',
  background: 'var(--color-background-primary,#fff)',
  color: 'var(--color-text-primary)',
  boxSizing: 'border-box',
};

const labelStyle: React.CSSProperties = {
  display: 'block',
  fontSize: '11px',
  fontWeight: 500,
  color: 'var(--color-text-secondary)',
  marginBottom: '5px',
  textTransform: 'uppercase' as const,
  letterSpacing: '0.05em',
};

const Logo: React.FC = () => (
  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px', marginBottom: '24px' }}>
    <div style={{ width: '44px', height: '44px', borderRadius: '12px', background: T.emerald.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `0.5px solid ${T.emerald.mid}` }}>
      <svg width="20" height="20" viewBox="0 0 16 16" fill={T.emerald.fill}><polygon points="8,1 14,4.5 14,11.5 8,15 2,11.5 2,4.5"/></svg>
    </div>
    <div style={{ textAlign: 'center' }}>
      <div style={{ fontSize: '18px', fontWeight: 500, letterSpacing: '-0.01em', color: 'var(--color-text-primary)' }}>Nexus</div>
      <div style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginTop: '1px' }}>Venture Platform</div>
    </div>
  </div>
);

export const ForgotPasswordPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { forgotPassword } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await forgotPassword(email);
      setIsSubmitted(true);
    } catch {}
    finally { setIsLoading(false); }
  };

  if (isSubmitted) {
    return (
      <div style={pageWrapper}>
        <Logo />
        <div style={formCard}>
          <div style={{ height: '2px', background: T.emerald.fill }} />
          <div style={{ padding: '32px 28px 28px', display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', gap: '16px' }}>
            <div style={{ width: '52px', height: '52px', borderRadius: '14px', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <CheckCircle size={24} color="#1D9E75" />
            </div>
            <div>
              <h2 style={{ fontSize: '18px', fontWeight: 500, margin: '0 0 4px', letterSpacing: '-0.01em' }}>Check your email</h2>
              <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0, lineHeight: 1.6 }}>
                We've sent password reset instructions to <strong style={{ color: 'var(--color-text-primary)', fontWeight: 500 }}>{email}</strong>
              </p>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', width: '100%', marginTop: '4px' }}>
              <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: 0 }}>Didn't receive the email? Check your spam folder or try again.</p>
              <button
                onClick={() => setIsSubmitted(false)}
                style={{ width: '100%', padding: '9px', background: '#EAF3DE', color: '#0F6E56', border: '0.5px solid #C0DD97', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}
              >
                Try again
              </button>
              <Link to="/login" style={{ textDecoration: 'none' }}>
                <button style={{ width: '100%', padding: '9px', background: 'none', color: 'var(--color-text-secondary)', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                  <ArrowLeft size={13} /> Back to login
                </button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={pageWrapper}>
      <Logo />
      <div style={formCard}>
        <div style={{ height: '2px', background: T.emerald.fill }} />
        <div style={{ padding: '28px 28px 24px' }}>
          <div style={{ display: 'flex', flex: 'column', alignItems: 'flex-start', gap: '12px', marginBottom: '20px' }}>
            <div style={{ width: '42px', height: '42px', borderRadius: '11px', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Mail size={19} color="#1D9E75" />
            </div>
            <div>
              <h2 style={{ fontSize: '18px', fontWeight: 500, margin: '0 0 4px', letterSpacing: '-0.01em' }}>Forgot your password?</h2>
              <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0, lineHeight: 1.5 }}>
                Enter your email and we'll send you instructions to reset it.
              </p>
            </div>
          </div>

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            <div>
              <label style={labelStyle}>Email address</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@company.com"
                required
                onFocus={e => (e.currentTarget.style.borderColor = '#1D9E75')}
                onBlur={e => (e.currentTarget.style.borderColor = 'rgba(0,0,0,0.12)')}
                style={inputStyle}
              />
            </div>
            <button type="submit" disabled={isLoading} style={{ width: '100%', padding: '10px', background: isLoading ? '#C0DD97' : '#1D9E75', color: '#fff', border: 'none', borderRadius: '9px', cursor: isLoading ? 'default' : 'pointer', fontSize: '13px', fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
              <Mail size={13} /> {isLoading ? 'Sending…' : 'Send reset instructions'}
            </button>
            <Link to="/login" style={{ textDecoration: 'none' }}>
              <button type="button" style={{ width: '100%', padding: '9px', background: 'none', color: 'var(--color-text-secondary)', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                <ArrowLeft size={13} /> Back to login
              </button>
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
};