import React, { useState, useRef } from 'react';
import {
  Upload, FileText, Eye, PenTool, CheckCircle, Clock, Edit3,
  Download, Trash2, X, Check, RotateCcw, ZoomIn, ZoomOut,
  Shield, AlertCircle, ChevronRight, Plus, FilePlus
} from 'lucide-react';

type DocStatus = 'draft' | 'in-review' | 'signed';

interface Document {
  id: string;
  name: string;
  type: string;
  size: string;
  status: DocStatus;
  uploadedAt: string;
  parties: string[];
  pages: number;
}

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75', mid: '#C0DD97' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD', mid: '#AFA9EC' },
  amber:   { bg: '#FAEEDA', text: '#854F0B', fill: '#BA7517', mid: '#FAC775' },
  coral:   { bg: '#FAECE7', text: '#993C1D', fill: '#D85A30', mid: '#F5C4B3' },
};

const statusConf: Record<DocStatus, { label: string; color: keyof typeof T; icon: React.ReactNode }> = {
  draft:     { label: 'Draft',     color: 'amber',   icon: <Edit3 size={11} /> },
  'in-review': { label: 'In Review', color: 'violet',  icon: <Clock size={11} /> },
  signed:    { label: 'Signed',    color: 'emerald', icon: <CheckCircle size={11} /> },
};

const INITIAL_DOCS: Document[] = [
  { id: '1', name: 'Series A Term Sheet.pdf',       type: 'PDF', size: '2.4 MB', status: 'signed',     uploadedAt: '2026-03-01', parties: ['Alex Kim', 'Sarah Chen'],    pages: 12 },
  { id: '2', name: 'Investment Agreement v2.pdf',   type: 'PDF', size: '3.8 MB', status: 'in-review',  uploadedAt: '2026-03-05', parties: ['Alex Kim', 'Michael Torres'], pages: 24 },
  { id: '3', name: 'NDA - TechWave AI.pdf',         type: 'PDF', size: '1.1 MB', status: 'draft',      uploadedAt: '2026-03-10', parties: ['Alex Kim'],                  pages: 6  },
  { id: '4', name: 'Shareholder Agreement.pdf',     type: 'PDF', size: '5.2 MB', status: 'in-review',  uploadedAt: '2026-03-12', parties: ['Alex Kim', 'Priya Nair'],    pages: 31 },
  { id: '5', name: 'Due Diligence Checklist.docx',  type: 'DOC', size: '0.8 MB', status: 'draft',      uploadedAt: '2026-03-14', parties: ['Alex Kim'],                  pages: 8  },
];

const baseCard: React.CSSProperties = {
  background: 'var(--color-background-primary,#fff)',
  border: '0.5px solid rgba(0,0,0,0.08)',
  borderRadius: '14px',
  overflow: 'hidden',
};

const panelHead: React.CSSProperties = {
  padding: '14px 20px',
  borderBottom: '0.5px solid rgba(0,0,0,0.07)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
};

export const DocumentChamberPage: React.FC = () => {
  const [docs, setDocs] = useState<Document[]>(INITIAL_DOCS);
  const [selectedDoc, setSelectedDoc] = useState<Document | null>(null);
  const [activeTab, setActiveTab] = useState<'chamber' | 'signature'>('chamber');
  const [filterStatus, setFilterStatus] = useState<DocStatus | 'all'>('all');
  const [isDragging, setIsDragging] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [signatureMode, setSignatureMode] = useState(false);
  const [isSigning, setIsSigning] = useState(false);
  const [signatureDone, setSignatureDone] = useState(false);
  const [zoom, setZoom] = useState(100);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isDrawing = useRef(false);
  const lastPos = useRef<{x:number;y:number}|null>(null);

  const filtered = filterStatus === 'all' ? docs : docs.filter(d => d.status === filterStatus);

  const updateStatus = (id: string, status: DocStatus) => {
    setDocs(p => p.map(d => d.id === id ? { ...d, status } : d));
    if (selectedDoc?.id === id) setSelectedDoc(p => p ? { ...p, status } : null);
  };

  const deleteDoc = (id: string) => {
    setDocs(p => p.filter(d => d.id !== id));
    if (selectedDoc?.id === id) setSelectedDoc(null);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files);
    files.forEach(f => {
      const newDoc: Document = {
        id: Date.now().toString() + Math.random(),
        name: f.name,
        type: f.name.split('.').pop()?.toUpperCase() || 'FILE',
        size: `${(f.size / (1024 * 1024)).toFixed(1)} MB`,
        status: 'draft',
        uploadedAt: new Date().toISOString().split('T')[0],
        parties: ['Alex Kim'],
        pages: Math.floor(Math.random() * 20) + 1,
      };
      setDocs(p => [...p, newDoc]);
    });
    setShowUploadModal(false);
  };

  // Signature pad
  const startDraw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    isDrawing.current = true;
    const rect = canvasRef.current!.getBoundingClientRect();
    lastPos.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };
  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing.current || !canvasRef.current || !lastPos.current) return;
    const ctx = canvasRef.current.getContext('2d')!;
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    ctx.beginPath();
    ctx.moveTo(lastPos.current.x, lastPos.current.y);
    ctx.lineTo(x, y);
    ctx.strokeStyle = '#1D9E75';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.stroke();
    lastPos.current = { x, y };
    setIsSigning(true);
  };
  const endDraw = () => { isDrawing.current = false; lastPos.current = null; };
  const clearCanvas = () => {
    const ctx = canvasRef.current?.getContext('2d');
    if (ctx && canvasRef.current) ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    setIsSigning(false);
    setSignatureDone(false);
  };
  const applySignature = () => {
    if (!selectedDoc || !isSigning) return;
    setSignatureDone(true);
    updateStatus(selectedDoc.id, 'signed');
    setTimeout(() => { setSignatureMode(false); setSignatureDone(false); setIsSigning(false); clearCanvas(); }, 1800);
  };

  const StatusBadge = ({ status }: { status: DocStatus }) => {
    const sc = statusConf[status];
    const c = T[sc.color];
    return (
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', padding: '3px 9px', borderRadius: '20px', fontSize: '10px', fontWeight: 500, background: c.bg, color: c.text }}>
        {sc.icon} {sc.label}
      </span>
    );
  };

  const typeColors: Record<string, keyof typeof T> = { PDF: 'coral', DOC: 'violet', DOCX: 'violet', XLS: 'emerald' };

  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '32px' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '28px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '4px' }}>
            <div style={{ width: '28px', height: '28px', borderRadius: '7px', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Shield size={14} color="#1D9E75" />
            </div>
            <h1 style={{ fontSize: '20px', fontWeight: 500, margin: 0, letterSpacing: '-0.01em' }}>Document Chamber</h1>
          </div>
          <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0, paddingLeft: '38px' }}>Secure deal documents · E-signatures · Contract lifecycle</p>
        </div>
        <button onClick={() => setShowUploadModal(true)} style={{ display: 'flex', alignItems: 'center', gap: '7px', padding: '9px 18px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '10px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>
          <FilePlus size={14} /> Upload document
        </button>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '14px', marginBottom: '24px' }}>
        {([
          { label: 'Total documents', value: docs.length,                                    color: 'violet' as const },
          { label: 'Draft',           value: docs.filter(d=>d.status==='draft').length,       color: 'amber' as const },
          { label: 'In review',       value: docs.filter(d=>d.status==='in-review').length,   color: 'violet' as const },
          { label: 'Signed',          value: docs.filter(d=>d.status==='signed').length,      color: 'emerald' as const },
        ]).map((s,i) => {
          const c = T[s.color];
          return (
            <div key={i} style={baseCard}>
              <div style={{ height: '2px', background: c.fill }} />
              <div style={{ padding: '16px 18px' }}>
                <div style={{ fontSize: '26px', fontWeight: 500, letterSpacing: '-0.02em', lineHeight: 1 }}>{s.value}</div>
                <div style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginTop: '5px' }}>{s.label}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', borderBottom: '0.5px solid rgba(0,0,0,0.08)', marginBottom: '20px' }}>
        {([
          { key: 'chamber', label: 'Document chamber' },
          { key: 'signature', label: 'E-signature pad' },
        ] as const).map(t => (
          <button key={t.key} onClick={() => setActiveTab(t.key)} style={{ padding: '10px 20px', background: 'none', border: 'none', cursor: 'pointer', fontSize: '13px', fontWeight: activeTab === t.key ? 500 : 400, color: activeTab === t.key ? '#1D9E75' : 'var(--color-text-secondary)', borderBottom: activeTab === t.key ? '2px solid #1D9E75' : '2px solid transparent', marginBottom: '-0.5px', transition: 'all 0.15s' }}>
            {t.label}
          </button>
        ))}
      </div>

      {/* CHAMBER TAB */}
      {activeTab === 'chamber' && (
        <div style={{ display: 'grid', gridTemplateColumns: selectedDoc ? '1fr 380px' : '1fr', gap: '16px', alignItems: 'start' }}>

          {/* Document list */}
          <div style={baseCard}>
            {/* Filters */}
            <div style={{ padding: '12px 20px', borderBottom: '0.5px solid rgba(0,0,0,0.07)', display: 'flex', gap: '6px', flexWrap: 'wrap', alignItems: 'center' }}>
              {(['all','draft','in-review','signed'] as const).map(f => {
                const active = filterStatus === f;
                const label = f === 'all' ? 'All' : statusConf[f as DocStatus]?.label || f;
                return (
                  <button key={f} onClick={() => setFilterStatus(f)} style={{ padding: '5px 12px', borderRadius: '20px', border: '0.5px solid', cursor: 'pointer', fontSize: '12px', fontWeight: active ? 500 : 400, transition: 'all 0.15s', background: active ? '#EAF3DE' : 'var(--color-background-primary,#fff)', color: active ? '#0F6E56' : 'var(--color-text-secondary)', borderColor: active ? '#1D9E75' : 'rgba(0,0,0,0.10)' }}>
                    {label}
                  </button>
                );
              })}
              <span style={{ marginLeft: 'auto', fontSize: '11px', color: 'var(--color-text-secondary)' }}>{filtered.length} document{filtered.length !== 1 ? 's' : ''}</span>
            </div>

            {/* Upload drop zone */}
            <div
              onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              style={{ margin: '12px 20px', padding: '16px', border: `2px dashed ${isDragging ? '#1D9E75' : 'rgba(0,0,0,0.10)'}`, borderRadius: '10px', textAlign: 'center', transition: 'all 0.2s', background: isDragging ? '#EAF3DE' : 'var(--color-background-secondary,#f8f7f4)', cursor: 'pointer' }}
              onClick={() => setShowUploadModal(true)}
            >
              <Upload size={18} color={isDragging ? '#1D9E75' : 'var(--color-text-tertiary,#b0b0b0)'} style={{ margin: '0 auto 6px', display: 'block' }} />
              <p style={{ fontSize: '12px', color: isDragging ? '#1D9E75' : 'var(--color-text-secondary)', margin: 0, fontWeight: isDragging ? 500 : 400 }}>
                {isDragging ? 'Drop to upload' : 'Drag & drop PDFs or click to browse'}
              </p>
            </div>

            {/* Table */}
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ background: 'var(--color-background-secondary,#f8f7f4)' }}>
                    {['Document','Status','Parties','Uploaded',''].map((h,i) => (
                      <th key={i} style={{ padding: '9px 16px', textAlign: 'left', fontSize: '10px', fontWeight: 500, color: 'var(--color-text-secondary)', letterSpacing: '0.05em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((doc, idx) => {
                    const tc = T[typeColors[doc.type] || 'coral'];
                    const isSelected = selectedDoc?.id === doc.id;
                    return (
                      <tr key={doc.id} onClick={() => setSelectedDoc(isSelected ? null : doc)}
                        style={{ borderTop: '0.5px solid rgba(0,0,0,0.05)', cursor: 'pointer', background: isSelected ? '#EAF3DE' : 'transparent', transition: 'background 0.1s' }}
                        onMouseEnter={e => { if (!isSelected) (e.currentTarget as HTMLElement).style.background = 'var(--color-background-secondary,#f8f7f4)'; }}
                        onMouseLeave={e => { if (!isSelected) (e.currentTarget as HTMLElement).style.background = 'transparent'; }}>
                        <td style={{ padding: '12px 16px', whiteSpace: 'nowrap' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                            <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: tc.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                              <span style={{ fontSize: '9px', fontWeight: 500, color: tc.text }}>{doc.type}</span>
                            </div>
                            <div>
                              <p style={{ fontSize: '13px', fontWeight: 500, margin: 0, maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{doc.name}</p>
                              <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)', margin: 0 }}>{doc.size} · {doc.pages} pages</p>
                            </div>
                          </div>
                        </td>
                        <td style={{ padding: '12px 16px' }}><StatusBadge status={doc.status} /></td>
                        <td style={{ padding: '12px 16px' }}>
                          <div style={{ display: 'flex', gap: '4px' }}>
                            {doc.parties.slice(0,2).map((p,i) => {
                              const c = [T.emerald,T.violet,T.amber][i % 3];
                              return <span key={i} style={{ fontSize: '10px', padding: '2px 7px', borderRadius: '20px', background: c.bg, color: c.text, fontWeight: 500 }}>{p.split(' ')[0]}</span>;
                            })}
                          </div>
                        </td>
                        <td style={{ padding: '12px 16px', fontSize: '12px', color: 'var(--color-text-secondary)', whiteSpace: 'nowrap' }}>
                          {new Date(doc.uploadedAt).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}
                        </td>
                        <td style={{ padding: '12px 16px' }}>
                          <div style={{ display: 'flex', gap: '3px' }}>
                            {[<Eye size={13}/>,<Download size={13}/>,<Trash2 size={13}/>].map((icon,i) => (
                              <button key={i} onClick={e => { e.stopPropagation(); if(i===2) deleteDoc(doc.id); }}
                                style={{ width: '28px', height: '28px', borderRadius: '6px', border: 'none', background: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--color-text-tertiary,#b0b0b0)' }}
                                onMouseEnter={e => { e.currentTarget.style.background = i===2?'#FAECE7':'#EAF3DE'; e.currentTarget.style.color = i===2?'#D85A30':'#1D9E75'; }}
                                onMouseLeave={e => { e.currentTarget.style.background = 'none'; e.currentTarget.style.color = 'var(--color-text-tertiary,#b0b0b0)'; }}>
                                {icon}
                              </button>
                            ))}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Document Preview Panel */}
          {selectedDoc && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div style={baseCard}>
                <div style={panelHead}>
                  <div style={{ fontSize: '13px', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '240px' }}>{selectedDoc.name}</div>
                  <button onClick={() => setSelectedDoc(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--color-text-secondary)', display: 'flex', alignItems: 'center' }}>
                    <X size={15}/>
                  </button>
                </div>
                {/* PDF preview mockup */}
                <div style={{ padding: '16px', display: 'flex', justifyContent: 'center' }}>
                  <div style={{ width: '100%', background: 'var(--color-background-secondary,#f8f7f4)', borderRadius: '8px', padding: '20px', minHeight: '280px', position: 'relative', border: '0.5px solid rgba(0,0,0,0.08)', transform: `scale(${zoom/100})`, transformOrigin: 'top center', transition: 'transform 0.2s' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px', paddingBottom: '12px', borderBottom: '0.5px solid rgba(0,0,0,0.10)' }}>
                      <div>
                        <div style={{ fontSize: '14px', fontWeight: 500, marginBottom: '3px' }}>{selectedDoc.name.replace('.pdf','').replace('.docx','')}</div>
                        <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>Page 1 of {selectedDoc.pages}</div>
                      </div>
                      <div style={{ width: '32px', height: '32px', borderRadius: '7px', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Shield size={14} color="#1D9E75"/>
                      </div>
                    </div>
                    {[80,60,90,50,70,40,80,55].map((w,i)=>(
                      <div key={i} style={{ height: '7px', width: `${w}%`, background: i%3===0?'rgba(0,0,0,0.10)':'rgba(0,0,0,0.06)', borderRadius: '4px', marginBottom: '8px' }} />
                    ))}
                    <div style={{ marginTop: '16px', padding: '10px 12px', background: '#EAF3DE', borderRadius: '8px', border: '0.5px dashed #C0DD97' }}>
                      <div style={{ fontSize: '10px', fontWeight: 500, color: '#0F6E56', marginBottom: '4px' }}>Signature field</div>
                      {selectedDoc.status === 'signed'
                        ? <div style={{ fontFamily: 'Georgia, serif', fontSize: '18px', color: '#1D9E75' }}>Alex Kim</div>
                        : <div style={{ fontSize: '11px', color: '#BA7517', display: 'flex', alignItems: 'center', gap: '4px' }}><AlertCircle size={11}/> Awaiting signature</div>
                      }
                    </div>
                  </div>
                </div>
                {/* Zoom controls */}
                <div style={{ padding: '8px 16px', borderTop: '0.5px solid rgba(0,0,0,0.06)', display: 'flex', alignItems: 'center', gap: '6px', justifyContent: 'center' }}>
                  <button onClick={()=>setZoom(z=>Math.max(60,z-10))} style={{ width:'26px',height:'26px',borderRadius:'6px',border:'0.5px solid rgba(0,0,0,0.10)',background:'none',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',color:'var(--color-text-secondary)' }}><ZoomOut size={12}/></button>
                  <span style={{ fontSize:'11px',color:'var(--color-text-secondary)',minWidth:'36px',textAlign:'center' }}>{zoom}%</span>
                  <button onClick={()=>setZoom(z=>Math.min(150,z+10))} style={{ width:'26px',height:'26px',borderRadius:'6px',border:'0.5px solid rgba(0,0,0,0.10)',background:'none',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',color:'var(--color-text-secondary)' }}><ZoomIn size={12}/></button>
                </div>
              </div>

              {/* Status & actions */}
              <div style={baseCard}>
                <div style={{ padding: '14px 18px', borderBottom: '0.5px solid rgba(0,0,0,0.07)', fontSize: '13px', fontWeight: 500 }}>Document status</div>
                <div style={{ padding: '14px 18px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: '12px', color: 'var(--color-text-secondary)' }}>Current status</span>
                    <StatusBadge status={selectedDoc.status} />
                  </div>
                  <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                    {(['draft','in-review','signed'] as DocStatus[]).map(s => {
                      const sc = statusConf[s];
                      const c = T[sc.color];
                      const active = selectedDoc.status === s;
                      return (
                        <button key={s} onClick={() => updateStatus(selectedDoc.id, s)} style={{ flex: 1, padding: '7px 10px', border: `0.5px solid ${active ? c.fill : 'rgba(0,0,0,0.10)'}`, borderRadius: '8px', background: active ? c.bg : 'var(--color-background-primary,#fff)', color: active ? c.text : 'var(--color-text-secondary)', cursor: 'pointer', fontSize: '11px', fontWeight: active ? 500 : 400, transition: 'all 0.15s', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
                          {sc.icon} {sc.label}
                        </button>
                      );
                    })}
                  </div>
                  {selectedDoc.status !== 'signed' && (
                    <button onClick={() => { setSignatureMode(true); setActiveTab('signature'); }}
                      style={{ width: '100%', padding: '9px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                      <PenTool size={13}/> Sign this document
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SIGNATURE PAD TAB */}
      {activeTab === 'signature' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: '16px', alignItems: 'start' }}>
          <div style={baseCard}>
            <div style={panelHead}>
              <div>
                <div style={{ fontSize: '14px', fontWeight: 500 }}>E-signature pad</div>
                <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>Draw your signature below</div>
              </div>
              {isSigning && !signatureDone && (
                <button onClick={clearCanvas} style={{ display: 'flex', alignItems: 'center', gap: '5px', padding: '6px 12px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '8px', background: 'none', cursor: 'pointer', fontSize: '12px', color: 'var(--color-text-secondary)' }}>
                  <RotateCcw size={12}/> Clear
                </button>
              )}
            </div>
            <div style={{ padding: '20px' }}>
              {signatureDone ? (
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '60px 20px', gap: '14px' }}>
                  <div style={{ width: '56px', height: '56px', borderRadius: '50%', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <CheckCircle size={28} color="#1D9E75"/>
                  </div>
                  <p style={{ fontSize: '15px', fontWeight: 500, margin: 0 }}>Document signed successfully</p>
                  <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>Status updated to Signed</p>
                </div>
              ) : (
                <>
                  <div style={{ border: '2px dashed rgba(0,0,0,0.12)', borderRadius: '12px', overflow: 'hidden', background: 'var(--color-background-secondary,#f8f7f4)', cursor: 'crosshair', position: 'relative' }}>
                    <canvas
                      ref={canvasRef}
                      width={560}
                      height={200}
                      style={{ display: 'block', width: '100%', height: '200px', touchAction: 'none' }}
                      onMouseDown={startDraw}
                      onMouseMove={draw}
                      onMouseUp={endDraw}
                      onMouseLeave={endDraw}
                    />
                    {!isSigning && (
                      <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
                        <div style={{ textAlign: 'center' }}>
                          <PenTool size={24} color="rgba(0,0,0,0.15)" style={{ margin: '0 auto 8px', display: 'block' }}/>
                          <p style={{ fontSize: '13px', color: 'rgba(0,0,0,0.25)', margin: 0 }}>Draw your signature here</p>
                        </div>
                      </div>
                    )}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', marginTop: '10px' }}>
                    <div style={{ flex: 1, height: '0.5px', background: 'rgba(0,0,0,0.08)' }}/>
                    <span style={{ padding: '0 12px', fontSize: '11px', color: 'var(--color-text-secondary)' }}>X — Sign above the line</span>
                    <div style={{ flex: 1, height: '0.5px', background: 'rgba(0,0,0,0.08)' }}/>
                  </div>
                  <div style={{ display: 'flex', gap: '8px', marginTop: '16px' }}>
                    <button onClick={clearCanvas} style={{ flex: 1, padding: '9px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '9px', background: 'none', cursor: 'pointer', fontSize: '13px', color: 'var(--color-text-secondary)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '5px' }}>
                      <RotateCcw size={13}/> Clear
                    </button>
                    <button onClick={applySignature} disabled={!isSigning || !selectedDoc}
                      style={{ flex: 2, padding: '9px', background: isSigning && selectedDoc ? '#1D9E75' : 'rgba(0,0,0,0.06)', color: isSigning && selectedDoc ? '#fff' : 'var(--color-text-tertiary,#b0b0b0)', border: 'none', borderRadius: '9px', cursor: isSigning && selectedDoc ? 'pointer' : 'default', fontSize: '13px', fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '5px', transition: 'all 0.15s' }}>
                      <Check size={13}/> Apply signature
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Right panel — document selector */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            <div style={baseCard}>
              <div style={{ padding: '14px 18px', borderBottom: '0.5px solid rgba(0,0,0,0.07)', fontSize: '13px', fontWeight: 500 }}>Select document to sign</div>
              <div style={{ padding: '8px 0' }}>
                {docs.filter(d => d.status !== 'signed').map(doc => {
                  const tc = T[typeColors[doc.type] || 'coral'];
                  const isSelected = selectedDoc?.id === doc.id;
                  return (
                    <div key={doc.id} onClick={() => setSelectedDoc(doc)}
                      style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 18px', cursor: 'pointer', background: isSelected ? '#EAF3DE' : 'transparent', borderLeft: `2px solid ${isSelected ? '#1D9E75' : 'transparent'}`, transition: 'all 0.12s' }}
                      onMouseEnter={e => { if (!isSelected) (e.currentTarget as HTMLElement).style.background = 'var(--color-background-secondary,#f8f7f4)'; }}
                      onMouseLeave={e => { if (!isSelected) (e.currentTarget as HTMLElement).style.background = 'transparent'; }}>
                      <div style={{ width: '28px', height: '28px', borderRadius: '6px', background: tc.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <span style={{ fontSize: '8px', fontWeight: 500, color: tc.text }}>{doc.type}</span>
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <p style={{ fontSize: '12px', fontWeight: 500, margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{doc.name}</p>
                        <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)', margin: 0 }}>{doc.pages} pages</p>
                      </div>
                      {isSelected && <ChevronRight size={13} color="#1D9E75"/>}
                    </div>
                  );
                })}
                {docs.filter(d => d.status !== 'signed').length === 0 && (
                  <div style={{ padding: '24px 18px', textAlign: 'center' }}>
                    <CheckCircle size={20} color="#1D9E75" style={{ margin: '0 auto 8px', display: 'block' }}/>
                    <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: 0 }}>All documents signed</p>
                  </div>
                )}
              </div>
            </div>

            {/* Signed docs */}
            {docs.filter(d => d.status === 'signed').length > 0 && (
              <div style={baseCard}>
                <div style={{ padding: '14px 18px', borderBottom: '0.5px solid rgba(0,0,0,0.07)', fontSize: '13px', fontWeight: 500, display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <CheckCircle size={13} color="#1D9E75"/> Signed documents
                </div>
                <div style={{ padding: '8px 0' }}>
                  {docs.filter(d => d.status === 'signed').map(doc => (
                    <div key={doc.id} style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '8px 18px', opacity: 0.7 }}>
                      <CheckCircle size={13} color="#1D9E75" style={{ flexShrink: 0 }}/>
                      <p style={{ fontSize: '12px', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{doc.name}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Upload Modal */}
      {showUploadModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 50 }}
          onClick={() => setShowUploadModal(false)}>
          <div style={{ background: 'var(--color-background-primary,#fff)', borderRadius: '16px', padding: '28px', width: '420px', border: '0.5px solid rgba(0,0,0,0.08)' }}
            onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <h3 style={{ fontSize: '15px', fontWeight: 500, margin: 0 }}>Upload document</h3>
              <button onClick={() => setShowUploadModal(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--color-text-secondary)' }}><X size={16}/></button>
            </div>
            <div
              onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={e => { handleDrop(e); setShowUploadModal(false); }}
              style={{ border: `2px dashed ${isDragging ? '#1D9E75' : 'rgba(0,0,0,0.12)'}`, borderRadius: '12px', padding: '40px 20px', textAlign: 'center', background: isDragging ? '#EAF3DE' : 'var(--color-background-secondary,#f8f7f4)', transition: 'all 0.2s', cursor: 'pointer' }}>
              <Upload size={28} color={isDragging ? '#1D9E75' : 'rgba(0,0,0,0.20)'} style={{ margin: '0 auto 12px', display: 'block' }}/>
              <p style={{ fontSize: '13px', fontWeight: 500, margin: '0 0 4px' }}>Drop files here</p>
              <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: 0 }}>PDF, DOC, DOCX up to 20MB</p>
            </div>
            <div style={{ display: 'flex', gap: '8px', marginTop: '16px' }}>
              <button onClick={() => setShowUploadModal(false)} style={{ flex: 1, padding: '9px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '9px', background: 'none', cursor: 'pointer', fontSize: '13px', color: 'var(--color-text-secondary)' }}>Cancel</button>
              <button style={{ flex: 1, padding: '9px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '9px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>Browse files</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};