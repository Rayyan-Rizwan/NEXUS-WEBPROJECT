import React, { useState } from 'react';
import { Search, Filter, DollarSign, TrendingUp, Users, Calendar, Plus, X, ArrowUpRight } from 'lucide-react';
import { Avatar } from '../../components/ui/Avatar';

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD' },
  amber:   { bg: '#FAEEDA', text: '#854F0B', fill: '#BA7517' },
  coral:   { bg: '#FAECE7', text: '#993C1D', fill: '#D85A30' },
  rose:    { bg: '#FBEAF0', text: '#993556', fill: '#D4537E' },
};

const statusMap: Record<string, { color: keyof typeof T; label: string }> = {
  'Due Diligence': { color: 'violet', label: 'Due diligence' },
  'Term Sheet':    { color: 'amber',  label: 'Term sheet' },
  'Negotiation':   { color: 'coral',  label: 'Negotiation' },
  'Closed':        { color: 'emerald',label: 'Closed' },
  'Passed':        { color: 'rose',   label: 'Passed' },
};

const deals = [
  { id: 1, startup: { name: 'TechWave AI', logo: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg', industry: 'FinTech', initials: 'TW' }, amount: '$1.5M', equity: '15%', status: 'Due Diligence', stage: 'Series A', lastActivity: '2024-02-15' },
  { id: 2, startup: { name: 'GreenLife Solutions', logo: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg', industry: 'CleanTech', initials: 'GL' }, amount: '$2.0M', equity: '20%', status: 'Term Sheet', stage: 'Seed', lastActivity: '2024-02-10' },
  { id: 3, startup: { name: 'HealthPulse', logo: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg', industry: 'HealthTech', initials: 'HP' }, amount: '$800K', equity: '12%', status: 'Negotiation', stage: 'Pre-seed', lastActivity: '2024-02-05' },
  { id: 4, startup: { name: 'VoiceSync', logo: '', industry: 'AI/ML', initials: 'VS' }, amount: '$1.1M', equity: '18%', status: 'Closed', stage: 'Seed', lastActivity: '2024-01-30' },
  { id: 5, startup: { name: 'DataBridge', logo: '', industry: 'SaaS', initials: 'DB' }, amount: '$3.2M', equity: '22%', status: 'Term Sheet', stage: 'Series A', lastActivity: '2024-01-25' },
];

const baseCard: React.CSSProperties = { background: 'var(--color-background-primary,#fff)', border: '0.5px solid rgba(0,0,0,0.08)', borderRadius: '14px', overflow: 'hidden' };

const statCards = [
  { icon: <DollarSign size={15} />, label: 'Total investment', value: '$4.3M', color: 'emerald' as const, tag: '+18.4% QoQ' },
  { icon: <TrendingUp size={15} />, label: 'Active deals', value: '8', color: 'violet' as const, tag: '3 new this month' },
  { icon: <Users size={15} />, label: 'Portfolio companies', value: '12', color: 'amber' as const, tag: '2 exited' },
  { icon: <Calendar size={15} />, label: 'Closed this month', value: '2', color: 'coral' as const, tag: 'On track' },
];

export const DealsPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string[]>([]);

  const statuses = Object.keys(statusMap);

  const toggleStatus = (s: string) =>
    setSelectedStatus(p => p.includes(s) ? p.filter(x => x !== s) : [...p, s]);

  const filtered = deals.filter(d => {
    const q = searchQuery.toLowerCase();
    const matchSearch = !searchQuery || d.startup.name.toLowerCase().includes(q) || d.startup.industry.toLowerCase().includes(q);
    const matchStatus = !selectedStatus.length || selectedStatus.includes(d.status);
    return matchSearch && matchStatus;
  });

  const avatarColors: (keyof typeof T)[] = ['emerald', 'violet', 'amber', 'coral', 'rose'];

  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '32px' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '28px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <h1 style={{ fontSize: '20px', fontWeight: 500, margin: '0 0 4px', letterSpacing: '-0.01em' }}>Investment deals</h1>
          <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>Track and manage your investment pipeline</p>
        </div>
        <button style={{ display: 'flex', alignItems: 'center', gap: '7px', padding: '9px 18px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '10px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>
          <Plus size={14} /> Add deal
        </button>
      </div>

      {/* KPIs */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '14px', marginBottom: '24px' }}>
        {statCards.map((k, i) => {
          const c = T[k.color];
          return (
            <div key={i} style={baseCard}>
              <div style={{ height: '2px', background: c.fill }} />
              <div style={{ padding: '18px 20px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
                  <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: c.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', color: c.text }}>{k.icon}</div>
                  <span style={{ fontSize: '10px', fontWeight: 500, padding: '2px 8px', borderRadius: '20px', background: c.bg, color: c.text }}>{k.tag}</span>
                </div>
                <div style={{ fontSize: '28px', fontWeight: 500, letterSpacing: '-0.02em', lineHeight: 1 }}>{k.value}</div>
                <div style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginTop: '6px' }}>{k.label}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Filters bar */}
      <div style={{ ...baseCard, marginBottom: '16px' }}>
        <div style={{ padding: '14px 20px', display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: '200px', position: 'relative' }}>
            <Search size={14} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--color-text-tertiary,#b0b0b0)' }} />
            <input
              placeholder="Search by startup name or industry…"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              style={{ width: '100%', padding: '8px 12px 8px 34px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '9px', fontSize: '13px', outline: 'none', background: 'var(--color-background-secondary,#f8f7f4)', color: 'var(--color-text-primary)', boxSizing: 'border-box' as const }}
            />
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
            <Filter size={13} color="var(--color-text-tertiary,#b0b0b0)" />
            {statuses.map(s => {
              const active = selectedStatus.includes(s);
              const sc = T[statusMap[s].color];
              return (
                <button key={s} onClick={() => toggleStatus(s)} style={{ display: 'flex', alignItems: 'center', gap: '5px', padding: '5px 11px', borderRadius: '20px', border: '0.5px solid', cursor: 'pointer', fontSize: '12px', fontWeight: active ? 500 : 400, transition: 'all 0.15s', background: active ? sc.bg : 'var(--color-background-primary,#fff)', color: active ? sc.text : 'var(--color-text-secondary)', borderColor: active ? sc.fill : 'rgba(0,0,0,0.10)' }}>
                  {active && <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: sc.fill, flexShrink: 0 }} />}
                  {statusMap[s].label}
                </button>
              );
            })}
            {selectedStatus.length > 0 && (
              <button onClick={() => setSelectedStatus([])} style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '5px 10px', borderRadius: '20px', border: '0.5px solid rgba(0,0,0,0.10)', background: 'none', cursor: 'pointer', fontSize: '12px', color: 'var(--color-text-secondary)' }}>
                <X size={11} /> Clear
              </button>
            )}
          </div>
          <span style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginLeft: 'auto', flexShrink: 0 }}>{filtered.length} deal{filtered.length !== 1 ? 's' : ''}</span>
        </div>
      </div>

      {/* Table */}
      <div style={baseCard}>
        <div style={{ padding: '16px 24px', borderBottom: '0.5px solid rgba(0,0,0,0.07)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ fontSize: '14px', fontWeight: 500 }}>Active deals</div>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed' as const }}>
            <colgroup>
              <col style={{ width: '220px' }} /><col style={{ width: '100px' }} /><col style={{ width: '80px' }} /><col style={{ width: '140px' }} /><col style={{ width: '100px' }} /><col style={{ width: '120px' }} /><col style={{ width: '120px' }} />
            </colgroup>
            <thead>
              <tr style={{ background: 'var(--color-background-secondary,#f8f7f4)' }}>
                {['Startup','Amount','Equity','Status','Stage','Last activity',''].map((h, i) => (
                  <th key={i} style={{ padding: '10px 16px', textAlign: i === 6 ? 'right' : 'left', fontSize: '11px', fontWeight: 500, color: 'var(--color-text-secondary)', letterSpacing: '0.04em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((deal, idx) => {
                const sc = statusMap[deal.status];
                const tc = T[sc.color];
                const av = T[avatarColors[idx % avatarColors.length]];
                return (
                  <tr key={deal.id} style={{ borderTop: '0.5px solid rgba(0,0,0,0.06)', cursor: 'pointer' }}
                    onMouseEnter={e => (e.currentTarget.style.background = 'var(--color-background-secondary,#f8f7f4)')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                    <td style={{ padding: '12px 16px', whiteSpace: 'nowrap' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: av.bg, color: av.text, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', fontWeight: 500, flexShrink: 0 }}>{deal.startup.initials}</div>
                        <div>
                          <p style={{ fontSize: '13px', fontWeight: 500, margin: 0 }}>{deal.startup.name}</p>
                          <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)', margin: 0 }}>{deal.startup.industry}</p>
                        </div>
                      </div>
                    </td>
                    <td style={{ padding: '12px 16px', fontSize: '13px', fontWeight: 500 }}>{deal.amount}</td>
                    <td style={{ padding: '12px 16px', fontSize: '13px', color: 'var(--color-text-secondary)' }}>{deal.equity}</td>
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', padding: '4px 10px', borderRadius: '20px', fontSize: '11px', fontWeight: 500, background: tc.bg, color: tc.text }}>
                        <span style={{ width: '5px', height: '5px', borderRadius: '50%', background: tc.fill, flexShrink: 0 }} />
                        {sc.label}
                      </span>
                    </td>
                    <td style={{ padding: '12px 16px', fontSize: '12px', color: 'var(--color-text-secondary)' }}>{deal.stage}</td>
                    <td style={{ padding: '12px 16px', fontSize: '12px', color: 'var(--color-text-secondary)' }}>
                      {new Date(deal.lastActivity).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                    </td>
                    <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                      <button style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', padding: '6px 12px', background: 'var(--color-background-primary,#fff)', color: 'var(--color-text-secondary)', border: '0.5px solid rgba(0,0,0,0.12)', borderRadius: '8px', cursor: 'pointer', fontSize: '12px' }}>
                        Details <ArrowUpRight size={11} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};