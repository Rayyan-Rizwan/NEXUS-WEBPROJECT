import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  MessageCircle, Users, Calendar, Building2, MapPin, UserCircle,
  FileText, DollarSign, Send, ArrowLeft, TrendingUp, CheckCircle, Clock, Eye
} from 'lucide-react';
import { Avatar } from '../../components/ui/Avatar';
import { useAuth } from '../../context/AuthContext';
import { findUserById } from '../../data/users';
import { createCollaborationRequest, getRequestsFromInvestor } from '../../data/collaborationRequests';
import { Entrepreneur } from '../../types';

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75', mid: '#C0DD97' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD', mid: '#AFA9EC' },
  amber:   { bg: '#FAEEDA', text: '#854F0B', fill: '#BA7517', mid: '#FAC775' },
  coral:   { bg: '#FAECE7', text: '#993C1D', fill: '#D85A30', mid: '#F5C4B3' },
};

const baseCard: React.CSSProperties = {
  background: 'var(--color-background-primary,#fff)',
  border: '0.5px solid rgba(0,0,0,0.08)',
  borderRadius: '14px',
  overflow: 'hidden',
};

const panelHead: React.CSSProperties = {
  padding: '16px 24px',
  borderBottom: '0.5px solid rgba(0,0,0,0.07)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
};

const teamMembers = [
  { name: 'Alex Johnson', role: 'CTO', initials: 'AJ', colorIdx: 1 },
  { name: 'Jessica Chen', role: 'Head of Product', initials: 'JC', colorIdx: 2 },
];

const avatarColors = [T.emerald, T.violet, T.amber, T.coral];
const getAv = (idx: number) => avatarColors[idx % avatarColors.length];

const documents = [
  { name: 'Pitch Deck', updated: '2 months ago', type: 'PDF' },
  { name: 'Business Plan', updated: '1 month ago', type: 'DOC' },
  { name: 'Financial Projections', updated: '2 weeks ago', type: 'XLS' },
];

const docColors: Record<string, keyof typeof T> = { PDF: 'coral', DOC: 'violet', XLS: 'emerald' };

export const EntrepreneurProfile: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user: currentUser } = useAuth();
  const [requestSent, setRequestSent] = useState(false);

  const entrepreneur = findUserById(id || '') as Entrepreneur | null;

  if (!entrepreneur || entrepreneur.role !== 'entrepreneur') {
    return (
      <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', padding: '60px', textAlign: 'center' }}>
        <div style={{ width: '52px', height: '52px', borderRadius: '14px', background: '#FAECE7', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
          <UserCircle size={26} color="#D85A30" />
        </div>
        <h2 style={{ fontSize: '18px', fontWeight: 500, margin: '0 0 6px' }}>Entrepreneur not found</h2>
        <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: '0 0 20px' }}>This profile doesn't exist or has been removed.</p>
        <Link to="/dashboard/investor" style={{ textDecoration: 'none' }}>
          <button style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '9px 18px', background: 'var(--color-background-primary,#fff)', color: 'var(--color-text-secondary)', border: '0.5px solid rgba(0,0,0,0.12)', borderRadius: '10px', cursor: 'pointer', fontSize: '13px' }}>
            <ArrowLeft size={14} /> Back to dashboard
          </button>
        </Link>
      </div>
    );
  }

  const isCurrentUser = currentUser?.id === entrepreneur.id;
  const isInvestor = currentUser?.role === 'investor';
  const hasRequestedCollaboration = requestSent || (isInvestor && id
    ? getRequestsFromInvestor(currentUser!.id).some(req => req.entrepreneurId === id)
    : false);

  const initials = entrepreneur.name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
  const av = getAv(0);

  const handleSendRequest = () => {
    if (isInvestor && currentUser && id) {
      createCollaborationRequest(
        currentUser.id, id,
        `I'm interested in learning more about ${entrepreneur.startupName} and would like to explore potential investment opportunities.`
      );
      setRequestSent(true);
    }
  };

  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '32px' }}>

      {/* Back link */}
      <div style={{ marginBottom: '20px' }}>
        <Link to={isInvestor ? '/dashboard/investor' : '/dashboard/entrepreneur'} style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', fontSize: '13px', color: 'var(--color-text-secondary)', textDecoration: 'none' }}>
          <ArrowLeft size={13} /> Back
        </Link>
      </div>

      {/* Profile hero */}
      <div style={{ ...baseCard, marginBottom: '20px' }}>
        <div style={{ height: '3px', background: `linear-gradient(90deg, ${T.emerald.fill}, ${T.violet.fill})` }} />
        <div style={{ padding: '28px 28px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: '18px' }}>
            {/* Avatar */}
            <div style={{ position: 'relative', flexShrink: 0 }}>
              <div style={{ width: '68px', height: '68px', borderRadius: '16px', background: av.bg, color: av.text, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '22px', fontWeight: 500 }}>
                {initials}
              </div>
              {entrepreneur.isOnline && (
                <span style={{ position: 'absolute', bottom: '2px', right: '2px', width: '12px', height: '12px', borderRadius: '50%', background: '#1D9E75', border: '2px solid var(--color-background-primary,#fff)' }} />
              )}
            </div>
            <div>
              <h1 style={{ fontSize: '20px', fontWeight: 500, margin: '0 0 4px', letterSpacing: '-0.01em' }}>{entrepreneur.name}</h1>
              <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: '0 0 10px', display: 'flex', alignItems: 'center', gap: '5px' }}>
                <Building2 size={13} /> Founder at {entrepreneur.startupName}
              </p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                {[
                  { icon: <MapPin size={11} />, label: entrepreneur.location, color: 'violet' as const },
                  { icon: <Calendar size={11} />, label: `Founded ${entrepreneur.foundedYear}`, color: 'amber' as const },
                  { icon: <Users size={11} />, label: `${entrepreneur.teamSize} team members`, color: 'emerald' as const },
                ].map((tag, i) => {
                  const c = T[tag.color];
                  return (
                    <span key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', padding: '4px 10px', borderRadius: '20px', fontSize: '11px', fontWeight: 500, background: c.bg, color: c.text }}>
                      {tag.icon} {tag.label}
                    </span>
                  );
                })}
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', padding: '4px 10px', borderRadius: '20px', fontSize: '11px', fontWeight: 500, background: T.coral.bg, color: T.coral.text }}>
                  {entrepreneur.industry}
                </span>
              </div>
            </div>
          </div>

          {/* Actions */}
          {!isCurrentUser && (
            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
              <Link to={`/chat/${entrepreneur.id}`} style={{ textDecoration: 'none' }}>
                <button style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '9px 16px', background: 'var(--color-background-primary,#fff)', color: 'var(--color-text-secondary)', border: '0.5px solid rgba(0,0,0,0.12)', borderRadius: '10px', cursor: 'pointer', fontSize: '13px' }}>
                  <MessageCircle size={14} /> Message
                </button>
              </Link>
              {isInvestor && (
                <button
                  onClick={handleSendRequest}
                  disabled={hasRequestedCollaboration}
                  style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '9px 18px', background: hasRequestedCollaboration ? '#EAF3DE' : '#1D9E75', color: hasRequestedCollaboration ? '#0F6E56' : '#fff', border: hasRequestedCollaboration ? '0.5px solid #C0DD97' : 'none', borderRadius: '10px', cursor: hasRequestedCollaboration ? 'default' : 'pointer', fontSize: '13px', fontWeight: 500 }}
                >
                  {hasRequestedCollaboration ? <><CheckCircle size={13} /> Request Sent</> : <><Send size={13} /> Request Collaboration</>}
                </button>
              )}
            </div>
          )}
          {isCurrentUser && (
            <button style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '9px 16px', background: 'var(--color-background-primary,#fff)', color: 'var(--color-text-secondary)', border: '0.5px solid rgba(0,0,0,0.12)', borderRadius: '10px', cursor: 'pointer', fontSize: '13px' }}>
              <UserCircle size={14} /> Edit profile
            </button>
          )}
        </div>
      </div>

      {/* Body grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: '16px', alignItems: 'start' }}>

        {/* Main */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>

          {/* About */}
          <div style={baseCard}>
            <div style={panelHead}><div style={{ fontSize: '14px', fontWeight: 500 }}>About</div></div>
            <div style={{ padding: '20px 24px' }}>
              <p style={{ fontSize: '13px', lineHeight: 1.7, color: 'var(--color-text-secondary)', margin: 0 }}>{entrepreneur.bio}</p>
            </div>
          </div>

          {/* Startup overview */}
          <div style={baseCard}>
            <div style={panelHead}><div style={{ fontSize: '14px', fontWeight: 500 }}>Startup overview</div></div>
            <div style={{ padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {[
                { label: 'Problem statement', body: `${entrepreneur.pitchSummary?.split('.')[0]}.` },
                { label: 'Solution', body: entrepreneur.pitchSummary },
                { label: 'Market opportunity', body: `The ${entrepreneur.industry} market is experiencing significant growth, with a projected CAGR of 14.5% through 2027. Our solution addresses key pain points in this expanding market.` },
                { label: 'Competitive advantage', body: 'Unlike our competitors, we offer a unique approach that combines innovative technology with deep industry expertise, resulting in superior outcomes for our customers.' },
              ].map((s, i) => (
                <div key={i}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '6px' }}>
                    <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#1D9E75', flexShrink: 0 }} />
                    <h3 style={{ fontSize: '13px', fontWeight: 500, margin: 0 }}>{s.label}</h3>
                  </div>
                  <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', lineHeight: 1.7, margin: '0 0 0 12px' }}>{s.body}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Team */}
          <div style={baseCard}>
            <div style={{ ...panelHead }}>
              <div style={{ fontSize: '14px', fontWeight: 500 }}>Team</div>
              <span style={{ fontSize: '11px', fontWeight: 500, padding: '3px 10px', borderRadius: '20px', background: '#EAF3DE', color: '#0F6E56' }}>{entrepreneur.teamSize} members</span>
            </div>
            <div style={{ padding: '16px 24px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(200px,1fr))', gap: '10px' }}>
                {/* Founder */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '12px 14px', border: '0.5px solid rgba(0,0,0,0.08)', borderRadius: '10px', background: 'var(--color-background-secondary,#f8f7f4)' }}>
                  <div style={{ width: '34px', height: '34px', borderRadius: '8px', background: av.bg, color: av.text, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', fontWeight: 500, flexShrink: 0 }}>{initials}</div>
                  <div>
                    <p style={{ fontSize: '12px', fontWeight: 500, margin: 0 }}>{entrepreneur.name}</p>
                    <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)', margin: 0 }}>Founder & CEO</p>
                  </div>
                </div>
                {teamMembers.map((m, i) => {
                  const c = getAv(m.colorIdx);
                  return (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '12px 14px', border: '0.5px solid rgba(0,0,0,0.08)', borderRadius: '10px' }}>
                      <div style={{ width: '34px', height: '34px', borderRadius: '8px', background: c.bg, color: c.text, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', fontWeight: 500, flexShrink: 0 }}>{m.initials}</div>
                      <div>
                        <p style={{ fontSize: '12px', fontWeight: 500, margin: 0 }}>{m.name}</p>
                        <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)', margin: 0 }}>{m.role}</p>
                      </div>
                    </div>
                  );
                })}
                {entrepreneur.teamSize > 3 && (
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '12px 14px', border: '0.5px dashed rgba(0,0,0,0.12)', borderRadius: '10px' }}>
                    <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: 0 }}>+ {entrepreneur.teamSize - 3} more members</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>

          {/* Funding */}
          <div style={baseCard}>
            <div style={{ height: '2px', background: T.amber.fill }} />
            <div style={panelHead}><div style={{ fontSize: '14px', fontWeight: 500 }}>Funding details</div></div>
            <div style={{ padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 500 }}>Current round</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                  <DollarSign size={16} color={T.amber.fill} />
                  <span style={{ fontSize: '18px', fontWeight: 500 }}>{entrepreneur.fundingNeeded}</span>
                </div>
              </div>
              {[
                { label: 'Valuation', value: '$8M – $12M' },
                { label: 'Previous funding', value: '$750K Seed (2022)' },
              ].map((item, i) => (
                <div key={i}>
                  <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginBottom: '3px', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 500 }}>{item.label}</div>
                  <div style={{ fontSize: '13px', fontWeight: 500 }}>{item.value}</div>
                </div>
              ))}
              <div style={{ borderTop: '0.5px solid rgba(0,0,0,0.07)', paddingTop: '12px' }}>
                <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 500 }}>Funding timeline</div>
                {[
                  { stage: 'Pre-seed', status: 'Completed', color: 'emerald' as const },
                  { stage: 'Seed', status: 'Completed', color: 'emerald' as const },
                  { stage: 'Series A', status: 'In progress', color: 'amber' as const },
                ].map((r, i) => {
                  const c = T[r.color];
                  return (
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                      <span style={{ fontSize: '12px', fontWeight: 500 }}>{r.stage}</span>
                      <span style={{ fontSize: '10px', fontWeight: 500, padding: '2px 8px', borderRadius: '20px', background: c.bg, color: c.text }}>{r.status}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Documents */}
          <div style={baseCard}>
            <div style={panelHead}><div style={{ fontSize: '14px', fontWeight: 500 }}>Documents</div></div>
            <div style={{ padding: '10px 20px 16px' }}>
              {documents.map((doc, i) => {
                const c = T[docColors[doc.type]];
                return (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 0', borderTop: i > 0 ? '0.5px solid rgba(0,0,0,0.06)' : 'none' }}>
                    <div style={{ width: '34px', height: '34px', borderRadius: '8px', background: c.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <span style={{ fontSize: '10px', fontWeight: 500, color: c.text }}>{doc.type}</span>
                    </div>
                    <div style={{ flex: 1 }}>
                      <p style={{ fontSize: '12px', fontWeight: 500, margin: 0 }}>{doc.name}</p>
                      <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)', margin: 0, display: 'flex', alignItems: 'center', gap: '3px' }}>
                        <Clock size={10} /> {doc.updated}
                      </p>
                    </div>
                    <button style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '5px 10px', background: 'var(--color-background-secondary,#f8f7f4)', color: 'var(--color-text-secondary)', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '7px', cursor: 'pointer', fontSize: '11px' }}>
                      <Eye size={11} /> View
                    </button>
                  </div>
                );
              })}
              {!isCurrentUser && isInvestor && (
                <div style={{ marginTop: '12px', paddingTop: '12px', borderTop: '0.5px solid rgba(0,0,0,0.07)' }}>
                  <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: '0 0 12px', lineHeight: 1.5 }}>
                    Request access to detailed documents by sending a collaboration request.
                  </p>
                  <button
                    onClick={handleSendRequest}
                    disabled={hasRequestedCollaboration}
                    style={{ width: '100%', padding: '9px', background: hasRequestedCollaboration ? '#EAF3DE' : '#1D9E75', color: hasRequestedCollaboration ? '#0F6E56' : '#fff', border: hasRequestedCollaboration ? '0.5px solid #C0DD97' : 'none', borderRadius: '9px', cursor: hasRequestedCollaboration ? 'default' : 'pointer', fontSize: '13px', fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}
                  >
                    {hasRequestedCollaboration ? <><CheckCircle size={13} /> Request Sent</> : <><Send size={13} /> Request Collaboration</>}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};