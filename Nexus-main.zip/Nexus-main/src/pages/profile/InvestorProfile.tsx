import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { MessageCircle, Building2, MapPin, UserCircle, BarChart3, Briefcase, ArrowLeft, TrendingUp, Target } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { findUserById } from '../../data/users';
import { Investor } from '../../types';

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75', mid: '#C0DD97' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD', mid: '#AFA9EC' },
  amber:   { bg: '#FAEEDA', text: '#854F0B', fill: '#BA7517', mid: '#FAC775' },
  coral:   { bg: '#FAECE7', text: '#993C1D', fill: '#D85A30', mid: '#F5C4B3' },
};

const baseCard: React.CSSProperties = {
  background: 'var(--color-background-primary,#fff)',
  border: '0.5px solid rgba(0,0,0,0.08)',
  borderRadius: '14px',
  overflow: 'hidden',
};

const panelHead: React.CSSProperties = {
  padding: '16px 24px',
  borderBottom: '0.5px solid rgba(0,0,0,0.07)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
};

const avatarColors = [T.emerald, T.violet, T.amber, T.coral];
const getAv = (idx: number) => avatarColors[idx % avatarColors.length];

const investmentCriteria = [
  'Strong founding team with domain expertise',
  'Clear market opportunity and product-market fit',
  'Scalable business model with strong unit economics',
  'Potential for significant growth and market impact',
];

const focusAreas = [
  { label: 'SaaS & B2B', pct: 75 },
  { label: 'FinTech', pct: 60 },
  { label: 'HealthTech', pct: 40 },
];

const stats = [
  { label: 'Successful exits', value: '4', color: 'emerald' as const, icon: <TrendingUp size={16} /> },
  { label: 'Average ROI', value: '3.2x', color: 'violet' as const, icon: <BarChart3 size={16} /> },
];

export const InvestorProfile: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user: currentUser } = useAuth();

  const investor = findUserById(id || '') as Investor | null;

  if (!investor || investor.role !== 'investor') {
    return (
      <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', padding: '60px', textAlign: 'center' }}>
        <div style={{ width: '52px', height: '52px', borderRadius: '14px', background: '#FAECE7', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
          <UserCircle size={26} color="#D85A30" />
        </div>
        <h2 style={{ fontSize: '18px', fontWeight: 500, margin: '0 0 6px' }}>Investor not found</h2>
        <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: '0 0 20px' }}>This profile doesn't exist or has been removed.</p>
        <Link to="/dashboard/entrepreneur" style={{ textDecoration: 'none' }}>
          <button style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '9px 18px', background: 'var(--color-background-primary,#fff)', color: 'var(--color-text-secondary)', border: '0.5px solid rgba(0,0,0,0.12)', borderRadius: '10px', cursor: 'pointer', fontSize: '13px' }}>
            <ArrowLeft size={14} /> Back to dashboard
          </button>
        </Link>
      </div>
    );
  }

  const isCurrentUser = currentUser?.id === investor.id;
  const initials = investor.name.split(' ').map((w: string) => w[0]).join('').slice(0, 2).toUpperCase();
  const av = getAv(0);

  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '32px' }}>

      {/* Back */}
      <div style={{ marginBottom: '20px' }}>
        <Link to="/dashboard/entrepreneur" style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', fontSize: '13px', color: 'var(--color-text-secondary)', textDecoration: 'none' }}>
          <ArrowLeft size={13} /> Back
        </Link>
      </div>

      {/* Hero card */}
      <div style={{ ...baseCard, marginBottom: '20px' }}>
        <div style={{ height: '3px', background: `linear-gradient(90deg, ${T.violet.fill}, ${T.amber.fill})` }} />
        <div style={{ padding: '28px 28px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: '18px' }}>
            <div style={{ position: 'relative', flexShrink: 0 }}>
              <div style={{ width: '68px', height: '68px', borderRadius: '16px', background: av.bg, color: av.text, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '22px', fontWeight: 500 }}>
                {initials}
              </div>
              {investor.isOnline && (
                <span style={{ position: 'absolute', bottom: '2px', right: '2px', width: '12px', height: '12px', borderRadius: '50%', background: '#1D9E75', border: '2px solid var(--color-background-primary,#fff)' }} />
              )}
            </div>
            <div>
              <h1 style={{ fontSize: '20px', fontWeight: 500, margin: '0 0 4px', letterSpacing: '-0.01em' }}>{investor.name}</h1>
              <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: '0 0 10px', display: 'flex', alignItems: 'center', gap: '5px' }}>
                <Building2 size={13} /> Investor · {investor.totalInvestments} investments
              </p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', padding: '4px 10px', borderRadius: '20px', fontSize: '11px', fontWeight: 500, background: T.violet.bg, color: T.violet.text }}>
                  <MapPin size={11} /> San Francisco, CA
                </span>
                {investor.investmentStage.map((stage: string, i: number) => (
                  <span key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', padding: '4px 10px', borderRadius: '20px', fontSize: '11px', fontWeight: 500, background: T.amber.bg, color: T.amber.text }}>
                    {stage}
                  </span>
                ))}
              </div>
            </div>
          </div>
          {!isCurrentUser && (
            <Link to={`/chat/${investor.id}`} style={{ textDecoration: 'none' }}>
              <button style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '9px 18px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '10px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>
                <MessageCircle size={14} /> Message
              </button>
            </Link>
          )}
          {isCurrentUser && (
            <button style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '9px 16px', background: 'var(--color-background-primary,#fff)', color: 'var(--color-text-secondary)', border: '0.5px solid rgba(0,0,0,0.12)', borderRadius: '10px', cursor: 'pointer', fontSize: '13px' }}>
              <UserCircle size={14} /> Edit profile
            </button>
          )}
        </div>
      </div>

      {/* Body */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: '16px', alignItems: 'start' }}>

        {/* Main */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>

          {/* About */}
          <div style={baseCard}>
            <div style={panelHead}><div style={{ fontSize: '14px', fontWeight: 500 }}>About</div></div>
            <div style={{ padding: '20px 24px' }}>
              <p style={{ fontSize: '13px', lineHeight: 1.7, color: 'var(--color-text-secondary)', margin: 0 }}>{investor.bio}</p>
            </div>
          </div>

          {/* Investment interests */}
          <div style={baseCard}>
            <div style={panelHead}><div style={{ fontSize: '14px', fontWeight: 500 }}>Investment interests</div></div>
            <div style={{ padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div>
                <div style={{ fontSize: '12px', fontWeight: 500, color: 'var(--color-text-secondary)', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Industries</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                  {investor.investmentInterests.map((interest: string, i: number) => (
                    <span key={i} style={{ padding: '5px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: 500, background: T.emerald.bg, color: T.emerald.text }}>{interest}</span>
                  ))}
                </div>
              </div>
              <div>
                <div style={{ fontSize: '12px', fontWeight: 500, color: 'var(--color-text-secondary)', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Investment stages</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                  {investor.investmentStage.map((stage: string, i: number) => (
                    <span key={i} style={{ padding: '5px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: 500, background: T.violet.bg, color: T.violet.text }}>{stage}</span>
                  ))}
                </div>
              </div>
              <div>
                <div style={{ fontSize: '12px', fontWeight: 500, color: 'var(--color-text-secondary)', marginBottom: '10px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Investment criteria</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {investmentCriteria.map((c, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: '8px' }}>
                      <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#1D9E75', flexShrink: 0, marginTop: '6px' }} />
                      <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0, lineHeight: 1.6 }}>{c}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Portfolio */}
          <div style={baseCard}>
            <div style={{ ...panelHead }}>
              <div style={{ fontSize: '14px', fontWeight: 500 }}>Portfolio companies</div>
              <span style={{ fontSize: '11px', fontWeight: 500, padding: '3px 10px', borderRadius: '20px', background: '#EAF3DE', color: '#0F6E56' }}>{investor.portfolioCompanies.length} companies</span>
            </div>
            <div style={{ padding: '16px 24px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(180px,1fr))', gap: '10px' }}>
                {investor.portfolioCompanies.map((company: string, i: number) => {
                  const c = getAv(i);
                  return (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '12px 14px', border: '0.5px solid rgba(0,0,0,0.08)', borderRadius: '10px' }}>
                      <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: c.bg, color: c.text, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <Briefcase size={14} color={c.text} />
                      </div>
                      <div>
                        <p style={{ fontSize: '12px', fontWeight: 500, margin: 0 }}>{company}</p>
                        <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)', margin: 0 }}>Invested 2022</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>

          {/* Investment details */}
          <div style={baseCard}>
            <div style={{ height: '2px', background: T.violet.fill }} />
            <div style={panelHead}><div style={{ fontSize: '14px', fontWeight: 500 }}>Investment details</div></div>
            <div style={{ padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div>
                <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginBottom: '3px', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 500 }}>Investment range</div>
                <div style={{ fontSize: '18px', fontWeight: 500 }}>{investor.minimumInvestment} – {investor.maximumInvestment}</div>
              </div>
              {[
                { label: 'Total investments', value: `${investor.totalInvestments} companies` },
                { label: 'Typical timeline', value: '3–5 years' },
              ].map((item, i) => (
                <div key={i}>
                  <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginBottom: '3px', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 500 }}>{item.label}</div>
                  <div style={{ fontSize: '13px', fontWeight: 500 }}>{item.value}</div>
                </div>
              ))}
              {/* Focus areas */}
              <div style={{ borderTop: '0.5px solid rgba(0,0,0,0.07)', paddingTop: '12px' }}>
                <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginBottom: '10px', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 500 }}>Investment focus</div>
                {focusAreas.map((f, i) => (
                  <div key={i} style={{ marginBottom: '8px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                      <span style={{ fontSize: '12px', fontWeight: 500 }}>{f.label}</span>
                      <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>{f.pct}%</span>
                    </div>
                    <div style={{ height: '5px', background: 'var(--color-background-secondary,#f0efec)', borderRadius: '3px', overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: `${f.pct}%`, background: T.violet.fill, borderRadius: '3px' }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Stats */}
          <div style={baseCard}>
            <div style={panelHead}><div style={{ fontSize: '14px', fontWeight: 500 }}>Investment stats</div></div>
            <div style={{ padding: '14px 20px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {stats.map((s, i) => {
                const c = T[s.color];
                return (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 14px', background: c.bg, borderRadius: '10px', border: `0.5px solid ${c.mid}` }}>
                    <div>
                      <p style={{ fontSize: '11px', color: c.text, margin: '0 0 3px', fontWeight: 500 }}>{s.label}</p>
                      <p style={{ fontSize: '20px', fontWeight: 500, color: c.text, margin: 0, letterSpacing: '-0.02em' }}>{s.value}</p>
                    </div>
                    <div style={{ color: c.fill }}>{s.icon}</div>
                  </div>
                );
              })}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 14px', background: T.amber.bg, borderRadius: '10px', border: `0.5px solid ${T.amber.mid}` }}>
                <div>
                  <p style={{ fontSize: '11px', color: T.amber.text, margin: '0 0 3px', fontWeight: 500 }}>Active investments</p>
                  <p style={{ fontSize: '20px', fontWeight: 500, color: T.amber.text, margin: 0, letterSpacing: '-0.02em' }}>{investor.portfolioCompanies.length}</p>
                </div>
                <Target size={16} color={T.amber.fill} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};