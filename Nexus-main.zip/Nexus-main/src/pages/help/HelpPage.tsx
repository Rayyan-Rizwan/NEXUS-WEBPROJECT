import React, { useState } from 'react';
import { Search, Book, MessageCircle, Phone, Mail, ExternalLink, ChevronDown, ChevronUp, CheckCircle, Headphones } from 'lucide-react';

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75', mid: '#C0DD97' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD', mid: '#AFA9EC' },
  amber:   { bg: '#FAEEDA', text: '#854F0B', fill: '#BA7517', mid: '#FAC775' },
  coral:   { bg: '#FAECE7', text: '#993C1D', fill: '#D85A30', mid: '#F5C4B3' },
};

const baseCard: React.CSSProperties = { background: 'var(--color-background-primary,#fff)', border: '0.5px solid rgba(0,0,0,0.08)', borderRadius: '14px', overflow: 'hidden' };

const faqs = [
  { q: 'How do I connect with investors?', a: 'Browse our investor directory and send connection requests. Once an investor accepts, you can message them directly and schedule video calls through the platform.' },
  { q: 'What should I include in my startup profile?', a: 'Your profile should include a compelling pitch, funding needs, team information, market opportunity, and any traction or metrics that demonstrate your progress.' },
  { q: 'How do I share documents securely?', a: 'Upload documents to your secure vault and selectively share them with connected investors. All documents are encrypted and access-controlled at the file level.' },
  { q: 'What are collaboration requests?', a: 'Collaboration requests are formal expressions of interest from investors. They indicate an investor wants to learn more about your startup and potentially discuss investment opportunities.' },
  { q: 'How does the meeting scheduler work?', a: 'Set your availability in the Calendar tab, then send meeting requests to connected investors. They can accept or decline, and confirmed meetings appear on your dashboard.' },
  { q: 'Can I do video calls directly on Nexus?', a: 'Yes — navigate to Video Calls to start an instant call or join a scheduled one. You can toggle audio/video, share your screen, and use the built-in chat.' },
];

const channels = [
  { icon: <Book size={20} />, title: 'Documentation', desc: 'Detailed guides and tutorials', action: 'Browse docs', color: 'violet' as const },
  { icon: <MessageCircle size={20} />, title: 'Live chat', desc: 'Talk to support in real time', action: 'Start chat', color: 'emerald' as const, primary: true },
  { icon: <Headphones size={20} />, title: 'Support call', desc: 'Schedule a call with our team', action: 'Book a call', color: 'amber' as const },
];

export const HelpPage: React.FC = () => {
  const [expanded, setExpanded] = useState<number | null>(0);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setForm({ name: '', email: '', subject: '', message: '' });
    setTimeout(() => setSubmitted(false), 4000);
  };

  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '9px 12px', border: '0.5px solid rgba(0,0,0,0.12)', borderRadius: '9px', fontSize: '13px', outline: 'none', background: 'var(--color-background-primary,#fff)', color: 'var(--color-text-primary)', boxSizing: 'border-box',
  };

  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '32px' }}>

      {/* Header */}
      <div style={{ marginBottom: '28px' }}>
        <h1 style={{ fontSize: '20px', fontWeight: 500, margin: '0 0 4px', letterSpacing: '-0.01em' }}>Help & support</h1>
        <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>Find answers or get in touch with our team</p>
      </div>

      {/* Search */}
      <div style={{ maxWidth: '520px', marginBottom: '28px', position: 'relative' }}>
        <Search size={15} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: 'var(--color-text-tertiary,#b0b0b0)' }} />
        <input
          placeholder="Search help articles, guides, and FAQs…"
          style={{ ...inputStyle, padding: '11px 14px 11px 40px', borderRadius: '11px', fontSize: '13px' }}
          onFocus={e => (e.currentTarget.style.borderColor = '#1D9E75')}
          onBlur={e => (e.currentTarget.style.borderColor = 'rgba(0,0,0,0.12)')}
        />
      </div>

      {/* Support channels */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '14px', marginBottom: '24px' }}>
        {channels.map((ch, i) => {
          const c = T[ch.color];
          return (
            <div key={i} style={{ ...baseCard }}>
              <div style={{ height: '2px', background: c.fill }} />
              <div style={{ padding: '20px 22px' }}>
                <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: c.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', color: c.text, marginBottom: '12px' }}>
                  {ch.icon}
                </div>
                <h3 style={{ fontSize: '14px', fontWeight: 500, margin: '0 0 4px' }}>{ch.title}</h3>
                <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: '0 0 16px', lineHeight: 1.5 }}>{ch.desc}</p>
                <button style={{ display: 'flex', alignItems: 'center', gap: '5px', padding: '8px 14px', borderRadius: '8px', border: `0.5px solid ${ch.primary ? c.fill : 'rgba(0,0,0,0.12)'}`, background: ch.primary ? c.fill : 'transparent', color: ch.primary ? '#fff' : c.text, cursor: 'pointer', fontSize: '12px', fontWeight: 500 }}>
                  {ch.action} {!ch.primary && <ExternalLink size={11} />}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom grid: FAQs + form */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: '16px', alignItems: 'start' }}>

        {/* FAQs */}
        <div style={baseCard}>
          <div style={{ padding: '16px 24px', borderBottom: '0.5px solid rgba(0,0,0,0.07)' }}>
            <div style={{ fontSize: '14px', fontWeight: 500 }}>Frequently asked questions</div>
            <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>Answers to the most common questions</div>
          </div>
          {faqs.map((faq, idx) => (
            <div key={idx} style={{ borderTop: idx > 0 ? '0.5px solid rgba(0,0,0,0.06)' : 'none' }}>
              <button
                onClick={() => setExpanded(expanded === idx ? null : idx)}
                style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '15px 24px', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left', gap: '12px' }}>
                <span style={{ fontSize: '13px', fontWeight: 500, flex: 1 }}>{faq.q}</span>
                {expanded === idx
                  ? <ChevronUp size={15} color="var(--color-text-tertiary,#b0b0b0)" style={{ flexShrink: 0 }} />
                  : <ChevronDown size={15} color="var(--color-text-tertiary,#b0b0b0)" style={{ flexShrink: 0 }} />}
              </button>
              {expanded === idx && (
                <div style={{ padding: '0 24px 16px', fontSize: '13px', color: 'var(--color-text-secondary)', lineHeight: 1.7, borderLeft: '2px solid #1D9E75', marginLeft: '24px', paddingLeft: '16px' }}>
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Contact form */}
        <div style={baseCard}>
          <div style={{ padding: '16px 22px', borderBottom: '0.5px solid rgba(0,0,0,0.07)' }}>
            <div style={{ fontSize: '14px', fontWeight: 500 }}>Still need help?</div>
            <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>We respond within 24 hours</div>
          </div>
          <div style={{ padding: '20px 22px' }}>
            {submitted && (
              <div style={{ background: '#EAF3DE', border: '0.5px solid #C0DD97', borderRadius: '10px', padding: '10px 14px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <CheckCircle size={15} color="#1D9E75" />
                <p style={{ margin: 0, fontSize: '13px', color: '#0F6E56', fontWeight: 500 }}>Message sent! We'll reply soon.</p>
              </div>
            )}
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                {[{ k: 'name', label: 'Name', type: 'text', ph: 'Your name' }, { k: 'email', label: 'Email', type: 'email', ph: 'you@company.com' }].map(f => (
                  <div key={f.k}>
                    <label style={{ display: 'block', fontSize: '11px', fontWeight: 500, color: 'var(--color-text-secondary)', marginBottom: '5px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{f.label}</label>
                    <input type={f.type} placeholder={f.ph} required value={(form as any)[f.k]} onChange={e => setForm(p => ({ ...p, [f.k]: e.target.value }))} style={inputStyle}
                      onFocus={e => (e.currentTarget.style.borderColor = '#1D9E75')}
                      onBlur={e => (e.currentTarget.style.borderColor = 'rgba(0,0,0,0.12)')} />
                  </div>
                ))}
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '11px', fontWeight: 500, color: 'var(--color-text-secondary)', marginBottom: '5px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Subject</label>
                <input type="text" placeholder="What can we help with?" value={form.subject} onChange={e => setForm(p => ({ ...p, subject: e.target.value }))} style={inputStyle}
                  onFocus={e => (e.currentTarget.style.borderColor = '#1D9E75')}
                  onBlur={e => (e.currentTarget.style.borderColor = 'rgba(0,0,0,0.12)')} />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '11px', fontWeight: 500, color: 'var(--color-text-secondary)', marginBottom: '5px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Message</label>
                <textarea rows={4} placeholder="Describe your issue in detail…" required value={form.message} onChange={e => setForm(p => ({ ...p, message: e.target.value }))} style={{ ...inputStyle, resize: 'vertical', fontFamily: 'inherit', lineHeight: 1.6 }}
                  onFocus={e => (e.currentTarget.style.borderColor = '#1D9E75')}
                  onBlur={e => (e.currentTarget.style.borderColor = 'rgba(0,0,0,0.12)')} />
              </div>
              <button type="submit" style={{ padding: '10px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '10px', cursor: 'pointer', fontSize: '13px', fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}
                onMouseEnter={e => (e.currentTarget.style.background = '#0F6E56')}
                onMouseLeave={e => (e.currentTarget.style.background = '#1D9E75')}>
                <Mail size={14} /> Send message
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};