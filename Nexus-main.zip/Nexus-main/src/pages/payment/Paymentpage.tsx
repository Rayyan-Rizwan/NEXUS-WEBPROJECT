import React, { useState } from 'react';
import {
  ArrowUpRight, ArrowDownLeft, RefreshCw, DollarSign, TrendingUp,
  TrendingDown, Clock, CheckCircle, AlertCircle, X, CreditCard,
  Building2, Send, Shield, Eye, EyeOff, ChevronRight, Zap, Plus
} from 'lucide-react';

type TxStatus = 'completed' | 'pending' | 'failed';
type TxType = 'deposit' | 'withdrawal' | 'transfer';
type ActionType = 'deposit' | 'withdraw' | 'transfer' | null;

interface Transaction {
  id: string;
  type: TxType;
  amount: number;
  sender: string;
  receiver: string;
  status: TxStatus;
  date: string;
  note: string;
}

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75', mid: '#C0DD97' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD', mid: '#AFA9EC' },
  amber:   { bg: '#FAEEDA', text: '#854F0B', fill: '#BA7517', mid: '#FAC775' },
  coral:   { bg: '#FAECE7', text: '#993C1D', fill: '#D85A30', mid: '#F5C4B3' },
};

const INITIAL_TXS: Transaction[] = [
  { id: 't1', type: 'deposit',    amount: 500000,  sender: 'Sarah Chen',    receiver: 'Wallet',       status: 'completed', date: '2026-03-10', note: 'Series A tranche 1' },
  { id: 't2', type: 'transfer',   amount: 250000,  sender: 'Michael Torres',receiver: 'TechWave AI',  status: 'completed', date: '2026-03-08', note: 'Seed investment' },
  { id: 't3', type: 'withdrawal', amount: 75000,   sender: 'Wallet',        receiver: 'Bank Account', status: 'completed', date: '2026-03-06', note: 'Operating expenses' },
  { id: 't4', type: 'deposit',    amount: 150000,  sender: 'Priya Nair',    receiver: 'Wallet',       status: 'pending',   date: '2026-03-12', note: 'Due diligence cleared' },
  { id: 't5', type: 'transfer',   amount: 30000,   sender: 'Wallet',        receiver: 'GreenLife',    status: 'failed',    date: '2026-03-11', note: 'Term sheet advance' },
  { id: 't6', type: 'deposit',    amount: 1000000, sender: 'David Lim',     receiver: 'Wallet',       status: 'completed', date: '2026-03-01', note: 'Lead investor - Series A' },
  { id: 't7', type: 'withdrawal', amount: 45000,   sender: 'Wallet',        receiver: 'Bank Account', status: 'pending',   date: '2026-03-13', note: 'Quarterly distribution' },
];

const statusConf: Record<TxStatus, { label: string; color: keyof typeof T; icon: React.ReactNode }> = {
  completed: { label: 'Completed', color: 'emerald', icon: <CheckCircle size={12}/> },
  pending:   { label: 'Pending',   color: 'amber',   icon: <Clock size={12}/> },
  failed:    { label: 'Failed',    color: 'coral',   icon: <AlertCircle size={12}/> },
};

const fmt = (n: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);
const fmtShort = (n: number) => n >= 1000000 ? `$${(n/1000000).toFixed(1)}M` : n >= 1000 ? `$${(n/1000).toFixed(0)}K` : `$${n}`;

const baseCard: React.CSSProperties = {
  background: 'var(--color-background-primary,#fff)',
  border: '0.5px solid rgba(0,0,0,0.08)',
  borderRadius: '14px',
  overflow: 'hidden',
};

export const PaymentPage: React.FC = () => {
  const [txs, setTxs] = useState<Transaction[]>(INITIAL_TXS);
  const [balance, setBalance] = useState(1530000);
  const [activeAction, setActiveAction] = useState<ActionType>(null);
  const [showBalance, setShowBalance] = useState(true);
  const [form, setForm] = useState({ amount: '', recipient: '', note: '' });
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [filterStatus, setFilterStatus] = useState<TxStatus | 'all'>('all');

  const filtered = filterStatus === 'all' ? txs : txs.filter(t => t.status === filterStatus);

  const handleAction = () => {
    const amt = parseFloat(form.amount.replace(/,/g, ''));
    if (!amt || amt <= 0) return;
    setProcessing(true);
    setTimeout(() => {
      const newTx: Transaction = {
        id: 't' + Date.now(),
        type: activeAction as TxType,
        amount: amt,
        sender: activeAction === 'deposit' ? (form.recipient || 'External') : 'Wallet',
        receiver: activeAction === 'withdrawal' ? 'Bank Account' : activeAction === 'transfer' ? (form.recipient || 'Recipient') : 'Wallet',
        status: 'completed',
        date: new Date().toISOString().split('T')[0],
        note: form.note || `${activeAction} transaction`,
      };
      setTxs(p => [newTx, ...p]);
      if (activeAction === 'deposit') setBalance(p => p + amt);
      if (activeAction === 'withdrawal' || activeAction === 'transfer') setBalance(p => p - amt);
      setProcessing(false);
      setSuccess(true);
      setTimeout(() => { setSuccess(false); setActiveAction(null); setForm({ amount: '', recipient: '', note: '' }); }, 2000);
    }, 1400);
  };

  const totalIn  = txs.filter(t=>t.type==='deposit'   &&t.status==='completed').reduce((a,t)=>a+t.amount,0);
  const totalOut = txs.filter(t=>t.type!=='deposit'    &&t.status==='completed').reduce((a,t)=>a+t.amount,0);
  const pendingAmt = txs.filter(t=>t.status==='pending').reduce((a,t)=>a+t.amount,0);

  const inputStyle: React.CSSProperties = { width: '100%', padding: '9px 12px', border: '0.5px solid rgba(0,0,0,0.12)', borderRadius: '9px', fontSize: '13px', outline: 'none', background: 'var(--color-background-primary,#fff)', color: 'var(--color-text-primary)', boxSizing: 'border-box' };

  const actionConf = {
    deposit:    { label: 'Deposit funds',   icon: <ArrowDownLeft size={15}/>,  color: 'emerald' as const, desc: 'Receive investment or add funds to your wallet' },
    withdraw:   { label: 'Withdraw funds',  icon: <ArrowUpRight size={15}/>,   color: 'coral' as const,   desc: 'Transfer funds to your bank account' },
    transfer:   { label: 'Transfer funds',  icon: <Send size={15}/>,            color: 'violet' as const,  desc: 'Send funds to an entrepreneur or deal' },
  };

  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '32px' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '28px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '4px' }}>
            <div style={{ width: '28px', height: '28px', borderRadius: '7px', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <CreditCard size={14} color="#1D9E75"/>
            </div>
            <h1 style={{ fontSize: '20px', fontWeight: 500, margin: 0, letterSpacing: '-0.01em' }}>Payments</h1>
          </div>
          <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0, paddingLeft: '38px' }}>Investment flows · Wallet balance · Transaction history</p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '6px 12px', background: '#EAF3DE', border: '0.5px solid #C0DD97', borderRadius: '20px' }}>
          <Shield size={12} color="#1D9E75"/>
          <span style={{ fontSize: '11px', fontWeight: 500, color: '#0F6E56' }}>Simulation mode</span>
        </div>
      </div>

      {/* Wallet card */}
      <div style={{ ...baseCard, marginBottom: '24px', background: '#1A1A1A', color: '#fff' }}>
        <div style={{ padding: '28px 28px 24px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '24px' }}>
            <div>
              <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.4)', margin: '0 0 8px', letterSpacing: '0.06em', textTransform: 'uppercase', fontWeight: 500 }}>Wallet balance</p>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                {showBalance
                  ? <h2 style={{ fontSize: '36px', fontWeight: 500, margin: 0, letterSpacing: '-0.02em' }}>{fmt(balance)}</h2>
                  : <h2 style={{ fontSize: '36px', fontWeight: 500, margin: 0 }}>••••••••</h2>
                }
                <button onClick={() => setShowBalance(p=>!p)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.4)', display: 'flex', alignItems: 'center' }}>
                  {showBalance ? <EyeOff size={16}/> : <Eye size={16}/>}
                </button>
              </div>
              <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.35)', margin: '6px 0 0' }}>Available for investment</p>
            </div>
            <div style={{ width: '44px', height: '44px', borderRadius: '12px', background: 'rgba(29,158,117,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <CreditCard size={20} color="#5DCAA5"/>
            </div>
          </div>
          {/* Quick stats */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' }}>
            {[
              { label: 'Total in',  value: fmtShort(totalIn),    icon: <TrendingUp size={13}/>,  color: '#5DCAA5' },
              { label: 'Total out', value: fmtShort(totalOut),   icon: <TrendingDown size={13}/>,color: '#F5C4B3' },
              { label: 'Pending',   value: fmtShort(pendingAmt), icon: <Clock size={13}/>,       color: '#FAC775' },
            ].map((s,i) => (
              <div key={i} style={{ padding: '12px 14px', background: 'rgba(255,255,255,0.06)', borderRadius: '10px', border: '0.5px solid rgba(255,255,255,0.08)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '5px', color: s.color, marginBottom: '5px' }}>
                  {s.icon}
                  <span style={{ fontSize: '10px', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{s.label}</span>
                </div>
                <p style={{ fontSize: '16px', fontWeight: 500, margin: 0, color: '#fff' }}>{s.value}</p>
              </div>
            ))}
          </div>
        </div>
        {/* Action buttons */}
        <div style={{ padding: '16px 28px', borderTop: '0.5px solid rgba(255,255,255,0.08)', display: 'flex', gap: '10px' }}>
          {(['deposit','withdraw','transfer'] as const).map(a => {
            const ac = actionConf[a];
            const c = T[ac.color];
            return (
              <button key={a} onClick={() => setActiveAction(a)}
                style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '9px', borderRadius: '9px', border: `0.5px solid ${c.mid}`, background: c.bg, color: c.text, cursor: 'pointer', fontSize: '12px', fontWeight: 500, transition: 'all 0.15s' }}>
                {ac.icon} {a.charAt(0).toUpperCase()+a.slice(1)}
              </button>
            );
          })}
        </div>
      </div>

      {/* Action form modal */}
      {activeAction && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 50 }}>
          <div style={{ background: 'var(--color-background-primary,#fff)', borderRadius: '16px', width: '400px', overflow: 'hidden', border: '0.5px solid rgba(0,0,0,0.08)' }}>
            {success ? (
              <div style={{ padding: '48px 28px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '14px' }}>
                <div style={{ width: '56px', height: '56px', borderRadius: '50%', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <CheckCircle size={28} color="#1D9E75"/>
                </div>
                <p style={{ fontSize: '16px', fontWeight: 500, margin: 0 }}>Transaction complete</p>
                <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>{fmt(parseFloat(form.amount.replace(/,/g,''))||0)} {activeAction === 'deposit' ? 'added to' : 'removed from'} wallet</p>
              </div>
            ) : (
              <>
                <div style={{ height: '3px', background: T[actionConf[activeAction].color].fill }} />
                <div style={{ padding: '20px 24px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                    <h3 style={{ fontSize: '15px', fontWeight: 500, margin: 0 }}>{actionConf[activeAction].label}</h3>
                    <button onClick={() => setActiveAction(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--color-text-secondary)' }}><X size={16}/></button>
                  </div>
                  <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: '0 0 20px' }}>{actionConf[activeAction].desc}</p>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                    <div>
                      <label style={{ display: 'block', fontSize: '11px', fontWeight: 500, color: 'var(--color-text-secondary)', marginBottom: '5px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Amount (USD)</label>
                      <div style={{ position: 'relative' }}>
                        <span style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--color-text-secondary)', fontSize: '13px' }}>$</span>
                        <input type="number" placeholder="0.00" value={form.amount} onChange={e=>setForm(p=>({...p,amount:e.target.value}))} style={{ ...inputStyle, paddingLeft: '24px' }}
                          onFocus={e=>(e.currentTarget.style.borderColor='#1D9E75')}
                          onBlur={e=>(e.currentTarget.style.borderColor='rgba(0,0,0,0.12)')}/>
                      </div>
                    </div>
                    {activeAction !== 'deposit' && (
                      <div>
                        <label style={{ display: 'block', fontSize: '11px', fontWeight: 500, color: 'var(--color-text-secondary)', marginBottom: '5px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                          {activeAction === 'transfer' ? 'Recipient' : 'Bank account'}
                        </label>
                        <input type="text" placeholder={activeAction === 'transfer' ? 'Entrepreneur or deal name' : '****1234'} value={form.recipient} onChange={e=>setForm(p=>({...p,recipient:e.target.value}))} style={inputStyle}
                          onFocus={e=>(e.currentTarget.style.borderColor='#1D9E75')}
                          onBlur={e=>(e.currentTarget.style.borderColor='rgba(0,0,0,0.12)')}/>
                      </div>
                    )}
                    {activeAction === 'deposit' && (
                      <div>
                        <label style={{ display: 'block', fontSize: '11px', fontWeight: 500, color: 'var(--color-text-secondary)', marginBottom: '5px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Sender / Investor</label>
                        <input type="text" placeholder="Investor name" value={form.recipient} onChange={e=>setForm(p=>({...p,recipient:e.target.value}))} style={inputStyle}
                          onFocus={e=>(e.currentTarget.style.borderColor='#1D9E75')}
                          onBlur={e=>(e.currentTarget.style.borderColor='rgba(0,0,0,0.12)')}/>
                      </div>
                    )}
                    <div>
                      <label style={{ display: 'block', fontSize: '11px', fontWeight: 500, color: 'var(--color-text-secondary)', marginBottom: '5px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Note (optional)</label>
                      <input type="text" placeholder="Transaction note" value={form.note} onChange={e=>setForm(p=>({...p,note:e.target.value}))} style={inputStyle}
                        onFocus={e=>(e.currentTarget.style.borderColor='#1D9E75')}
                        onBlur={e=>(e.currentTarget.style.borderColor='rgba(0,0,0,0.12)')}/>
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: '8px', marginTop: '20px' }}>
                    <button onClick={() => setActiveAction(null)} style={{ flex: 1, padding: '10px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '9px', background: 'none', cursor: 'pointer', fontSize: '13px', color: 'var(--color-text-secondary)' }}>Cancel</button>
                    <button onClick={handleAction} disabled={!form.amount || processing}
                      style={{ flex: 2, padding: '10px', background: !form.amount || processing ? 'rgba(0,0,0,0.06)' : T[actionConf[activeAction].color].fill, color: !form.amount || processing ? 'var(--color-text-tertiary,#b0b0b0)' : '#fff', border: 'none', borderRadius: '9px', cursor: !form.amount || processing ? 'default' : 'pointer', fontSize: '13px', fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                      {processing ? (
                        <><div style={{ width: '14px', height: '14px', borderRadius: '50%', border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff', animation: 'spin 0.8s linear infinite' }}/> Processing…</>
                      ) : <>{actionConf[activeAction].icon} Confirm {activeAction}</>}
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Stats row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '14px', marginBottom: '24px' }}>
        {[
          { label: 'Total transactions', value: txs.length,                                icon: <RefreshCw size={15}/>,    color: 'violet' as const },
          { label: 'Completed',          value: txs.filter(t=>t.status==='completed').length, icon: <CheckCircle size={15}/>, color: 'emerald' as const },
          { label: 'Pending',            value: txs.filter(t=>t.status==='pending').length,   icon: <Clock size={15}/>,       color: 'amber' as const },
          { label: 'Failed',             value: txs.filter(t=>t.status==='failed').length,    icon: <AlertCircle size={15}/>, color: 'coral' as const },
        ].map((s,i) => {
          const c = T[s.color];
          return (
            <div key={i} style={baseCard}>
              <div style={{ height: '2px', background: c.fill }}/>
              <div style={{ padding: '16px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontSize: '24px', fontWeight: 500, letterSpacing: '-0.02em', lineHeight: 1 }}>{s.value}</div>
                  <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginTop: '5px' }}>{s.label}</div>
                </div>
                <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: c.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', color: c.text }}>{s.icon}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Transaction history */}
      <div style={baseCard}>
        <div style={{ padding: '14px 20px', borderBottom: '0.5px solid rgba(0,0,0,0.07)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '10px' }}>
          <div>
            <div style={{ fontSize: '14px', fontWeight: 500 }}>Transaction history</div>
            <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>All investment flows and movements</div>
          </div>
          <div style={{ display: 'flex', gap: '6px' }}>
            {(['all','completed','pending','failed'] as const).map(f => {
              const active = filterStatus === f;
              return (
                <button key={f} onClick={()=>setFilterStatus(f)} style={{ padding: '5px 12px', borderRadius: '20px', border: '0.5px solid', cursor: 'pointer', fontSize: '11px', fontWeight: active?500:400, background: active?'#EAF3DE':'var(--color-background-primary,#fff)', color: active?'#0F6E56':'var(--color-text-secondary)', borderColor: active?'#1D9E75':'rgba(0,0,0,0.10)' }}>
                  {f.charAt(0).toUpperCase()+f.slice(1)}
                </button>
              );
            })}
          </div>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--color-background-secondary,#f8f7f4)' }}>
                {['Type','Amount','Sender','Receiver','Status','Date','Note'].map((h,i) => (
                  <th key={i} style={{ padding: '9px 16px', textAlign: 'left', fontSize: '10px', fontWeight: 500, color: 'var(--color-text-secondary)', letterSpacing: '0.05em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((tx,idx) => {
                const sc = statusConf[tx.status];
                const tc = T[sc.color];
                const typeColor = tx.type==='deposit' ? T.emerald : tx.type==='withdrawal' ? T.coral : T.violet;
                const typeIcon = tx.type==='deposit' ? <ArrowDownLeft size={12}/> : tx.type==='withdrawal' ? <ArrowUpRight size={12}/> : <Send size={12}/>;
                return (
                  <tr key={tx.id} style={{ borderTop: '0.5px solid rgba(0,0,0,0.05)' }}
                    onMouseEnter={e=>(e.currentTarget as HTMLElement).style.background='var(--color-background-secondary,#f8f7f4)'}
                    onMouseLeave={e=>(e.currentTarget as HTMLElement).style.background='transparent'}>
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', padding: '3px 9px', borderRadius: '20px', fontSize: '11px', fontWeight: 500, background: typeColor.bg, color: typeColor.text }}>
                        {typeIcon} {tx.type.charAt(0).toUpperCase()+tx.type.slice(1)}
                      </span>
                    </td>
                    <td style={{ padding: '12px 16px', fontSize: '13px', fontWeight: 500, color: tx.type==='deposit'?'#1D9E75':tx.type==='withdrawal'?'#D85A30':'var(--color-text-primary)' }}>
                      {tx.type==='deposit'?'+':'-'}{fmt(tx.amount)}
                    </td>
                    <td style={{ padding: '12px 16px', fontSize: '12px', color: 'var(--color-text-secondary)', whiteSpace: 'nowrap' }}>{tx.sender}</td>
                    <td style={{ padding: '12px 16px', fontSize: '12px', color: 'var(--color-text-secondary)', whiteSpace: 'nowrap' }}>{tx.receiver}</td>
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', padding: '3px 9px', borderRadius: '20px', fontSize: '11px', fontWeight: 500, background: tc.bg, color: tc.text }}>
                        {sc.icon} {sc.label}
                      </span>
                    </td>
                    <td style={{ padding: '12px 16px', fontSize: '12px', color: 'var(--color-text-secondary)', whiteSpace: 'nowrap' }}>
                      {new Date(tx.date).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}
                    </td>
                    <td style={{ padding: '12px 16px', fontSize: '12px', color: 'var(--color-text-secondary)', maxWidth: '160px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{tx.note}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
    </div>
  );
};