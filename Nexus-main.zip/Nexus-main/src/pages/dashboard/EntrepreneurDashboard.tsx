import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Users, Bell, Calendar, AlertCircle, PlusCircle, Video, ArrowRight, Clock, Eye, Zap, TrendingUp } from 'lucide-react';
import { CollaborationRequestCard } from '../../components/collaboration/CollaborationRequestCard';
import { InvestorCard } from '../../components/investor/InvestorCard';
import { useAuth } from '../../context/AuthContext';
import { CollaborationRequest } from '../../types';
import { getRequestsForEntrepreneur } from '../../data/collaborationRequests';
import { investors } from '../../data/users';

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75', mid: '#C0DD97' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD', mid: '#AFA9EC' },
  amber:   { bg: '#FAEEDA', text: '#854F0B', fill: '#BA7517', mid: '#FAC775' },
  coral:   { bg: '#FAECE7', text: '#993C1D', fill: '#D85A30', mid: '#F5C4B3' },
};

const baseCard: React.CSSProperties = {
  background: 'var(--color-background-primary,#fff)',
  border: '0.5px solid rgba(0,0,0,0.08)',
  borderRadius: '14px',
  overflow: 'hidden',
};

const headStyle: React.CSSProperties = {
  padding: '16px 24px',
  borderBottom: '0.5px solid rgba(0,0,0,0.07)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
};

export const EntrepreneurDashboard: React.FC = () => {
  const { user } = useAuth();
  const [collaborationRequests, setCollaborationRequests] = useState<CollaborationRequest[]>([]);
  const [recommendedInvestors] = useState(investors.slice(0, 3));

  useEffect(() => {
    if (user) setCollaborationRequests(getRequestsForEntrepreneur(user.id));
  }, [user]);

  const handleRequestStatusUpdate = (requestId: string, status: 'accepted' | 'rejected') => {
    setCollaborationRequests(prev => prev.map(r => r.id === requestId ? { ...r, status } : r));
  };

  if (!user) return null;
  const pendingRequests = collaborationRequests.filter(r => r.status === 'pending');

  const kpis = [
    { label: 'Pending requests', value: pendingRequests.length, icon: <Bell size={15} />, color: 'violet' as const, tag: 'Needs action' },
    { label: 'Active connections', value: collaborationRequests.filter(r => r.status === 'accepted').length, icon: <Users size={15} />, color: 'emerald' as const, tag: '+3 this week' },
    { label: 'Meetings scheduled', value: 2, icon: <Calendar size={15} />, color: 'amber' as const, tag: '1 today' },
    { label: 'Profile views', value: 24, icon: <Eye size={15} />, color: 'coral' as const, tag: '+12.5%' },
  ];

  const upcomingMeetings = [
    { id: '1', title: 'Pitch Review', with: 'Sarah Chen', firm: 'Sequoia', time: 'Today, 10:00 AM', avatar: 'SC', color: 'emerald' as const },
    { id: '2', title: 'Due Diligence', with: 'Michael Torres', firm: 'a16z', time: 'Mar 18, 2:00 PM', avatar: 'MT', color: 'violet' as const },
  ];

  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '32px' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '28px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '4px' }}>
            <div style={{ width: '28px', height: '28px', borderRadius: '7px', background: '#EAF3DE', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Zap size={14} color="#1D9E75" />
            </div>
            <h1 style={{ fontSize: '20px', fontWeight: 500, margin: 0, letterSpacing: '-0.01em' }}>Welcome back, {user.name}</h1>
          </div>
          <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0, paddingLeft: '38px' }}>Series A fundraise · March 2026</p>
        </div>
        <Link to="/investors" style={{ textDecoration: 'none' }}>
          <button style={{ display: 'flex', alignItems: 'center', gap: '7px', padding: '9px 18px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '10px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>
            <PlusCircle size={14} /> Find investors
          </button>
        </Link>
      </div>

      {/* KPI row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '14px', marginBottom: '24px' }}>
        {kpis.map((k, i) => {
          const c = T[k.color];
          return (
            <div key={i} style={{ ...baseCard }}>
              <div style={{ height: '2px', background: c.fill }} />
              <div style={{ padding: '18px 20px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
                  <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: c.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', color: c.text }}>{k.icon}</div>
                  <span style={{ fontSize: '10px', fontWeight: 500, padding: '2px 8px', borderRadius: '20px', background: c.bg, color: c.text }}>{k.tag}</span>
                </div>
                <div style={{ fontSize: '28px', fontWeight: 500, letterSpacing: '-0.02em', lineHeight: 1 }}>{k.value}</div>
                <div style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginTop: '6px' }}>{k.label}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Body grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: '16px', alignItems: 'start' }}>

        {/* Collaboration requests */}
        <div style={baseCard}>
          <div style={headStyle}>
            <div>
              <div style={{ fontSize: '14px', fontWeight: 500 }}>Collaboration requests</div>
              <div style={{ fontSize: '11px', color: 'var(--color-text-secondary)', marginTop: '2px' }}>Investor outreach requiring your response</div>
            </div>
            {pendingRequests.length > 0 && (
              <span style={{ fontSize: '10px', fontWeight: 500, padding: '3px 10px', borderRadius: '20px', background: '#EEEDFE', color: '#534AB7' }}>
                {pendingRequests.length} pending
              </span>
            )}
          </div>
          <div style={{ padding: '12px 24px' }}>
            {collaborationRequests.length > 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                {collaborationRequests.map(r => (
                  <CollaborationRequestCard key={r.id} request={r} onStatusUpdate={handleRequestStatusUpdate} />
                ))}
              </div>
            ) : (
              <div style={{ textAlign: 'center', padding: '48px 16px' }}>
                <div style={{ width: '44px', height: '44px', borderRadius: '50%', background: 'var(--color-background-secondary,#f5f4f0)', margin: '0 auto 14px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <AlertCircle size={20} color="var(--color-text-tertiary,#c0c0c0)" />
                </div>
                <p style={{ fontSize: '14px', fontWeight: 500, margin: '0 0 4px' }}>No requests yet</p>
                <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: 0 }}>Investor collaboration requests will appear here</p>
              </div>
            )}
          </div>
        </div>

        {/* Right sidebar */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>

          {/* Meetings */}
          <div style={baseCard}>
            <div style={headStyle}>
              <div style={{ fontSize: '14px', fontWeight: 500 }}>Upcoming meetings</div>
              <Link to="/meetings" style={{ fontSize: '12px', color: '#1D9E75', fontWeight: 500, textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '3px' }}>
                View all <ArrowRight size={11} />
              </Link>
            </div>
            <div style={{ padding: '12px 20px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {upcomingMeetings.map(m => {
                const c = T[m.color];
                return (
                  <div key={m.id} style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 12px', background: 'var(--color-background-secondary,#f8f7f4)', borderRadius: '10px' }}>
                    <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: c.bg, color: c.text, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', fontWeight: 500, flexShrink: 0 }}>{m.avatar}</div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p style={{ fontSize: '13px', fontWeight: 500, margin: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{m.title}</p>
                      <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)', margin: '1px 0 0', display: 'flex', alignItems: 'center', gap: '3px' }}>
                        <Clock size={10} /> {m.time}
                      </p>
                    </div>
                    <div style={{ width: '26px', height: '26px', borderRadius: '50%', background: c.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <Video size={11} color={c.text} />
                    </div>
                  </div>
                );
              })}
            </div>
            <div style={{ padding: '10px 20px', borderTop: '0.5px solid rgba(0,0,0,0.06)' }}>
              <Link to="/meetings" style={{ textDecoration: 'none' }}>
                <button style={{ width: '100%', padding: '9px', background: '#EAF3DE', color: '#0F6E56', border: '0.5px solid #C0DD97', borderRadius: '9px', cursor: 'pointer', fontSize: '12px', fontWeight: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                  <Calendar size={13} /> Open scheduler
                </button>
              </Link>
            </div>
          </div>

          {/* Fundraise progress */}
          <div style={baseCard}>
            <div style={{ padding: '16px 20px', borderBottom: '0.5px solid rgba(0,0,0,0.07)', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <TrendingUp size={14} color="#1D9E75" />
              <div style={{ fontSize: '14px', fontWeight: 500 }}>Fundraise progress</div>
            </div>
            <div style={{ padding: '16px 20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ fontSize: '12px', color: 'var(--color-text-secondary)' }}>Series A target</span>
                <span style={{ fontSize: '12px', fontWeight: 500 }}>$5M</span>
              </div>
              <div style={{ height: '6px', background: 'var(--color-background-secondary,#f0efec)', borderRadius: '3px', overflow: 'hidden', marginBottom: '8px' }}>
                <div style={{ height: '100%', width: '86%', background: '#1D9E75', borderRadius: '3px' }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: '11px', color: '#1D9E75', fontWeight: 500 }}>$4.3M raised · 86%</span>
                <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>$700K remaining</span>
              </div>
            </div>
          </div>

          {/* Recommended investors */}
          <div style={baseCard}>
            <div style={headStyle}>
              <div style={{ fontSize: '14px', fontWeight: 500 }}>Recommended investors</div>
              <Link to="/investors" style={{ fontSize: '12px', color: '#1D9E75', fontWeight: 500, textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '3px' }}>
                View all <ArrowRight size={11} />
              </Link>
            </div>
            <div style={{ padding: '8px 20px 16px' }}>
              {recommendedInvestors.map(inv => <InvestorCard key={inv.id} investor={inv} showActions={false} />)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};