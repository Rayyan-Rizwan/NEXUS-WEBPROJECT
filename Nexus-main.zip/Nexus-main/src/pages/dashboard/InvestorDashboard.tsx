import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Users, PieChart, Search, PlusCircle, Calendar, TrendingUp, Filter, X } from 'lucide-react';
import { EntrepreneurCard } from '../../components/entrepreneur/EntrepreneurCard';
import { useAuth } from '../../context/AuthContext';
import { entrepreneurs } from '../../data/users';
import { getRequestsFromInvestor } from '../../data/collaborationRequests';

const T = {
  emerald: { bg: '#EAF3DE', text: '#0F6E56', fill: '#1D9E75', mid: '#C0DD97' },
  violet:  { bg: '#EEEDFE', text: '#534AB7', fill: '#7F77DD', mid: '#AFA9EC' },
  amber:   { bg: '#FAEEDA', text: '#854F0B', fill: '#BA7517', mid: '#FAC775' },
  coral:   { bg: '#FAECE7', text: '#993C1D', fill: '#D85A30', mid: '#F5C4B3' },
};

const baseCard: React.CSSProperties = {
  background: 'var(--color-background-primary,#fff)',
  border: '0.5px solid rgba(0,0,0,0.08)',
  borderRadius: '14px',
  overflow: 'hidden',
};

export const InvestorDashboard: React.FC = () => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIndustries, setSelectedIndustries] = useState<string[]>([]);

  if (!user) return null;

  const sentRequests = getRequestsFromInvestor(user.id);
  const industries = Array.from(new Set(entrepreneurs.map(e => e.industry)));

  const filteredEntrepreneurs = entrepreneurs.filter(e => {
    const q = searchQuery.toLowerCase();
    const matchSearch = !searchQuery || e.name.toLowerCase().includes(q) || e.startupName.toLowerCase().includes(q) || e.industry.toLowerCase().includes(q) || e.pitchSummary.toLowerCase().includes(q);
    const matchInd = !selectedIndustries.length || selectedIndustries.includes(e.industry);
    return matchSearch && matchInd;
  });

  const toggleIndustry = (ind: string) =>
    setSelectedIndustries(p => p.includes(ind) ? p.filter(i => i !== ind) : [...p, ind]);

  const kpis = [
    { label: 'Total startups', value: entrepreneurs.length, color: 'emerald' as const, icon: <Users size={15} />, tag: 'In database' },
    { label: 'Industries tracked', value: industries.length, color: 'violet' as const, icon: <PieChart size={15} />, tag: 'Sectors' },
    { label: 'Your connections', value: sentRequests.filter(r => r.status === 'accepted').length, color: 'amber' as const, icon: <TrendingUp size={15} />, tag: 'Active' },
    { label: 'Meetings this week', value: 3, color: 'coral' as const, icon: <Calendar size={15} />, tag: 'Confirmed' },
  ];

  return (
    <div style={{ fontFamily: 'var(--font-sans,system-ui,sans-serif)', color: 'var(--color-text-primary)', paddingBottom: '32px' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '28px', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <h1 style={{ fontSize: '20px', fontWeight: 500, margin: '0 0 4px', letterSpacing: '-0.01em' }}>Discover startups</h1>
          <p style={{ fontSize: '13px', color: 'var(--color-text-secondary)', margin: 0 }}>Find and connect with promising entrepreneurs</p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <Link to="/meetings" style={{ textDecoration: 'none' }}>
            <button style={{ display: 'flex', alignItems: 'center', gap: '7px', padding: '9px 16px', background: 'var(--color-background-primary,#fff)', color: 'var(--color-text-secondary)', border: '0.5px solid rgba(0,0,0,0.12)', borderRadius: '10px', cursor: 'pointer', fontSize: '13px' }}>
              <Calendar size={14} /> Schedule
            </button>
          </Link>
          <Link to="/entrepreneurs" style={{ textDecoration: 'none' }}>
            <button style={{ display: 'flex', alignItems: 'center', gap: '7px', padding: '9px 18px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: '10px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>
              <PlusCircle size={14} /> View all startups
            </button>
          </Link>
        </div>
      </div>

      {/* KPI row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '14px', marginBottom: '24px' }}>
        {kpis.map((k, i) => {
          const c = T[k.color];
          return (
            <div key={i} style={baseCard}>
              <div style={{ height: '2px', background: c.fill }} />
              <div style={{ padding: '18px 20px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
                  <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: c.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', color: c.text }}>{k.icon}</div>
                  <span style={{ fontSize: '10px', fontWeight: 500, padding: '2px 8px', borderRadius: '20px', background: c.bg, color: c.text }}>{k.tag}</span>
                </div>
                <div style={{ fontSize: '28px', fontWeight: 500, letterSpacing: '-0.02em', lineHeight: 1 }}>{k.value}</div>
                <div style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginTop: '6px' }}>{k.label}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Search + filters */}
      <div style={{ ...baseCard, marginBottom: '16px' }}>
        <div style={{ padding: '14px 20px', display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
          {/* Search */}
          <div style={{ flex: 1, minWidth: '220px', position: 'relative' }}>
            <Search size={14} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--color-text-tertiary,#b0b0b0)' }} />
            <input
              placeholder="Search startups, industries, keywords…"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              style={{ width: '100%', padding: '8px 12px 8px 34px', border: '0.5px solid rgba(0,0,0,0.10)', borderRadius: '9px', fontSize: '13px', outline: 'none', background: 'var(--color-background-secondary,#f8f7f4)', color: 'var(--color-text-primary)', boxSizing: 'border-box' }}
            />
          </div>
          {/* Industry chips */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
            <Filter size={13} color="var(--color-text-tertiary,#b0b0b0)" />
            {industries.map(ind => {
              const active = selectedIndustries.includes(ind);
              return (
                <button key={ind} onClick={() => toggleIndustry(ind)} style={{ padding: '5px 11px', borderRadius: '20px', border: '0.5px solid', cursor: 'pointer', fontSize: '12px', fontWeight: active ? 500 : 400, transition: 'all 0.15s', background: active ? '#EAF3DE' : 'var(--color-background-primary,#fff)', color: active ? '#0F6E56' : 'var(--color-text-secondary)', borderColor: active ? '#1D9E75' : 'rgba(0,0,0,0.10)' }}>
                  {ind}
                </button>
              );
            })}
            {selectedIndustries.length > 0 && (
              <button onClick={() => setSelectedIndustries([])} style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '5px 10px', borderRadius: '20px', border: '0.5px solid rgba(0,0,0,0.10)', background: 'none', cursor: 'pointer', fontSize: '12px', color: 'var(--color-text-secondary)' }}>
                <X size={11} /> Clear
              </button>
            )}
          </div>
          <span style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginLeft: 'auto', flexShrink: 0 }}>
            {filteredEntrepreneurs.length} result{filteredEntrepreneurs.length !== 1 ? 's' : ''}
          </span>
        </div>
      </div>

      {/* Startup grid */}
      <div style={baseCard}>
        <div style={{ padding: '16px 24px', borderBottom: '0.5px solid rgba(0,0,0,0.07)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ fontSize: '14px', fontWeight: 500 }}>Featured startups</div>
          <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)', background: 'var(--color-background-secondary,#f5f4f0)', padding: '3px 10px', borderRadius: '20px' }}>
            {filteredEntrepreneurs.length} shown
          </span>
        </div>
        <div style={{ padding: '20px 24px' }}>
          {filteredEntrepreneurs.length > 0 ? (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(280px,1fr))', gap: '16px' }}>
              {filteredEntrepreneurs.map(e => <EntrepreneurCard key={e.id} entrepreneur={e} />)}
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '48px' }}>
              <p style={{ fontSize: '14px', fontWeight: 500, margin: '0 0 4px' }}>No startups match</p>
              <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)', margin: '0 0 16px' }}>Try adjusting your search or filters</p>
              <button onClick={() => { setSearchQuery(''); setSelectedIndustries([]); }} style={{ padding: '8px 16px', background: '#EAF3DE', color: '#0F6E56', border: '0.5px solid #C0DD97', borderRadius: '8px', cursor: 'pointer', fontSize: '13px', fontWeight: 500 }}>
                Clear all filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};